/***************************************************************************//**
 * @file serial_api.c
 *******************************************************************************
 * @section License
 * <b>(C) Copyright 2015 Silicon Labs, http://www.silabs.com</b>
 *******************************************************************************
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ******************************************************************************/

#include "device.h"
#include "clocking.h"
#if DEVICE_SERIAL

#include "mbed_assert.h"
#include "mbed_power_mgmt.h"
#include "serial_api.h"
#include <string.h>
#include <stdbool.h>

#include "pinmap.h"
#include "pinmap_function.h"
#include "pinmap_custom.h"
#include "PeripheralPins.h"
#include "PeripheralNames.h"

#include "em_eusart.h"
#include "em_cmu.h"
#include "em_dma.h"
#include "em_ldma.h"
#include "dma_api_HAL.h"
#include "dma_api.h"
#include "sleep_api.h"
#include "buffer.h"

#ifndef EUSART_PRESENT
#define EUSART_COUNT (0)
#endif

#define MODULES_SIZE_SERIAL (EUSART_COUNT)

/* Store IRQ id for each UART */
static uint32_t serial_irq_ids[MODULES_SIZE_SERIAL] = { 0 };
/* Interrupt handler from mbed common */
static uart_irq_handler irq_handler;
/* Keep track of incoming DMA IRQ's */
static bool serial_dma_irq_fired[DMA_CHAN_COUNT] = { false };

/* Serial interface on CONSOLE_TX/CONSOLE_RX retargets stdio */
int stdio_uart_inited = 0;
serial_t stdio_uart;

static void uart_irq(UARTName, SerialIrq);
static uint8_t serial_get_index(serial_t *obj);
static void serial_enable(serial_t *obj, uint8_t enable);
static void serial_enable_pins(serial_t *obj, uint8_t enable);
static void serial_set_route(serial_t *obj);
static IRQn_Type serial_get_rx_irq_index(serial_t *obj);
static IRQn_Type serial_get_tx_irq_index(serial_t *obj);
static CMU_Clock_TypeDef serial_get_clock(serial_t *obj);
static void serial_dmaSetupChannel(serial_t *obj, bool tx_nrx);
static void serial_rx_abort_asynch_intern(serial_t *obj, int unblock_sleep);
static void serial_tx_abort_asynch_intern(serial_t *obj, int unblock_sleep);
static void serial_block_sleep(serial_t *obj);
static void serial_unblock_sleep(serial_t *obj);

/* ISRs for RX and TX events */
#ifdef EUSART0
static void eusart0_rx_irq() { EUSART_IntClear((EUSART_TypeDef*)USART_0, EUSART_IF_RXFL); uart_irq(USART_0, RxIrq); }
static void eusart0_tx_irq() { EUSART_IntClear((EUSART_TypeDef*)USART_0, EUSART_IF_TXC); uart_irq(USART_0, TxIrq);}
#endif
#ifdef EUSART1
static void eusart1_rx_irq() { EUSART_IntClear((EUSART_TypeDef*)USART_1, EUSART_IF_RXFL); uart_irq(USART_1, RxIrq); }
static void eusart1_tx_irq() { EUSART_IntClear((EUSART_TypeDef*)USART_1, EUSART_IF_TXC); uart_irq(USART_1, TxIrq);}
#endif
#ifdef EUSART2
static void eusart2_rx_irq() { EUSART_IntClear((EUSART_TypeDef*)USART_2, EUSART_IF_RXFL); uart_irq(USART_2, RxIrq); }
static void eusart2_tx_irq() { EUSART_IntClear((EUSART_TypeDef*)USART_2, EUSART_IF_TXC); uart_irq(USART_2, TxIrq);}
#endif
#ifdef EUSART3
static void eusart3_rx_irq() { EUSART_IntClear((EUSART_TypeDef*)USART_3, EUSART_IF_RXFL); uart_irq(USART_3, RxIrq); }
static void eusart3_tx_irq() { EUSART_IntClear((EUSART_TypeDef*)USART_3, EUSART_IF_TXC); uart_irq(USART_3, TxIrq);}
#endif
#ifdef EUSART4
static void eusart4_rx_irq() { EUSART_IntClear((EUSART_TypeDef*)USART_4, EUSART_IF_RXFL); uart_irq(USART_4, RxIrq); }
static void eusart4_tx_irq() { EUSART_IntClear((EUSART_TypeDef*)USART_4, EUSART_IF_TXC); uart_irq(USART_4, TxIrq);}
#endif


/**
 * Initialize the UART using default settings, overridden by settings from serial object
 *
 * @param obj pointer to serial object
 */
static void uart_init(serial_t *obj, uint32_t baudrate, SerialParity parity, int stop_bits)
{
    EUSART_UartInit_TypeDef init = EUSART_UART_INIT_DEFAULT_HF;

    if (stop_bits == 2) {
        init.stopbits = eusartStopbits2;
    } else {
        init.stopbits = eusartStopbits1;
    }
    switch (parity) {
        case ParityOdd:
        case ParityForced0:
            init.parity = eusartOddParity;
            break;
        case ParityEven:
        case ParityForced1:
            init.parity = eusartEvenParity;
            break;
        default: /* ParityNone */
            init.parity = eusartNoParity;
            break;
    }

    init.enable = eusartDisable;
    init.baudrate = baudrate;
    init.oversampling = eusartOVS16;
    init.databits = eusartDataBits8;

    EUSART_UartInitHf(obj->serial.periph.uart, &init);
}
/**
* Get index of serial object, relating it to the physical peripheral.
*
* @param obj pointer to serial peripheral (= base address of periph)
* @return internal index of U(S)ART peripheral
*/
static inline uint8_t serial_pointer_get_index(uint32_t serial_ptr)
{
    uint8_t index = 0;
#ifdef EUSART0
    if (serial_ptr == USART_0) return index;
    index++;
#endif
#ifdef EUSART1
    if (serial_ptr == USART_1) return index;
    index++;
#endif
#ifdef EUSART2
    if (serial_ptr == USART_2) return index;
    index++;
#endif
#ifdef EUSART3
    if (serial_ptr == USART_3) return index;
    index++;
#endif
#ifdef EUSART4
    if (serial_ptr == USART_4) return index;
    index++;
#endif
    return 0;
}

/**
* Get index of serial object, relating it to the physical peripheral.
*
* @param obj pointer to serial object (mbed object)
* @return internal index of U(S)ART peripheral
*/
static inline uint8_t serial_get_index(serial_t *obj)
{
    return serial_pointer_get_index((uint32_t)obj->serial.periph.uart);
}

/**
* Get index of serial object RX IRQ, relating it to the physical peripheral.
*
* @param obj pointer to serial object
* @return internal NVIC RX IRQ index of U(S)ART peripheral
*/
static inline IRQn_Type serial_get_rx_irq_index(serial_t *obj)
{
    switch ((uint32_t)obj->serial.periph.uart) {
#ifdef EUSART0
        case USART_0:
            return EUSART0_RX_IRQn;
#endif
#ifdef EUSART1
        case USART_1:
            return EUSART1_RX_IRQn;
#endif
#ifdef EUSART2
        case USART_2:
            return EUSART2_RX_IRQn;
#endif
#ifdef EUSART3
        case USART_3:
            return EUSART3_RX_IRQn;
#endif
#ifdef EUSART4
        case USART_4:
            return EUSART4_RX_IRQn;
#endif
        default:
            MBED_ASSERT(0);
    }
    return (IRQn_Type)0;
}

/**
* Get index of serial object TX IRQ, relating it to the physical peripheral.
*
* @param obj pointer to serial object
* @return internal NVIC TX IRQ index of U(S)ART peripheral
*/
static inline IRQn_Type serial_get_tx_irq_index(serial_t *obj)
{
    switch ((uint32_t)obj->serial.periph.uart) {
#ifdef EUSART0
        case USART_0:
            return EUSART0_TX_IRQn;
#endif
#ifdef EUSART1
        case USART_1:
            return EUSART1_TX_IRQn;
#endif
#ifdef EUSART2
        case USART_2:
            return EUSART2_TX_IRQn;
#endif
#ifdef EUSART3
        case USART_3:
            return EUSART3_TX_IRQn;
#endif
#ifdef EUSART4
        case USART_4:
            return EUSART4_TX_IRQn;
#endif
        default:
            MBED_ASSERT(0);
    }
    return (IRQn_Type)0;
}

/**
* Get clock tree for serial peripheral pointed to by obj.
*
* @param obj pointer to serial object
* @return CMU_Clock_TypeDef for U(S)ART
*/
static inline CMU_Clock_TypeDef serial_get_clock(serial_t *obj)
{
    switch ((uint32_t)obj->serial.periph.uart) {
#ifdef EUSART0
        case USART_0:
            return cmuClock_EUSART0;
#endif
#ifdef EUSART1
        case USART_1:
            return cmuClock_EUSART1;
#endif
#ifdef EUSART2
        case USART_2:
            return cmuClock_EUSART2;
#endif
#ifdef EUSART3
        case USART_3:
            return cmuClock_EUSART3;
#endif
#ifdef EUSART4
        case USART_4:
            return cmuClock_EUSART4;
#endif
        default:
            return cmuClock_HCLK;
    }
}

static void serial_preinit(serial_t *obj, PinName tx, PinName rx)
{
    /* Get UART object connected to the given pins */
    UARTName uart_tx = (UARTName) pinmap_peripheral_with_exclusion(tx, PinMap_UART_TX);
    UARTName uart_rx = (UARTName) pinmap_peripheral_with_exclusion(rx, PinMap_UART_RX);
    /* Check that pins are connected to same UART */
    UARTName uart = (UARTName) pinmap_merge(uart_tx, uart_rx);
    MBED_ASSERT((int)uart != NC);
    pinmap_set_peripheral_availability((uint32_t)uart, true);

    obj->serial.periph.uart = (EUSART_TypeDef *) uart;

    /* Get location */
    uint32_t uart_tx_loc = pin_location(tx, PinMap_UART_TX);
    uint32_t uart_rx_loc = pin_location(rx, PinMap_UART_RX);

    obj->serial.location_tx = uart_tx_loc;
    obj->serial.location_rx = uart_rx_loc;

    /* Store pins in object for easy disabling in serial_free() */
    //TODO: replace all usages with AF_USARTx_TX_PORT(location) macro to save 8 bytes from struct
    obj->serial.rx_pin = rx;
    obj->serial.tx_pin = tx;

    /* Select interrupt */
    switch ((uint32_t)obj->serial.periph.uart) {
#ifdef EUSART0
        case USART_0:
            NVIC_SetVector(EUSART0_RX_IRQn, (uint32_t) &eusart0_rx_irq);
            NVIC_SetVector(EUSART0_TX_IRQn, (uint32_t) &eusart0_tx_irq);
            NVIC_SetPriority(EUSART0_TX_IRQn, 1);
            break;
#endif
#ifdef EUSART1
        case USART_1:
            NVIC_SetVector(EUSART1_RX_IRQn, (uint32_t) &eusart1_rx_irq);
            NVIC_SetVector(EUSART1_TX_IRQn, (uint32_t) &eusart1_tx_irq);
            NVIC_SetPriority(EUSART1_TX_IRQn, 1);
            break;
#endif
#ifdef EUSART2
        case USART_2:
            NVIC_SetVector(EUSART2_RX_IRQn, (uint32_t) &eusart2_rx_irq);
            NVIC_SetVector(EUSART2_TX_IRQn, (uint32_t) &eusart2_tx_irq);
            NVIC_SetPriority(EUSART2_TX_IRQn, 1);
            break;
#endif
#ifdef EUSART3
        case USART_3:
            NVIC_SetVector(EUSART3_RX_IRQn, (uint32_t) &eusart3_rx_irq);
            NVIC_SetVector(EUSART3_TX_IRQn, (uint32_t) &eusart3_tx_irq);
            NVIC_SetPriority(EUSART3_TX_IRQn, 1);
            break;
#endif
#ifdef EUSART4
        case USART_4:
            NVIC_SetVector(EUSART4_RX_IRQn, (uint32_t) &eusart4_rx_irq);
            NVIC_SetVector(EUSART4_TX_IRQn, (uint32_t) &eusart4_tx_irq);
            NVIC_SetPriority(EUSART4_TX_IRQn, 1);
            break;
#endif
    }
}

static void serial_enable_pins(serial_t *obj, uint8_t enable)
{
    if (enable) {
        /* Configure GPIO pins*/
        if(obj->serial.rx_pin != NC) {
            pin_mode(obj->serial.rx_pin, Input);
        }
        /* Set DOUT first to prevent glitches */
        if(obj->serial.tx_pin != NC) {
            GPIO_PinOutSet((GPIO_Port_TypeDef)(obj->serial.tx_pin >> 4 & 0xF), obj->serial.tx_pin & 0xF);
            pin_mode(obj->serial.tx_pin, PushPull);
        }
    } else {
        if(obj->serial.rx_pin != NC) {
            pin_mode(obj->serial.rx_pin, Disabled);
        }
        if(obj->serial.tx_pin != NC) {
            pin_mode(obj->serial.tx_pin, Disabled);
        }
    }
}

static void serial_set_route(serial_t *obj)
{
    uint32_t txrxen_mask = 0;

    if((int)obj->serial.location_tx != NC) {
        GPIO->EUSARTROUTE[serial_get_index(obj)].TXROUTE = ((obj->serial.tx_pin >> 4 & 0xF) << _GPIO_EUSART_TXROUTE_PORT_SHIFT)
                                    | (obj->serial.location_tx << _GPIO_EUSART_TXROUTE_PIN_SHIFT);
        txrxen_mask |= GPIO_EUSART_ROUTEEN_TXPEN;
    }
    if((int)obj->serial.location_rx != NC) {
        GPIO->EUSARTROUTE[serial_get_index(obj)].RXROUTE = ((obj->serial.rx_pin >> 4 & 0xF) << _GPIO_EUSART_RXROUTE_PORT_SHIFT)
                                    | (obj->serial.location_rx << _GPIO_EUSART_RXROUTE_PIN_SHIFT);
        txrxen_mask |= GPIO_EUSART_ROUTEEN_RXPEN;
    }


    GPIO->EUSARTROUTE[serial_get_index(obj)].ROUTEEN = txrxen_mask;
}

void serial_init(serial_t *obj, PinName tx, PinName rx)
{
    serial_preinit(obj, tx, rx);

    serial_enable_pins(obj, true);
    serial_set_route(obj);

    CMU_ClockEnable(serial_get_clock(obj), true);

    /* Configure UART for async operation */
    uart_init(obj, MBED_CONF_PLATFORM_DEFAULT_SERIAL_BAUD_RATE, ParityNone, 1);


    /* Reset interrupts */
    obj->serial.periph.uart->IF_CLR = EUSART_IF_TXC;

    /* If this is the UART to be used for stdio, copy it to the stdio_uart struct */
    if(obj == &stdio_uart) {
        stdio_uart_inited = 1;
        memcpy(&stdio_uart, obj, sizeof(serial_t));
    }

    //serial_enable_pins(obj, true);
    serial_enable(obj, true);

    obj->serial.dmaOptionsTX.dmaChannel = -1;
    obj->serial.dmaOptionsTX.dmaUsageState = DMA_USAGE_OPPORTUNISTIC;

    obj->serial.dmaOptionsRX.dmaChannel = -1;
    obj->serial.dmaOptionsRX.dmaUsageState = DMA_USAGE_OPPORTUNISTIC;

}

void serial_free(serial_t *obj)
{
    EUSART_Enable(obj->serial.periph.uart, eusartDisable);
    serial_enable_pins(obj, false);
    pinmap_set_peripheral_availability((uint32_t)obj->serial.periph.uart, false);
}

static void serial_enable(serial_t *obj, uint8_t enable)
{
    if (enable) {
        EUSART_Enable(obj->serial.periph.uart, eusartEnable);
    } else {
        EUSART_Enable(obj->serial.periph.uart, eusartDisable);
    }
    serial_irq_ids[serial_get_index(obj)] = 0;
}

/**
 * Set UART baud rate
 */
void serial_baud(serial_t *obj, int baudrate)
{
    EUSART_BaudrateSet(obj->serial.periph.uart, 0, (uint32_t)baudrate);
}

/**
 * Set UART format by re-initializing the peripheral.
 */
void serial_format(serial_t *obj, int data_bits, SerialParity parity, int stop_bits)
{
    /* Save the serial state */
    uint8_t     was_enabled = EUSART_StatusGet(obj->serial.periph.uart) & (EUSART_STATUS_TXENS | EUSART_STATUS_RXENS);
    uint32_t    enabled_interrupts = obj->serial.periph.uart->IEN;


    EUSART_UartInit_TypeDef init = EUSART_UART_INIT_DEFAULT_HF;

    /* We support 4 to 8 data bits */
    MBED_ASSERT(data_bits >= 4 && data_bits <= 8);

    /* Re-init the UART */
    init.enable = (was_enabled == 0 ? eusartDisable : eusartEnable);
    init.baudrate = EUSART_BaudrateGet(obj->serial.periph.uart);
    init.oversampling = eusartOVS16;
    init.databits = (EUSART_Databits_TypeDef)((data_bits - 3));
    if (stop_bits == 2) {
        init.stopbits = eusartStopbits2;
    } else {
        init.stopbits = eusartStopbits1;
    }
    switch (parity) {
        case ParityOdd:
        case ParityForced0:
            init.parity = eusartOddParity;
            break;
        case ParityEven:
        case ParityForced1:
            init.parity = eusartEvenParity;
            break;
        default: /* ParityNone */
            init.parity = eusartNoParity;
            break;
    }

    EUSART_UartInitHf(obj->serial.periph.uart, &init);

    /* Re-enable pins for UART at correct location */
    serial_set_route(obj);

    /* Re-enable interrupts */
    if(was_enabled != 0) {
        obj->serial.periph.uart->IF_CLR = EUSART_IF_TXC;
        obj->serial.periph.uart->IEN = enabled_interrupts;
    }
}

/**
 * Set handler for all serial interrupts (is probably SerialBase::_handler())
 * and store IRQ ID to be returned to the handler upon interrupt. ID is
 * probably a pointer to the calling Serial object.
 */
void serial_irq_handler(serial_t *obj, uart_irq_handler handler, uint32_t id)
{
    irq_handler = handler;
    serial_irq_ids[serial_get_index(obj)] = id;
}

/**
 * Generic ISR for all UARTs, both TX and RX
 */
static void uart_irq(UARTName name, SerialIrq irq)
{
    uint8_t index = serial_pointer_get_index((uint32_t)name);
    if (serial_irq_ids[index] != 0) {
        /* Pass interrupt on to mbed common handler */
        irq_handler(serial_irq_ids[index], irq);
        /* Clearing interrupt not necessary */
    }
}

/**
 * Set ISR for a given UART and interrupt event (TX or RX)
 */
void serial_irq_set(serial_t *obj, SerialIrq irq, uint32_t enable)
{
    /* Enable or disable interrupt */
    if (enable) {
        if (irq == RxIrq) { /* RX */
            obj->serial.periph.uart->IEN |= EUSART_IEN_RXFL;
            NVIC_ClearPendingIRQ(serial_get_rx_irq_index(obj));
            NVIC_EnableIRQ(serial_get_rx_irq_index(obj));
        } else { /* TX */
            obj->serial.periph.uart->IEN |= EUSART_IEN_TXC;
            NVIC_SetPendingIRQ(serial_get_tx_irq_index(obj));
            NVIC_SetPriority(serial_get_tx_irq_index(obj), 1);
            NVIC_EnableIRQ(serial_get_tx_irq_index(obj));
        }
    } else {
        if (irq == RxIrq) { /* RX */
            obj->serial.periph.uart->IEN &= ~EUSART_IEN_RXFL;
            NVIC_DisableIRQ(serial_get_rx_irq_index(obj));
        } else { /* TX */
            obj->serial.periph.uart->IEN &= ~EUSART_IEN_TXC;
            NVIC_DisableIRQ(serial_get_tx_irq_index(obj));
        }
    }
}

/******************************************************************************
 *                               READ/WRITE                                   *
 ******************************************************************************/

/**
 *  Get one char from serial link
 */
int serial_getc(serial_t *obj)
{
    /* Emlib USART_Rx blocks until data is available, so we don't need to use
     * serial_readable(). Use USART_RxDataGet() to read register directly. */

    return EUSART_Rx(obj->serial.periph.uart);
}

/*
 * Send one char over serial link
 */
void serial_putc(serial_t *obj, int c)
{
    /* Emlib USART_Tx blocks until buffer is writable (non-full), so we don't
     * need to use serial_writable(). */
    EUSART_Tx(obj->serial.periph.uart, (uint8_t)(c));
}

/**
 * Check if data is available in RX data vector
 */
int serial_readable(serial_t *obj)
{
    return obj->serial.periph.uart->STATUS & EUSART_STATUS_RXFL;
}

/**
 * Check if TX buffer is empty
 */
int serial_writable(serial_t *obj)
{
    return !(obj->serial.periph.uart->STATUS & _EUSART_STATUS_TXFCNT_MASK);
}

/**
 * Clear UART interrupts
 */
void serial_clear(serial_t *obj)
{
    /* Interrupts automatically clear when condition is not met anymore */
}

void serial_break_set(serial_t *obj)
{
    /* Send transmission break */
    //obj->serial.periph.uart->TXDATAX = USART_TXDATAX_TXBREAK;
}

void serial_break_clear(serial_t *obj)
{
    /* No need to clear break, it is automatically cleared after one frame.
     * From the reference manual:
     *
     * By setting TXBREAK, the output will be held low during the stop-bit
     * period to generate a framing error. A receiver that supports break
     * detection detects this state, allowing it to be used e.g. for framing
     * of larger data packets. The line is driven high before the next frame
     * is transmitted so the next start condition can be identified correctly
     * by the recipient. Continuous breaks lasting longer than a USART frame
     * are thus not supported by the USART. GPIO can be used for this.
     */
}

void serial_pinout_tx(PinName tx)
{
    /* 0x10 sets DOUT high. Prevents false start. */
    pin_mode(tx, PushPull | 0x10);
}

const PinMap *serial_tx_pinmap()
{
    return PinMap_UART_TX;
}

const PinMap *serial_rx_pinmap()
{
    return PinMap_UART_RX;
}

const PinMap *serial_cts_pinmap()
{
#if !DEVICE_SERIAL_FC
    static const PinMap PinMap_UART_CTS[] = {
        {NC, NC, 0}
    };
#endif

    return PinMap_UART_CTS;
}

const PinMap *serial_rts_pinmap()
{
#if !DEVICE_SERIAL_FC
    static const PinMap PinMap_UART_RTS[] = {
        {NC, NC, 0}
    };
#endif

    return PinMap_UART_RTS;
}

#if DEVICE_SERIAL_FC

/**
 * Set HW Control Flow
 * @param obj    The serial object
 * @param type   The Control Flow type (FlowControlNone, FlowControlRTS, FlowControlCTS, FlowControlRTSCTS)
 * @param pinmap Pointer to structure which holds static pinmap
 */
#if STATIC_PINMAP_READY
#define SERIAL_SET_FC_DIRECT serial_set_flow_control_direct
void serial_set_flow_control_direct(serial_t *obj, FlowControl type, const serial_fc_pinmap_t *pinmap)
#else
#define SERIAL_SET_FC_DIRECT _serial_set_flow_control_direct
static void _serial_set_flow_control_direct(serial_t *obj, FlowControl type, const serial_fc_pinmap_t *pinmap)
#endif
{
//    USART_TypeDef *usart = obj->serial.periph.uart;
//
//    if ((type == FlowControlRTS) || (type == FlowControlRTSCTS)) {
//        // Set RTS location
//        MBED_ASSERT(pinmap->rx_flow_pin != NC);
//        usart->ROUTELOC1 = (usart->ROUTELOC1 & (~_USART_ROUTELOC1_RTSLOC_MASK)) | (pinmap->rx_flow_function << _USART_ROUTELOC1_RTSLOC_SHIFT);
//        usart->ROUTEPEN |= USART_ROUTEPEN_RTSPEN;
//
//        pin_mode(pinmap->rx_flow_pin, PushPull); // need to init at 0 ?
//    } else {
//        usart->ROUTEPEN &= ~USART_ROUTEPEN_RTSPEN;
//
//        if (pinmap->rx_flow_pin != NC) {
//            pin_mode(pinmap->rx_flow_pin, Disabled);
//        }
//    }
//
//    if ((type == FlowControlCTS) || (type == FlowControlRTSCTS)) {
//        // Set CTS location
//        MBED_ASSERT(pinmap->tx_flow_pin != NC);
//        usart->ROUTELOC1 = (usart->ROUTELOC1 & (~_USART_ROUTELOC1_CTSLOC_MASK)) | (pinmap->tx_flow_function << _USART_ROUTELOC1_CTSLOC_SHIFT);
//        usart->ROUTEPEN |= USART_ROUTEPEN_CTSPEN;
//        // Enable CTS
//        usart->CTRLX |= USART_CTRLX_CTSEN;
//
//        pin_mode(pinmap->tx_flow_pin, Input); // InputPullDown ?
//    } else {
//        usart->ROUTEPEN &= ~USART_ROUTEPEN_CTSPEN;
//        // Disable CTS
//        usart->CTRLX &= ~USART_CTRLX_CTSEN;
//
//        if (pinmap->tx_flow_pin != NC) {
//            pin_mode(pinmap->tx_flow_pin, Disabled);
//        }
//    }
}

/**
 * Set HW Control Flow
 * @param obj    The serial object
 * @param type   The Control Flow type (FlowControlNone, FlowControlRTS, FlowControlCTS, FlowControlRTSCTS)
 * @param rxflow Pin for the rxflow
 * @param txflow Pin for the txflow
 */
void serial_set_flow_control(serial_t *obj, FlowControl type, PinName rxflow, PinName txflow)
{
//    int tx_flow_function = (int)pinmap_find_function(txflow, PinMap_UART_CTS);
//    int rx_flow_function = (int)pinmap_find_function(rxflow, PinMap_UART_RTS);
//    // TODO check if it's the correct uart
//
//    const serial_fc_pinmap_t explicit_uart_fc_pinmap = {0, txflow, tx_flow_function, rxflow, rx_flow_function};
//
//    SERIAL_SET_FC_DIRECT(obj, type, &explicit_uart_fc_pinmap);
}

#endif /* DEVICE_SERIAL_FC */

/************************************************************************************
 *          DMA helper functions                                                    *
 ************************************************************************************/
/******************************************
* static void serial_dmaTransferComplete(uint channel, bool primary, void* user)
*
* Callback function which gets called upon DMA transfer completion
* the user-defined pointer is pointing to the CPP-land thunk
******************************************/
static void serial_dmaTransferComplete(unsigned int channel, bool primary, void *user)
{
    /* Store information about which channel triggered because CPP doesn't take arguments */
    serial_dma_irq_fired[channel] = true;

    /* User pointer should be a thunk to CPP land */
    if (user != NULL) {
        ((DMACallback)user)();
    }
}

/******************************************
* static void serial_dmaTrySetState(DMA_OPTIONS_t *obj, DMAUsage requestedState)
*
* Tries to set the passed DMA state to the requested state.
*
* requested state possibilities:
*   * NEVER:
*       if the previous state was always, will deallocate the channel
*   * OPPORTUNISTIC:
*       If the previous state was always, will reuse that channel but free upon next completion.
*       If not, will try to acquire a channel.
*       When allocated, state changes to DMA_USAGE_TEMPORARY_ALLOCATED.
*   * ALWAYS:
*       Will try to allocate a channel and keep it.
*       If succesfully allocated, state changes to DMA_USAGE_ALLOCATED.
******************************************/
static void serial_dmaTrySetState(DMA_OPTIONS_t *obj, DMAUsage requestedState, serial_t *serialPtr, bool tx_nrx)
{
    DMAUsage currentState = obj->dmaUsageState;
    int tempDMAChannel = -1;

    if ((requestedState == DMA_USAGE_ALWAYS) && (currentState != DMA_USAGE_ALLOCATED)) {
        /* Try to allocate channel */
        tempDMAChannel = dma_channel_allocate(DMA_CAP_NONE);
        if(tempDMAChannel >= 0) {
            obj->dmaChannel = tempDMAChannel;
            obj->dmaUsageState = DMA_USAGE_ALLOCATED;
            dma_init();
            serial_dmaSetupChannel(serialPtr, tx_nrx);
        }
    } else if (requestedState == DMA_USAGE_OPPORTUNISTIC) {
        if (currentState == DMA_USAGE_ALLOCATED) {
            /* Channels have already been allocated previously by an ALWAYS state, so after this transfer, we will release them */
            obj->dmaUsageState = DMA_USAGE_TEMPORARY_ALLOCATED;
        } else {
            /* Try to allocate channel */
            tempDMAChannel = dma_channel_allocate(DMA_CAP_NONE);
            if(tempDMAChannel >= 0) {
                obj->dmaChannel = tempDMAChannel;
                obj->dmaUsageState = DMA_USAGE_TEMPORARY_ALLOCATED;
                dma_init();
                serial_dmaSetupChannel(serialPtr, tx_nrx);
            }
        }
    } else if (requestedState == DMA_USAGE_NEVER) {
        /* If channel is allocated, get rid of it */
        dma_channel_free(obj->dmaChannel);
        obj->dmaChannel = -1;
        obj->dmaUsageState = DMA_USAGE_NEVER;
    }
}


#ifdef LDMA_PRESENT

static void serial_dmaSetupChannel(serial_t *obj, bool tx_nrx)
{
}

static void serial_dmaActivate(serial_t *obj, void* cb, void* buffer, int length, bool tx_nrx)
{
    LDMA_PeripheralSignal_t dma_periph;

    obj->serial.dmaOptionsRX.dmaCallback.userPtr = cb;

    if( tx_nrx ) {
        volatile void *target_addr;

        // Clear TXC
        EUSART_IntClear(obj->serial.periph.uart, EUSART_IF_TXC);

        switch((uint32_t)(obj->serial.periph.uart)) {
#ifdef EUSART0
            case USART_0:
                dma_periph = ldmaPeripheralSignal_EUSART0_TXFL;
                target_addr = &EUSART0->TXDATA;
                obj->serial.periph.uart->CMD = EUSART_CMD_TXEN | EUSART_CMD_CLEARTX;
                break;
#endif
#ifdef EUSART1
            case USART_1:
                dma_periph = ldmaPeripheralSignal_EUSART1_TXFL;
                target_addr = &EUSART1->TXDATA;
                obj->serial.periph.uart->CMD = EUSART_CMD_TXEN | EUSART_CMD_CLEARTX;
                break;
#endif
#ifdef EUSART2
            case USART_2:
                dma_periph = ldmaPeripheralSignal_EUSART2_TXFL;
                target_addr = &EUSART2->TXDATA;
                obj->serial.periph.uart->CMD = EUSART_CMD_TXEN | EUSART_CMD_CLEARTX;
                break;
#endif
#ifdef EUSART3
            case USART_3:
                dma_periph = ldmaPeripheralSignal_EUSART3_TXFL;
                target_addr = &EUSART3->TXDATA;
                obj->serial.periph.uart->CMD = EUSART_CMD_TXEN | EUSART_CMD_CLEARTX;
                break;
#endif
#ifdef EUSART4
            case USART_4:
                dma_periph = ldmaPeripheralSignal_EUSART4_TXFL;
                target_addr = &EUSART4->TXDATA;
                obj->serial.periph.uart->CMD = EUSART_CMD_TXEN | EUSART_CMD_CLEARTX;
                break;
#endif
            default:
                MBED_ASSERT(0);
                while(1);
                break;
        }

        // Set callback and enable TXC. This will fire once the
        // serial transfer finishes
        NVIC_SetVector(serial_get_tx_irq_index(obj), (uint32_t)cb);
        serial_irq_set(obj, TxIrq, true);

        // Start DMA transfer
        LDMA_TransferCfg_t xferConf = LDMA_TRANSFER_CFG_PERIPHERAL(dma_periph);
        LDMA_Descriptor_t desc = LDMA_DESCRIPTOR_SINGLE_M2P_BYTE(buffer, target_addr, length);
        LDMAx_StartTransfer(obj->serial.dmaOptionsTX.dmaChannel, &xferConf, &desc, serial_dmaTransferComplete, NULL);

    } else {
        volatile const void *source_addr;

        switch((uint32_t)(obj->serial.periph.uart)) {
#ifdef EUSART0
            case USART_0:
                dma_periph = ldmaPeripheralSignal_EUSART0_RXFL;
                source_addr = &EUSART0->RXDATA;
                obj->serial.periph.uart->CMD = EUSART_CMD_RXEN;
                break;
#endif
#ifdef EUSART1
            case USART_1:
                dma_periph = ldmaPeripheralSignal_EUSART1_RXFL;
                source_addr = &EUSART1->RXDATA;
                obj->serial.periph.uart->CMD = EUSART_CMD_RXEN;
                break;
#endif
#ifdef EUSART2
            case USART_2:
                dma_periph = ldmaPeripheralSignal_EUSART2_RXFL;
                source_addr = &EUSART2->RXDATA;
                obj->serial.periph.uart->CMD = EUSART_CMD_RXEN;
                break;
#endif
#ifdef EUSART3
            case USART_3:
                dma_periph = ldmaPeripheralSignal_EUSART3_RXFL;
                source_addr = &EUSART3->RXDATA;
                obj->serial.periph.uart->CMD = EUSART_CMD_RXEN;
                break;
#endif
#ifdef EUSART4
            case USART_4:
                dma_periph = ldmaPeripheralSignal_EUSART4_RXFL;
                source_addr = &EUSART4->RXDATA;
                obj->serial.periph.uart->CMD = EUSART_CMD_RXEN;
                break;
#endif
            default:
                MBED_ASSERT(0);
                while(1);
                break;
        }

        LDMA_TransferCfg_t xferConf = LDMA_TRANSFER_CFG_PERIPHERAL(dma_periph);
        LDMA_Descriptor_t desc = LDMA_DESCRIPTOR_SINGLE_P2M_BYTE(source_addr, buffer, length);
        LDMAx_StartTransfer(obj->serial.dmaOptionsRX.dmaChannel, &xferConf, &desc, serial_dmaTransferComplete, cb);
    }
}

#endif /* LDMA_PRESENT */

/************************************************************************************
 *          ASYNCHRONOUS HAL                                                        *
 ************************************************************************************/

#if DEVICE_SERIAL_ASYNCH

/************************************
 * HELPER FUNCTIONS                 *
 ***********************************/

/** Configure TX events
 *
 * @param obj    The serial object
 * @param event  The logical OR of the TX events to configure
 * @param enable Set to non-zero to enable events, or zero to disable them
 */
static void serial_tx_enable_event(serial_t *obj, int event, uint8_t enable)
{
    // Shouldn't have to enable TX interrupt here, just need to keep track of the requested events.
    if(enable) obj->serial.events |= event;
    else obj->serial.events &= ~event;
}

/**
 * @param obj    The serial object.
 * @param event  The logical OR of the RX events to configure
 * @param enable Set to non-zero to enable events, or zero to disable them
 */
static void serial_rx_enable_event(serial_t *obj, int event, uint8_t enable)
{
    if(enable) {
        obj->serial.events |= event;
    } else {
        obj->serial.events &= ~event;
    }

    if(event & SERIAL_EVENT_RX_FRAMING_ERROR) {
        //FERR interrupt source
        if(enable) obj->serial.periph.uart->IEN |= EUSART_IEN_FERR;
        else obj->serial.periph.uart->IEN &= ~EUSART_IEN_FERR;
    }
    if(event & SERIAL_EVENT_RX_PARITY_ERROR) {
        //PERR interrupt source
        if(enable) obj->serial.periph.uart->IEN |= EUSART_IEN_PERR;
        else obj->serial.periph.uart->IEN &= ~EUSART_IEN_PERR;
    }
    if(event & SERIAL_EVENT_RX_OVERFLOW) {
        //RXOF interrupt source
        if(enable) obj->serial.periph.uart->IEN |= EUSART_IEN_RXOF;
        else obj->serial.periph.uart->IEN &= ~EUSART_IEN_RXOF;
    }
}

/** Configure the TX buffer for an asynchronous write serial transaction
 *
 * @param obj       The serial object.
 * @param tx        The buffer for sending.
 * @param tx_length The number of words to transmit.
 */
static void serial_tx_buffer_set(serial_t *obj, void *tx, int tx_length, uint8_t width)
{
    // We only support byte buffers for now
    MBED_ASSERT(width == 8);

    if(serial_tx_active(obj)) return;

    obj->tx_buff.buffer = tx;
    obj->tx_buff.length = tx_length;
    obj->tx_buff.pos = 0;

    return;
}

/** Configure the TX buffer for an asynchronous read serial transaction
 *
 * @param obj       The serial object.
 * @param rx        The buffer for receiving.
 * @param rx_length The number of words to read.
 */
static void serial_rx_buffer_set(serial_t *obj, void *rx, int rx_length, uint8_t width)
{
    // We only support byte buffers for now
    MBED_ASSERT(width == 8);

    if(serial_rx_active(obj)) return;

    obj->rx_buff.buffer = rx;
    obj->rx_buff.length = rx_length;
    obj->rx_buff.pos = 0;

    return;
}

/************************************
 * TRANSFER FUNCTIONS               *
 ***********************************/

/** Begin asynchronous TX transfer. The used buffer is specified in the serial object,
 *  tx_buff
 *
 * @param obj  The serial object
 * @param cb   The function to call when an event occurs
 * @param hint A suggestion for how to use DMA with this transfer
 * @return Returns number of data transfered, or 0 otherwise
 */
int serial_tx_asynch(serial_t *obj, const void *tx, size_t tx_length, uint8_t tx_width, uint32_t handler, uint32_t event, DMAUsage hint)
{
   // Check that a buffer has indeed been set up
    MBED_ASSERT(tx != (void*)0);
    if(tx_length == 0) return 0;

    // Set up buffer
    serial_tx_buffer_set(obj, (void *)tx, tx_length, tx_width);

    // Set up events
    serial_tx_enable_event(obj, SERIAL_EVENT_TX_ALL, false);
    serial_tx_enable_event(obj, event, true);

    // Set up sleepmode
    serial_block_sleep(obj);

    // Determine DMA strategy
    serial_dmaTrySetState(&(obj->serial.dmaOptionsTX), hint, obj, true);

    // If DMA, kick off DMA transfer
    if(obj->serial.dmaOptionsTX.dmaChannel >= 0) {
        serial_dmaActivate(obj, (void*)handler, obj->tx_buff.buffer, obj->tx_buff.length, true);
    }
    // Else, activate interrupt. TXBL will take care of buffer filling through ISR.
    else {
        // Store callback
        NVIC_ClearPendingIRQ(serial_get_tx_irq_index(obj));
        NVIC_DisableIRQ(serial_get_tx_irq_index(obj));
        NVIC_SetPriority(serial_get_tx_irq_index(obj), 1);
        NVIC_SetVector(serial_get_tx_irq_index(obj), (uint32_t)handler);
        NVIC_EnableIRQ(serial_get_tx_irq_index(obj));

        // Activate TX and clear TX buffer
        obj->serial.periph.uart->CMD = EUSART_CMD_TXEN | EUSART_CMD_CLEARTX;

        // Enable interrupt
        EUSART_IntEnable(obj->serial.periph.uart, EUSART_IEN_TXFL);
    }

    return 0;
}

/** Begin asynchronous RX transfer (enable interrupt for data collecting)
 *  The used buffer is specified in the serial object - rx_buff
 *
 * @param obj  The serial object
 * @param cb   The function to call when an event occurs
 * @param hint A suggestion for how to use DMA with this transfer
 */
void serial_rx_asynch(serial_t *obj, void *rx, size_t rx_length, uint8_t rx_width, uint32_t handler, uint32_t event, uint8_t char_match, DMAUsage hint)
{
    // Check that a buffer has indeed been set up
    MBED_ASSERT(rx != (void*)0);
    if(rx_length == 0) return;

    // Set up buffer
    serial_rx_buffer_set(obj,(void*) rx, rx_length, rx_width);

    //disable character match if no character is specified
    if(char_match == SERIAL_RESERVED_CHAR_MATCH){
        event &= ~SERIAL_EVENT_RX_CHARACTER_MATCH;
    }

    /*clear all set interrupts*/
    EUSART_IntClear(obj->serial.periph.uart,  EUSART_IF_PERR | EUSART_IF_FERR | EUSART_IF_RXOF);

    // Set up events
    serial_rx_enable_event(obj, SERIAL_EVENT_RX_ALL, false);
    serial_rx_enable_event(obj, event, true);
    obj->char_match = char_match;

    // Set up sleepmode
    serial_block_sleep(obj);

    // Determine DMA strategy
    // If character match is enabled, we can't use DMA, sadly. We could when using LEUART though, but that support is not in here yet.
    // TODO: add DMA support for character matching with leuart
    if(!(event & SERIAL_EVENT_RX_CHARACTER_MATCH)) {
        serial_dmaTrySetState(&(obj->serial.dmaOptionsRX), hint, obj, false);
    }else{
        serial_dmaTrySetState(&(obj->serial.dmaOptionsRX), DMA_USAGE_NEVER, obj, false);
    }

    // If DMA, kick off DMA
    if(obj->serial.dmaOptionsRX.dmaChannel >= 0) {
        serial_dmaActivate(obj, (void*)handler, obj->rx_buff.buffer, obj->rx_buff.length, false);
    }
    // Else, activate interrupt. RXDATAV is responsible for incoming data notification.
    else {
        // Store callback
        NVIC_ClearPendingIRQ(serial_get_rx_irq_index(obj));
        NVIC_SetVector(serial_get_rx_irq_index(obj), (uint32_t)handler);
        NVIC_EnableIRQ(serial_get_rx_irq_index(obj));

        // Activate RX and clear RX buffer
        obj->serial.periph.uart->CMD = EUSART_CMD_RXEN;

        // Clear RXFULL
        EUSART_IntClear(obj->serial.periph.uart, EUSART_IF_RXFULL);

        // Enable interrupt
        EUSART_IntEnable(obj->serial.periph.uart, EUSART_IEN_RXFL);
    }

    return;
}

/** Attempts to determine if the serial peripheral is already in use for TX
 *
 * @param obj The serial object
 * @return Non-zero if the TX transaction is ongoing, 0 otherwise
 */
uint8_t serial_tx_active(serial_t *obj)
{
    return (obj->serial.periph.uart->IEN & (EUSART_IEN_TXFL|EUSART_IEN_TXC)) ? true : false;
}

/** Attempts to determine if the serial peripheral is already in use for RX
 *
 * @param obj The serial object
 * @return Non-zero if the RX transaction is ongoing, 0 otherwise
 */
uint8_t serial_rx_active(serial_t *obj)
{
    switch(obj->serial.dmaOptionsRX.dmaUsageState) {
        case DMA_USAGE_TEMPORARY_ALLOCATED:
            /* Temporary allocation always means its active, as this state gets cleared afterwards */
            return 1;
        case DMA_USAGE_ALLOCATED:
            /* Check whether the allocated DMA channel is active by checking the DMA transfer */
#ifndef LDMA_PRESENT
            return DMA_ChannelEnabled(obj->serial.dmaOptionsRX.dmaChannel);
#else
            // LDMA_TransferDone does not work since the CHDONE bits get cleared,
            // so just check if the channel is enabled
            return LDMA->CHEN & (1 << obj->serial.dmaOptionsRX.dmaChannel);
#endif
        default:
            /* Check whether interrupt for serial TX is enabled */
            return (obj->serial.periph.uart->IEN & (EUSART_IEN_TXFL)) ? true : false;
    }
}

/** The asynchronous TX handler. Writes to the TX FIFO and checks for events.
 *  If any TX event has occured, the TX abort function is called.
 *
 * @param obj The serial object
 * @return Returns event flags if a TX transfer termination condition was met or 0 otherwise
 */
static int serial_tx_irq_handler_asynch(serial_t *obj)
{
    /* This interrupt handler is called from USART irq */
    uint8_t *buf = obj->tx_buff.buffer;

    if(obj->serial.periph.uart->IEN & EUSART_IEN_TXFL){
        /* There is still data to send */
        while((EUSART_StatusGet(obj->serial.periph.uart) & EUSART_STATUS_TXFL) && (obj->tx_buff.pos <= (obj->tx_buff.length - 1))) {
            EUSART_Tx(obj->serial.periph.uart, buf[obj->tx_buff.pos]);
            obj->tx_buff.pos++;
        }
        if(obj->tx_buff.pos >= obj->tx_buff.length){
            /* Last byte has been put in TX, set up TXC interrupt */
            EUSART_IntDisable(obj->serial.periph.uart, EUSART_IEN_TXFL);
            EUSART_IntEnable(obj->serial.periph.uart, EUSART_IEN_TXC);
        }
    } else if (obj->serial.periph.uart->IF & EUSART_IF_TXC) {
        /* Last byte has been successfully transmitted. Stop the procedure */
        serial_tx_abort_asynch_intern(obj, 1);
        return SERIAL_EVENT_TX_COMPLETE & obj->serial.events;
    }
    return 0;
}

/** The asynchronous RX handler. Reads from the RX FIFOF and checks for events.
 *  If any RX event has occured, the RX abort function is called.
 *
 * @param obj The serial object
 * @return Returns event flags if a RX transfer termination condition was met or 0 otherwise
 */
static int serial_rx_irq_handler_asynch(serial_t *obj)
{
    int event = 0;

    /* This interrupt handler is called from USART irq */
    uint8_t *buf = (uint8_t*)obj->rx_buff.buffer;

    /* Determine the source of the interrupt */
    if(EUSART_IntGetEnabled(obj->serial.periph.uart) & EUSART_IF_PERR) {
        /* Parity error has occurred, and we are notifying. */
        EUSART_IntClear(obj->serial.periph.uart, EUSART_IF_PERR);
        serial_rx_abort_asynch_intern(obj, 1);
        return SERIAL_EVENT_RX_PARITY_ERROR;
    }

    if(EUSART_IntGetEnabled(obj->serial.periph.uart) & EUSART_IF_FERR) {
        /* Framing error has occurred, and we are notifying */
        EUSART_IntClear(obj->serial.periph.uart, EUSART_IF_FERR);
        serial_rx_abort_asynch_intern(obj, 1);
        return SERIAL_EVENT_RX_FRAMING_ERROR;
    }

    if(EUSART_IntGetEnabled(obj->serial.periph.uart) & EUSART_IF_RXOF) {
        /* RX buffer overflow has occurred, and we are notifying */
        EUSART_IntClear(obj->serial.periph.uart, EUSART_IF_RXOF);
        serial_rx_abort_asynch_intern(obj, 1);
        return SERIAL_EVENT_RX_OVERFLOW;
    }

    if((EUSART_IntGetEnabled(obj->serial.periph.uart) & EUSART_IF_RXFL) || (EUSART_StatusGet(obj->serial.periph.uart) & EUSART_STATUS_RXFULL)) {
        /* Valid data in buffer. Determine course of action: continue receiving or interrupt */
        if(obj->rx_buff.pos >= (obj->rx_buff.length - 1)) {
            /* Last char, transfer complete. Switch off interrupt and return event. */
            buf[obj->rx_buff.pos] = (uint8_t)(obj->serial.periph.uart->RXDATA);

            event |= SERIAL_EVENT_RX_COMPLETE;

            if((buf[obj->rx_buff.pos] == obj->char_match) && (obj->serial.events & SERIAL_EVENT_RX_CHARACTER_MATCH)) event |= SERIAL_EVENT_RX_CHARACTER_MATCH;

            serial_rx_abort_asynch_intern(obj, 1);
            return event & obj->serial.events;
        } else {
            /* There's still space in the receive buffer */
            while(((EUSART_StatusGet(obj->serial.periph.uart) & EUSART_STATUS_RXFL) || (EUSART_StatusGet(obj->serial.periph.uart) & EUSART_IF_RXFULL)) && (obj->rx_buff.pos <= (obj->rx_buff.length - 1))) {
                bool aborting = false;
                buf[obj->rx_buff.pos] = (uint8_t)(obj->serial.periph.uart->RXDATA);
                obj->rx_buff.pos++;

                /* Check for character match event */
                if((buf[obj->rx_buff.pos - 1] == obj->char_match) && (obj->serial.events & SERIAL_EVENT_RX_CHARACTER_MATCH)) {
                    aborting = true;
                    event |= SERIAL_EVENT_RX_CHARACTER_MATCH;
                }

                /* Check for final char event */
                if(obj->rx_buff.pos >= (obj->rx_buff.length)) {
                    aborting = true;
                    event |= SERIAL_EVENT_RX_COMPLETE & obj->serial.events;
                }

                if(aborting) {
                    serial_rx_abort_asynch_intern(obj, 1);
                    return event & obj->serial.events;
                }
            }
        }
    }

    /* All events should have generated a return, if no return has happened, no event has been caught */
    return 0;
}

/** Unified IRQ handler. Determines the appropriate handler to execute and returns the flags.
 *
 * WARNING: this code should be stateless, as re-entrancy is very possible in interrupt-based mode.
 */
int serial_irq_handler_asynch(serial_t *obj)
{
    uint32_t txc_int;

    txc_int = EUSART_IntGetEnabled(obj->serial.periph.uart) & EUSART_IF_TXC;

    /* First, check if we're running in DMA mode */
    if( (obj->serial.dmaOptionsRX.dmaChannel != -1) &&
        serial_dma_irq_fired[obj->serial.dmaOptionsRX.dmaChannel]) {
        /* Clean up */
        serial_dma_irq_fired[obj->serial.dmaOptionsRX.dmaChannel] = false;
        serial_rx_abort_asynch_intern(obj, 1);

        /* Notify CPP land of RX completion */
        return SERIAL_EVENT_RX_COMPLETE & obj->serial.events;
    } else if (txc_int && (obj->serial.dmaOptionsTX.dmaChannel != -1) &&
               serial_dma_irq_fired[obj->serial.dmaOptionsTX.dmaChannel]) {
        /* Clean up */
        serial_dma_irq_fired[obj->serial.dmaOptionsTX.dmaChannel] = false;
        serial_tx_abort_asynch_intern(obj, 1);
        /* Notify CPP land of completion */
        return SERIAL_EVENT_TX_COMPLETE & obj->serial.events;
    } else {
        /* Check the NVIC to see which interrupt we're running from
         * Also make sure to prioritize RX */
        if(EUSART_IntGetEnabled(obj->serial.periph.uart) & (EUSART_IF_RXFL | EUSART_IF_RXOF | EUSART_IF_PERR | EUSART_IF_FERR)) {
            return serial_rx_irq_handler_asynch(obj);
        } else if(EUSART_StatusGet(obj->serial.periph.uart) & (EUSART_STATUS_TXFL | EUSART_STATUS_TXC)){
            return serial_tx_irq_handler_asynch(obj);
        }
    }

    // All should be done now
    return 0;
}

/** Abort the ongoing TX transaction. It disables the enabled interupt for TX and
 *  flush TX hardware buffer if TX FIFO is used
 *
 * @param obj The serial object
 */
void serial_tx_abort_asynch(serial_t *obj)
{
    serial_tx_abort_asynch_intern(obj, 0);
}

static void serial_tx_abort_asynch_intern(serial_t *obj, int unblock_sleep)
{
    // Transmitter should be disabled here but there are multiple issues
    // making that quite difficult.
    //
    // - Disabling the transmitter when using DMA on platforms prior to
    //   Pearl can cause the UART to leave the line low, generating a break
    //   condition until the next transmission begins.
    //
    // - On (at least) Pearl, once TXC interrupt has fired it will take some time
    //   (some tens of microsec) for TXC to be set in STATUS. If we turn off
    //   the transmitter before this, bad things will happen.
    //
    // - On (at least) Pearl, when using TX DMA it is possible for the USART
    //   status to be: TXENS TXBL TXIDLE = 1, TXBUFCNT = 0, but TXC = 0.
    //
    // All in all, the logic was so fragile it's best to leave it out.

    /* Clean up */
    switch(obj->serial.dmaOptionsTX.dmaUsageState) {
        case DMA_USAGE_ALLOCATED:
            /* stop DMA transfer */
            LDMA_StopTransfer(obj->serial.dmaOptionsTX.dmaChannel);
            break;
        case DMA_USAGE_TEMPORARY_ALLOCATED:
            /* stop DMA transfer and release channel */
            LDMA_StopTransfer(obj->serial.dmaOptionsTX.dmaChannel);
            dma_channel_free(obj->serial.dmaOptionsTX.dmaChannel);
            obj->serial.dmaOptionsTX.dmaChannel = -1;
            obj->serial.dmaOptionsTX.dmaUsageState = DMA_USAGE_OPPORTUNISTIC;
            break;
        default:
            break;
    }

    /* stop interrupting */
    EUSART_IntDisable(obj->serial.periph.uart, EUSART_IEN_TXFL);
    EUSART_IntDisable(obj->serial.periph.uart, EUSART_IEN_TXC);
    EUSART_IntClear(obj->serial.periph.uart, EUSART_IF_TXC);

    /* Say that we can stop using this emode */
    if(unblock_sleep)
        serial_unblock_sleep(obj);
}


static void serial_unblock_sleep(serial_t *obj)
{
    if( obj->serial.sleep_blocked > 0 ) {
        sleep_manager_unlock_deep_sleep();
        obj->serial.sleep_blocked--;
    }
}

static void serial_block_sleep(serial_t *obj)
{
    obj->serial.sleep_blocked++;
    sleep_manager_lock_deep_sleep();
}

/** Abort the ongoing RX transaction It disables the enabled interrupt for RX and
 *  flush RX hardware buffer if RX FIFO is used
 *
 * @param obj The serial object
 */
void serial_rx_abort_asynch(serial_t *obj)
{
    serial_rx_abort_asynch_intern(obj, 0);
}

static void serial_rx_abort_asynch_intern(serial_t *obj, int unblock_sleep)
{
    /* Stop receiver */
    obj->serial.periph.uart->CMD = EUSART_CMD_RXDIS;

    /* Clean up */
    switch(obj->serial.dmaOptionsRX.dmaUsageState) {
        case DMA_USAGE_ALLOCATED:
            /* stop DMA transfer */
            LDMA_StopTransfer(obj->serial.dmaOptionsRX.dmaChannel);
            break;
        case DMA_USAGE_TEMPORARY_ALLOCATED:
            /* stop DMA transfer and release channel */
            LDMA_StopTransfer(obj->serial.dmaOptionsRX.dmaChannel);
            dma_channel_free(obj->serial.dmaOptionsRX.dmaChannel);
            obj->serial.dmaOptionsRX.dmaChannel = -1;
            obj->serial.dmaOptionsRX.dmaUsageState = DMA_USAGE_OPPORTUNISTIC;
            break;
        default:
            /* stop interrupting */
            EUSART_IntDisable(obj->serial.periph.uart, EUSART_IEN_RXFL | EUSART_IEN_PERR | EUSART_IEN_FERR | EUSART_IEN_RXOF);
            break;
    }

    /*clear all set interrupts*/
    EUSART_IntClear(obj->serial.periph.uart,  EUSART_IF_PERR | EUSART_IF_FERR | EUSART_IF_RXOF);

    /* Say that we can stop using this emode */
    if( unblock_sleep )
        serial_unblock_sleep(obj);
}

#endif //DEVICE_SERIAL_ASYNCH
#endif //DEVICE_SERIAL
