#include "pinmap_custom.h"
#include "platform/mbed_error.h"
#include "PeripheralPins.h"

bool pinmap_get_peripheral_availability(uint32_t peripheral) {
    int i = 0;
    while (periph_availability[i].periph != NC) {
        if ((uint32_t)periph_availability[i].periph == peripheral) {
            return periph_availability[i].used;
        }
        i++;
    }
    return false;
}

void pinmap_set_peripheral_availability(uint32_t peripheral, bool used) {
    int i = 0;
    while (periph_availability[i].periph != NC) {
        if ((uint32_t)periph_availability[i].periph == peripheral) {
            periph_availability[i].used = used;
            return;
        }
        i++;
    }
}

uint32_t pinmap_find_peripheral_with_exclusion(PinName pin, const PinMap *map)
{
    while (map->pin != NC) {
        if (map->pin == pin && !pinmap_get_peripheral_availability(map->peripheral)) {
            return map->peripheral;
        }
        map++;
    }
    return (uint32_t)NC;
}

uint32_t pinmap_peripheral_with_exclusion(PinName pin, const PinMap *map)
{
    uint32_t peripheral = (uint32_t)NC;

    if (pin == (PinName)NC) {
        return (uint32_t)NC;
    }
    peripheral = pinmap_find_peripheral_with_exclusion(pin, map);
    if ((uint32_t)NC == peripheral) { // no mapping available
        MBED_ERROR1(MBED_MAKE_ERROR(MBED_MODULE_PLATFORM, MBED_ERROR_CODE_PINMAP_INVALID), "pinmap not found for peripheral", pin);
    }
    return peripheral;
}