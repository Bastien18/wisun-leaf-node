/***************************************************************************//**
 * @file watchdog_api.c
 *******************************************************************************
 * @section License
 * <b>(C) Copyright 2018 Silicon Labs, http://www.silabs.com</b>
 * <b>(C) Copyright 2023 Yann Charbon, yann.charbon@ik.me</b>
 *******************************************************************************
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ******************************************************************************/

#include "device.h"
#include "watchdog_api.h"

#if DEVICE_WATCHDOG

#include "clocking.h"
#include "em_cmu.h"
#include "em_wdog.h"

watchdog_status_t hal_watchdog_init(const watchdog_config_t *config)
{
    watchdog_features_t feat = hal_watchdog_get_platform_features();

    if (config == 0 || config->timeout_ms > feat.max_timeout || config->timeout_ms == 0) {
        return WATCHDOG_STATUS_INVALID_ARGUMENT;
    }

    CMU_ClockEnable(cmuClock_WDOG0, true);

    // For calculus, see WDOG Clock source in EFR32FG25 reference manual
    uint32_t f = CMU_ClockFreqGet(cmuClock_WDOG0);
    uint32_t wait_cycles = (config->timeout_ms * f) / 1000;
    uint32_t result = 0;
    // Computing log2
    while (wait_cycles >>= 1) result++;
    result -= 3;

    if (result > wdogPeriod_128k) {
        result = wdogPeriod_128k;
    }

    WDOG_Init_TypeDef wdog_init = WDOG_INIT_DEFAULT;
    wdog_init.em2Run = true;
    wdog_init.em3Run = true;
    wdog_init.perSel = result;

    WDOGn_Init(DEFAULT_WDOG, &wdog_init);

    return WATCHDOG_STATUS_OK;
}

void hal_watchdog_kick(void)
{
    WDOGn_Feed(DEFAULT_WDOG);
}

watchdog_status_t hal_watchdog_stop(void)
{
    WDOGn_Enable(DEFAULT_WDOG, false);
    return WATCHDOG_STATUS_OK;
}

uint32_t hal_watchdog_get_reload_value(void)
{
    uint32_t period = (DEFAULT_WDOG->CFG & _WDOG_CFG_PERSEL_MASK) >> _WDOG_CFG_PERSEL_SHIFT;
    if (period == 0) {
        return 9;
    } else {
        period += 3;
        return (1U << period) + 1;
    }
}

watchdog_features_t hal_watchdog_get_platform_features(void)
{
    uint32_t f = CMU_ClockFreqGet(cmuClock_WDOG0);
    uint32_t max = ((1 << (wdogPeriod_128k + 3)) + 1) * 1000 / f;

    watchdog_features_t feat = {
        .max_timeout = max,
        .update_config = true,
        .disable_watchdog = true,
        .clock_typical_frequency = f,
        .clock_max_frequency = f
    };
    return feat;
}

#endif /* DEVICE_WATCHDOG */
