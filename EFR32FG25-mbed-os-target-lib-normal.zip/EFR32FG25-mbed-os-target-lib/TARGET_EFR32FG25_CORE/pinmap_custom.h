#ifndef PINMAP_CUSTOM_H
#define PINMAP_CUSTOM_H


#include "PinNames.h"
#include "pinmap.h"

#ifdef __cplusplus
extern "C" {
#endif

bool pinmap_get_peripheral_availability(uint32_t peripheral);
void pinmap_set_peripheral_availability(uint32_t peripheral, bool used);
uint32_t pinmap_find_peripheral_with_exclusion(PinName pin, const PinMap *map);
uint32_t pinmap_peripheral_with_exclusion(PinName pin, const PinMap *map);

#ifdef __cplusplus
}
#endif

#endif /*PINMAP_CUSTOM_H*/