/***************************************************************************//**
 * @file trng_api.c
 *******************************************************************************
 * @section License
 * <b>(C) Copyright 2023 Yann Charbon, https://www.linkedin.com/in/yann-charbon/</b>
 * <b>(C) Copyright 2017 Silicon Labs, http://www.silabs.com</b>
 *******************************************************************************
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ******************************************************************************/

#include "trng_api.h"
#include "em_se.h"
#include "sl_status.h"
#include "em_device.h"
#include <string.h>

#if DEVICE_TRNG

#define se_command_init(command, command_word) \
  command->command = command_word;         \
  command->data_in = NULL;                 \
  command->data_out = NULL;                \
  command->num_parameters = 0;


sl_status_t sl_se_get_random(SE_Command_t *command,
                             void * data,
                             uint32_t num_bytes);

static bool is_trng_enabled = false;
static SE_Response_t se_command_response;

void trng_init(trng_t *obj){
    (void) obj;

    if(!is_trng_enabled) {
        CMU_ClockEnable(cmuClock_SEMAILBOX, true);

        is_trng_enabled = true;
    }
}

void trng_free(trng_t *obj){
    /* Don't turn off the TRNG to avoid clearing its FIFO */
    (void) obj;
}

int trng_get_bytes(trng_t *obj, uint8_t *output, size_t length, size_t *output_length){
    SE_Command_t command;
    int ret = (int)sl_se_get_random(&command, output, length);
    *output_length = length;
    return (ret == 0) ? 0 : -1;
}

sl_status_t se_execute_and_wait(SE_Command_t *command){
    SE_executeCommand(command);
    SE_waitCommandCompletion();
    se_command_response = SE_readCommandResponse();

    if (se_command_response == 0) {
        return SL_STATUS_OK;
    } else {
        return SL_STATUS_FAIL;
    }
}

sl_status_t sl_se_get_random(SE_Command_t *command,
                             void * data,
                             uint32_t num_bytes) {
    sl_status_t ret;
    uint32_t surplus_bytes, i;
    uint32_t surplus_word = 0;

    if (command == NULL || (num_bytes != 0 && data == NULL)) {
        return SL_STATUS_INVALID_PARAMETER;
    }

    surplus_bytes = num_bytes & 0x3U;
    num_bytes &= ~0x3U;

    if (num_bytes > 0U) {
        se_command_init(command, SE_COMMAND_TRNG_GET_RANDOM);
        SE_DataTransfer_t data_out = SE_DATATRANSFER_DEFAULT(data, num_bytes);

        SE_addDataOutput(command, &data_out);
        SE_addParameter(command, num_bytes);

        // Execute and wait
        if ((ret = se_execute_and_wait(command)) != SL_STATUS_OK) {
            memset(data, 0, num_bytes);
            return ret;
        }
    }

    if (surplus_bytes > 0) {
        se_command_init(command, SE_COMMAND_TRNG_GET_RANDOM);
        SE_DataTransfer_t data_out = SE_DATATRANSFER_DEFAULT(&surplus_word, 4);

        SE_addDataOutput(command, &data_out);
        SE_addParameter(command, 4);

        // Execute and wait
        if ((ret = se_execute_and_wait(command)) != SL_STATUS_OK) {
            memset(data, 0, num_bytes + surplus_bytes);
            return ret;
        }

        uint8_t *output = (uint8_t*)data + num_bytes;
        for (i = 0; i < surplus_bytes; i++) {
            output[i] = (surplus_word >> (i * 8U)) & 0xFFU;
        }
    }

    return SL_STATUS_OK;
}
#endif /* DEVICE_TRNG */
