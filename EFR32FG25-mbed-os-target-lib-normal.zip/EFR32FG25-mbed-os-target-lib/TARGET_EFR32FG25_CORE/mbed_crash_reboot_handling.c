#if MBED_CONF_PLATFORM_CRASH_CAPTURE_ENABLED
#include "mbed_error.h"
#include "mbed_fault_handler.h"

mbed_error_status_t err_status;

void mbed_error_reboot_callback(mbed_error_ctx *error_context)
{
    err_status = error_context->error_status;
    printf("\n\n(before main) mbed_error_reboot_callback invoked with the following error context:\n");
    printf("    Status      : 0x%lX\n", (uint32_t)error_context->error_status);
    printf("    Value       : 0x%lX\n", (uint32_t)error_context->error_value);
    printf("    Address     : 0x%lX\n", (uint32_t)error_context->error_address);
    printf("    Reboot count: 0x%lX\n", (uint32_t)error_context->error_reboot_count);
    printf("    CRC         : 0x%lX\n", (uint32_t)error_context->crc_error_ctx);

    mbed_reset_reboot_error_info();
}

#endif