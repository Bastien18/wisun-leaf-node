/***************************************************************************//**
 * @file us_ticker.c
 *******************************************************************************
 * @section License
 * <b>(C) Copyright 2016 Silicon Labs, http://www.silabs.com</b>
 *******************************************************************************
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ******************************************************************************/

#include <stddef.h>
#include "us_ticker_api.h"
#include "device.h"
#include "mbed_assert.h"
#include "em_cmu.h"
#include "em_timer.h"
#include "clocking.h"

/* us ticker */
#define US_TICKER_TIMER         TIMER0
#define US_TICKER_TIMER_CLOCK   cmuClock_TIMER0
#define US_TICKER_TIMER_IRQ     TIMER0_IRQn

static ticker_info_t info = {
    0,  // 0 Hz
    16  // 16 bits
};

const ticker_info_t* us_ticker_get_info(void)
{
    uint32_t freq = CMU_ClockFreqGet(US_TICKER_TIMER_CLOCK);
    if (freq > 24000000) {
        info.frequency = CMU_ClockFreqGet(US_TICKER_TIMER_CLOCK) / 16;
    } else {
        info.frequency = CMU_ClockFreqGet(US_TICKER_TIMER_CLOCK) / 8;
    }
    return &info;
}

static bool us_ticker_inited = false;            // Is ticker initialized yet

void us_ticker_init(void)
{
    if (us_ticker_inited) {
        /* calling init again should cancel current interrupt */
        us_ticker_disable_interrupt();
        return;
    }
    us_ticker_inited = true;

    /* Enable clock for TIMERs */
    CMU_ClockEnable(US_TICKER_TIMER_CLOCK, true);

    uint32_t freq = CMU_ClockFreqGet(US_TICKER_TIMER_CLOCK);

    TIMER_Init_TypeDef timerInit = TIMER_INIT_DEFAULT;
    timerInit.enable = false;
    if (freq > 24000000) {
        timerInit.prescale = timerPrescale16;
    } else {
        timerInit.prescale = timerPrescale8;
    }

    /* Select Compare Channel parameters */
    TIMER_InitCC_TypeDef timerCCInit = TIMER_INITCC_DEFAULT;
    timerCCInit.mode = timerCCModeCompare;

    TIMER_Init(TIMER0, &timerInit);

    /* Configure Compare Channel 0 */
    TIMER_InitCC(US_TICKER_TIMER, 0, &timerCCInit);

    /* Enable interrupt vector in NVIC */
    TIMER_IntClear(US_TICKER_TIMER, TIMER_IF_CC0);
    NVIC_SetVector(US_TICKER_TIMER_IRQ, (uint32_t) us_ticker_irq_handler);
    NVIC_EnableIRQ(US_TICKER_TIMER_IRQ);

    /* Start TIMER */
    TIMER_Enable(US_TICKER_TIMER, true);

    /* Clear TIMER counter value */
    TIMER_CounterSet(US_TICKER_TIMER, 0);
}

void us_ticker_free(void)
{
    if (us_ticker_inited) {
        us_ticker_disable_interrupt();
        NVIC_DisableIRQ(US_TICKER_TIMER_IRQ);

        TIMER_Enable(US_TICKER_TIMER, false);

        CMU_ClockEnable(US_TICKER_TIMER_CLOCK, false);

        us_ticker_inited = false;
    }
}

uint32_t us_ticker_read()
{
    if (!us_ticker_inited) {
        us_ticker_init();
    }

    return US_TICKER_TIMER->CNT;
}

void us_ticker_set_interrupt(timestamp_t timestamp)
{
    TIMER_IntDisable(US_TICKER_TIMER, TIMER_IF_CC0);

    TIMER_IntClear(US_TICKER_TIMER, TIMER_IF_CC0);

    TIMER_CompareSet(US_TICKER_TIMER, 0, timestamp);

    TIMER_IntEnable(US_TICKER_TIMER, TIMER_IF_CC0);
}

void us_ticker_fire_interrupt(void)
{
    NVIC_SetPendingIRQ(US_TICKER_TIMER_IRQ);
}

void us_ticker_disable_interrupt(void)
{
    /* Disable compare channel interrupts */
    TIMER_IntDisable(US_TICKER_TIMER, TIMER_IF_CC0);
}

void us_ticker_clear_interrupt(void)
{
    /* Clear compare channel interrupts */
    TIMER_IntClear(US_TICKER_TIMER, TIMER_IF_CC0);
}
