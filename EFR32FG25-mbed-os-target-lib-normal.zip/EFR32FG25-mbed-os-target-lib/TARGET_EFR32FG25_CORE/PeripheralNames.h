// OKAY

/***************************************************************************//**
 * @file PeripheralNames.h
 *******************************************************************************
 * @section License
 * <b>(C) Copyright 2015 Silicon Labs, http://www.silabs.com</b>
 *******************************************************************************
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ******************************************************************************/
#ifndef MBED_PERIPHERALNAMES_H
#define MBED_PERIPHERALNAMES_H

#include "em_adc.h"
#include "em_usart.h"
#include "em_i2c.h"

#ifdef __cplusplus
extern "C" {
#endif

#if DEVICE_ANALOGIN
typedef enum {
#ifdef IADC0_BASE
    ADC_0 = IADC0_BASE,
#endif
} ADCName;
#endif

#if DEVICE_ANALOGOUT
typedef enum {
#ifdef VDAC0_BASE
    DAC_0 = VDAC0_BASE,
#endif
} DACName;
#endif

#if DEVICE_I2C
typedef enum {
#ifdef I2C0_BASE
    I2C_0 = I2C0_BASE,
#endif
#ifdef I2C1_BASE
    I2C_1 = I2C1_BASE,
#endif
#ifdef I2C2_BASE
    I2C_2 = I2C2_BASE,
#endif
} I2CName;
#endif

#if DEVICE_SPI
typedef enum {
#ifdef EUSART0_BASE
    SPI_0 = EUSART0_BASE,
#endif
#ifdef EUSART1_BASE
    SPI_1 = EUSART1_BASE,
#endif
#ifdef EUSART2_BASE
    SPI_2 = EUSART2_BASE,
#endif
#ifdef EUSART3_BASE
    SPI_3 = EUSART3_BASE,
#endif
#ifdef EUSART4_BASE
    SPI_4 = EUSART4_BASE,
#endif
} SPIName;
#endif

#if DEVICE_SERIAL
typedef enum {
#ifdef EUSART0_BASE
    USART_0 = EUSART0_BASE,
#endif
#ifdef EUSART1_BASE
    USART_1 = EUSART1_BASE,
#endif
#ifdef EUSART2_BASE
    USART_2 = EUSART2_BASE,
#endif
#ifdef EUSART3_BASE
    USART_3 = EUSART3_BASE,
#endif
#ifdef EUSART4_BASE
    USART_4 = EUSART4_BASE,
#endif
} UARTName;
#endif

#ifdef __cplusplus
}
#endif

#endif
