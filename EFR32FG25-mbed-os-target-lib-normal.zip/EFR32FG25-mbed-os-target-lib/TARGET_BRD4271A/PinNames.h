/***************************************************************************//**
 * @file PinNames.h
 *******************************************************************************
 * @section License
 * <b>(C) Copyright 2015 Silicon Labs, http://www.silabs.com</b>
 *******************************************************************************
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ******************************************************************************/

/* MBED TARGET LIST: TB_SENSE_12 */

#ifndef MBED_PINNAMES_H
#define MBED_PINNAMES_H

#include "CommonPinNames.h"

#ifdef __cplusplus
extern "C" {
#endif

#define EFR32_CUSTOM_BOARD

typedef enum {
    EFM32_STANDARD_PIN_DEFINITIONS,

    /* Starter Kit says LED0 and LED1, but mbed expects 1 and 2. This way using 1 and 2 or 0 and 1 will work. */
    LED0 = PC6,
    LED1 = PC7,
    LED2 = LED0,
    LED3 = LED0,
    LED4 = LED1,

    /* Push Buttons */
    SW0 = PB0,
    SW1 = PB1,
    BTN0 = SW0,
    BTN1 = SW1,
    // Standardized button names
    BUTTON1 = BTN0,
    BUTTON2 = BTN1,

    /* Expansion headers */
    EXP3  = PA10,
    EXP4  = PC0,
    EXP5  = PA0,
    EXP6  = PC1,
    EXP7  = PA5,
    EXP8  = PC2,
    EXP10 = PB4,
    EXP11 = PA6,
    EXP12 = PA8,
    EXP13 = PA7,
    EXP14 = PA9,
    EXP15 = PB2,
    EXP16 = PB3,

    ETH_SCLK = EXP7, //D13
    ETH_MISO = EXP11,    //D12
    ETH_MOSI = EXP13,    //D11
    ETH_CSn = EXP15,  //D10
    ETH_RSTn = EXP3,
    ETH_INTn = EXP10,

    /* Serial (just some usable pins) */
    //SERIAL_TX   = PA6,
    //SERIAL_RX   = PA7,

    /* Board Controller UART (USB)*/
    CONSOLE_TX       = PA8,
    CONSOLE_RX       = PA9,
    ENABLE_VCOM      = PA11,

    /* Board Controller */
#if defined(MBED_CONF_TARGET_STDIO_UART_TX)
    STDIO_UART_TX   = MBED_CONF_TARGET_STDIO_UART_TX,
#else
    STDIO_UART_TX   = CONSOLE_TX,
#endif
#if defined(MBED_CONF_TARGET_STDIO_UART_RX)
    STDIO_UART_RX   = MBED_CONF_TARGET_STDIO_UART_RX,
#else
    STDIO_UART_RX   = CONSOLE_RX
#endif
} PinName;

#ifdef __cplusplus
}
#endif

#endif
