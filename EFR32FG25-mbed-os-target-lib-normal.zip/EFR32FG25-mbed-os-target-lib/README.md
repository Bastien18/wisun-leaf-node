# EFR32FG25 porting with SL RAIL support

The library offers support for EFR32FG25 SoC include RAIL radio transceiver.

Here is a list of the currently supported features:

- DMA API
- GPIO API
- GPIO IRQ API
- Low-power ticker
- Microseconds ticker
- Serial API
- SPI API
- True random generator API
- Watchdog API
- NanostackRfPhy driver with IEEE 802.15.4-2015+ support only (also known as *extended* driver, no internal ACK support)
    - This driver offers full support of Wi-SUN 1.0
    - Wi-SUN 1.1 with OFDM support is in early-development stage

Here is a list of missing features:

- Analog input API
- CAN bus API
- Flash management API
- I2C API
- PWM output API
- QSPI API


# Extra features

## Handling error and auto-reboot

If you want to automatically handle auto system restart when Mbed OS crashes, you must add the following content to the `mbed_app.json` of your project.

```
"platform.crash-capture-enabled": true,
"platform.fatal-error-auto-reboot-enabled": true
```

By default, the error handler for this target is the `mbed_error_reboot_callback()` function in the `mbed_crash_reboot_handling.c` file of the TARGET_EFR32FG25.

## Changing offset of application

If you want to use a bootloader, you can adjust the main application base address by adding the following content to the `mbed_app.json` of your project.

```
"target.mbed_app_start": "0x08000000"
```

# Mbed OS / application required modifications

## When using Mbed CLI 1

As SL RAIL API library is precompiled with hard float flag, the `mbed-os/tools/toolchains/gcc.py` file must be modified to allow using SL RAIL API. Here is the content that must be changed. RAIL API library requires `SL_TRUSTZONE_SECURE` and `SL_TRUSTZONE_NONSECURE` to be undefined and `__ARM_FEATURE_CMSE` to be defined. **NOTE**: This is only required if using Mbed CLI 1 as Mbed CLI 2 applies automatically the correct flags using CMake.
```
+++ solarstratos/solarstratos-endpoint-emac/mbed-os/tools/toolchains/gcc.py	2023-09-04 15:18:30.163820531 +0200
@@ -124,9 +124,13 @@
         if core == "Cortex-M4F":
             self.cpu.append("-mfpu=fpv4-sp-d16")
             self.cpu.append("-mfloat-abi=softfp")
-        elif core == "Cortex-M7F" or core.startswith("Cortex-M33F"):
+        elif core == "Cortex-M7F":
             self.cpu.append("-mfpu=fpv5-sp-d16")
             self.cpu.append("-mfloat-abi=softfp")
+        elif core.startswith("Cortex-M33F"):
+            self.cpu.append("-mfpu=fpv5-sp-d16")
+            self.cpu.append("-mfloat-abi=hard")
+            self.cpu.append("-mcmse")
         elif core == "Cortex-M7FD":
             self.cpu.append("-mfpu=fpv5-d16")
             self.cpu.append("-mfloat-abi=softfp")

```

## When using Mbed CLI 2

No modification of the Mbed OS source code is required. The application must be told to include the current library using CMake. The `CMakeLists.txt` file of the root of the application must be completed with the following content.
```
project(${APP_TARGET})
....
add_subdirectory(${MBED_PATH})
add_subdirectory(EFR32FG25-mbed-os-target-lib EXCLUDE_FROM_ALL)
....
add_executable(${APP_TARGET})
```

# How to add a custom board

A custom board must at minimum contain a `PinNames.h` file containing the GPIO mappings that must be used. It can also contain some additional code or header files depending on what the board requires.

## With Mbed CLI 1

- Create a new target called `<name>` in `custom_targets.json` that inherits `EFR32FG25B222F1920IM56`.
- Create a folder called `TARGET_<name>` at the root folder of this project.


## With Mbed CLI 2

- Create a new target called `<name>` in `custom_targets.json` that inherits `EFR32FG25B222F1920IM56`.
- Create a folder called `TARGET_<name>` at the root folder of this project.
- Create a `CMakeLists.txt` file within the `TARGET_<name>` folder with the following content (please fill the missing elements).
```
add_library(mbed-<name> INTERFACE)

target_include_directories(mbed-<name>
    INTERFACE
        .
)

#target_sources(mbed-<name>
#    INTERFACE
#        # some files
#)

target_link_libraries(mbed-<name> INTERFACE mbed-efr32fg25)
```
- Tell CMake that this new board exists by adding `add_subdirectory(TARGET_<name> EXCLUDE_FROM_ALL)` in the `CMakeLists.txt` located at the root of this project.