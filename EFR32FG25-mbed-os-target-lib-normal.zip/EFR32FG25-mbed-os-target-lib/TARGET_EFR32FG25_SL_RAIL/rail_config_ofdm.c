/***************************************************************************//**
 * @brief RAIL Configuration
 * @details
 *   WARNING: Auto-Generated Radio Config  -  DO NOT EDIT
 *   Radio Configurator Version: 2302.5.1
 *   RAIL Adapter Version: 2.4.31
 *   RAIL Compatibility: 2.x
 *******************************************************************************
 * # License
 * <b>Copyright 2019 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * SPDX-License-Identifier: Zlib
 *
 * The licensor of this software is Silicon Laboratories Inc.
 *
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 *
 ******************************************************************************/
#include "em_device.h"
#include "rail_config.h"
#include "rail_config_ofdm.h"

static const uint8_t irCalConfig[] = {
  20, 41, 2, 0, 0, 57, 19, 0, 0, 0, 1, 0, 2, 100, 0, 1, 1, 47, 0, 0, 7
};

static const uint8_t txIrCalConfig[5] = {
  0x00, 0x03, 5, 5, 5
};

static const int32_t timingConfig_0[] = {
  5250, 5250, 0
};

static const int32_t timingConfig_1[] = {
  10500, 10500, 0
};

static const int32_t timingConfig_2[] = {
  18000, 18000, 0
};

static const int32_t timingConfig_3[] = {
  42000, 42000, 0
};

static const uint8_t hfxoRetimingConfigEntries[] = {
  1, 0, 0, 0, 0xc0, 0x17, 0x53, 0x02, 4, 12, 0, 0, 0xe0, 0x02, 0, 0, 0, 0, 0x3c, 0x03, 1, 2, 5, 4, 0x98, 0x03, 1, 2, 5, 5, 0xf4, 0x03, 1, 2, 6, 5
};

static RAIL_ChannelConfigEntryAttr_t channelConfigEntryAttr = {
#if RAIL_SUPPORTS_OFDM_PA
  {
#ifdef RADIO_CONFIG_ENABLE_IRCAL_MULTIPLE_RF_PATHS
    { 0xFFFFFFFFUL, 0xFFFFFFFFUL, },
#else
    { 0xFFFFFFFFUL },
#endif // RADIO_CONFIG_ENABLE_IRCAL_MULTIPLE_RF_PATHS
    { 0xFFFFFFFFUL, 0xFFFFFFFFUL }
  }
#else // RAIL_SUPPORTS_OFDM_PA
#ifdef RADIO_CONFIG_ENABLE_IRCAL_MULTIPLE_RF_PATHS
  { 0xFFFFFFFFUL, 0xFFFFFFFFUL, },
#else
  { 0xFFFFFFFFUL },
#endif // RADIO_CONFIG_ENABLE_IRCAL_MULTIPLE_RF_PATHS
#endif // RAIL_SUPPORTS_OFDM_PA
};

static const uint32_t phyInfo_0[] = {
  16UL,
  0x00000000UL, // 0.0
  (uint32_t) NULL,
  (uint32_t) irCalConfig,
  (uint32_t) timingConfig_0,
  0x00000000UL,
  0UL,
  0UL,
  8333UL,
  0x00F40130UL,
  0x06105E85UL,
  (uint32_t) NULL,
  (uint32_t) hfxoRetimingConfigEntries,
  (uint32_t) NULL,
  0UL,
  0UL,
  1333333UL,
  (uint32_t) rffpllConfig,
  (uint32_t) txIrCalConfig,
  (uint32_t) NULL,
};

static const uint32_t phyInfo_1[] = {
  16UL,
  0x00000000UL, // 0.0
  (uint32_t) NULL,
  (uint32_t) irCalConfig,
  (uint32_t) timingConfig_1,
  0x00000000UL,
  0UL,
  0UL,
  8333UL,
  0x00F20118UL,
  0x06103F03UL,
  (uint32_t) NULL,
  (uint32_t) hfxoRetimingConfigEntries,
  (uint32_t) NULL,
  0UL,
  0UL,
  666666UL,
  (uint32_t) rffpllConfig,
  (uint32_t) txIrCalConfig,
  (uint32_t) NULL,
};

static const uint32_t phyInfo_2[] = {
  16UL,
  0x00000000UL, // 0.0
  (uint32_t) NULL,
  (uint32_t) irCalConfig,
  (uint32_t) timingConfig_2,
  0x00000000UL,
  0UL,
  0UL,
  8333UL,
  0x00F0010CUL,
  0x06101F81UL,
  (uint32_t) NULL,
  (uint32_t) hfxoRetimingConfigEntries,
  (uint32_t) NULL,
  0UL,
  0UL,
  333333UL,
  (uint32_t) rffpllConfig,
  (uint32_t) txIrCalConfig,
  (uint32_t) NULL,
};

static const uint32_t phyInfo_3[] = {
  16UL,
  0x00000000UL, // 0.0
  (uint32_t) NULL,
  (uint32_t) irCalConfig,
  (uint32_t) timingConfig_3,
  0x00000000UL,
  0UL,
  0UL,
  8333UL,
  0x00F20106UL,
  0x06100FC0UL,
  (uint32_t) NULL,
  (uint32_t) hfxoRetimingConfigEntries,
  (uint32_t) NULL,
  0UL,
  0UL,
  166666UL,
  (uint32_t) rffpllConfig,
  (uint32_t) txIrCalConfig,
  (uint32_t) NULL,
};

static const uint32_t phyInfo_4[] = {
  16UL,
  0x00000000UL, // 0.0
  (uint32_t) NULL,
  (uint32_t) irCalConfig,
  (uint32_t) timingConfig_0,
  0x00000000UL,
  0UL,
  0UL,
  8333UL,
  0x00F20130UL,
  0x06105E85UL,
  (uint32_t) NULL,
  (uint32_t) hfxoRetimingConfigEntries,
  (uint32_t) NULL,
  0UL,
  0UL,
  1333333UL,
  (uint32_t) rffpllConfig,
  (uint32_t) txIrCalConfig,
  (uint32_t) NULL,
};

static const uint32_t phyInfo_5[] = {
  16UL,
  0x00000000UL, // 0.0
  (uint32_t) NULL,
  (uint32_t) irCalConfig,
  (uint32_t) timingConfig_1,
  0x00000000UL,
  0UL,
  0UL,
  8333UL,
  0x00F00118UL,
  0x06103F03UL,
  (uint32_t) NULL,
  (uint32_t) hfxoRetimingConfigEntries,
  (uint32_t) NULL,
  0UL,
  0UL,
  666666UL,
  (uint32_t) rffpllConfig,
  (uint32_t) txIrCalConfig,
  (uint32_t) NULL,
};

static const uint32_t phyInfo_6[] = {
  16UL,
  0x00000000UL, // 0.0
  (uint32_t) NULL,
  (uint32_t) irCalConfig,
  (uint32_t) timingConfig_2,
  0x00000000UL,
  0UL,
  0UL,
  8333UL,
  0x00EE010CUL,
  0x06101F81UL,
  (uint32_t) NULL,
  (uint32_t) hfxoRetimingConfigEntries,
  (uint32_t) NULL,
  0UL,
  0UL,
  333333UL,
  (uint32_t) rffpllConfig,
  (uint32_t) txIrCalConfig,
  (uint32_t) NULL,
};

static const uint32_t phyInfo_7[] = {
  16UL,
  0x00000000UL, // 0.0
  (uint32_t) NULL,
  (uint32_t) irCalConfig,
  (uint32_t) timingConfig_3,
  0x00000000UL,
  0UL,
  0UL,
  8333UL,
  0x00F00106UL,
  0x06100FC0UL,
  (uint32_t) NULL,
  (uint32_t) hfxoRetimingConfigEntries,
  (uint32_t) NULL,
  0UL,
  0UL,
  166666UL,
  (uint32_t) rffpllConfig,
  (uint32_t) txIrCalConfig,
  (uint32_t) NULL,
};

const uint32_t Protocol_OFDM_modemConfigBase[] = {
  0x10018058UL, 0xBF1FF07FUL,
  0x0102400CUL, 0x00000000UL,
  /*    4010 */ 0x00004000UL,
  0x01024020UL, 0x00000001UL,
  /*    4024 */ 0x00000000UL,
  0x01074030UL, 0x00000000UL,
  /*    4034 */ 0x00000000UL,
  /*    4038 */ 0x00000000UL,
  /*    403C */ 0x00000000UL,
  /*    4040 */ 0x00000000UL,
  /*    4044 */ 0x00006000UL,
  /*    4048 */ 0x030407A0UL,
  0x01014050UL, 0x00003F00UL,
  0x0102405CUL, 0x00000000UL,
  /*    4060 */ 0x00000000UL,
  0x010140A8UL, 0x00000007UL,
  0x010440BCUL, 0x00000000UL,
  /*    40C0 */ 0x00000000UL,
  /*    40C4 */ 0x00000000UL,
  /*    40C8 */ 0x00000000UL,
  0x01044108UL, 0x000000FFUL,
  /*    410C */ 0x000000FFUL,
  /*    4110 */ 0x000000FFUL,
  /*    4114 */ 0x000000FFUL,
  0x01014184UL, 0x00000000UL,
  0x1101C020UL, 0x0007F800UL,
  0x3101C020UL, 0x002801FEUL,
  0x0102C028UL, 0x03B380ECUL,
  /*    C02C */ 0x51407543UL,
  0x0105C034UL, 0x00004030UL,
  /*    C038 */ 0x0007AAA8UL,
  /*    C03C */ 0x01001001UL,
  /*    C040 */ 0x00000000UL,
  /*    C044 */ 0x00000000UL,
  0x0102C054UL, 0x00303187UL,
  /*    C058 */ 0xE664002CUL,
  0x0103C060UL, 0x64646425UL,
  /*    C064 */ 0x00000064UL,
  /*    C068 */ 0x00012491UL,
  0x0102C09CUL, 0x3FFF39D0UL,
  /*    C0A0 */ 0x00003FFFUL,
  0x0105C0A8UL, 0x15724BBDUL,
  /*    C0AC */ 0x0518A311UL,
  /*    C0B0 */ 0x76543210UL,
  /*    C0B4 */ 0x00000A98UL,
  /*    C0B8 */ 0x00000000UL,
  0x0103C0D0UL, 0x00000000UL,
  /*    C0D4 */ 0x000A0001UL,
  /*    C0D8 */ 0x00280001UL,
  0x0102C110UL, 0x00010100UL,
  /*    C114 */ 0x000000C8UL,
  0x02010008UL, 0x0000070CUL,
  0x02010018UL, 0x00000000UL,
  0x02010020UL, 0xEDB88320UL,
  0x02024040UL, 0x00000000UL,
  /*    4044 */ 0x00000000UL,
  0x0203404CUL, 0x00000000UL,
  /*    4050 */ 0x0002CA0FUL,
  /*    4054 */ 0x00000000UL,
  0x0203405CUL, 0x03000000UL,
  /*    4060 */ 0x40003000UL,
  /*    4064 */ 0x00000000UL,
  0x0201406CUL, 0x00000440UL,
  0x02194074UL, 0x00000012UL,
  /*    4078 */ 0x00001E6AUL,
  /*    407C */ 0x00001E6AUL,
  /*    4080 */ 0x000C0000UL,
  /*    4084 */ 0x00000000UL,
  /*    4088 */ 0x000F0000UL,
  /*    408C */ 0x60000000UL,
  /*    4090 */ 0x00000000UL,
  /*    4094 */ 0x22130A04UL,
  /*    4098 */ 0x4F4A4132UL,
  /*    409C */ 0x00000000UL,
  /*    40A0 */ 0x00000000UL,
  /*    40A4 */ 0x00000000UL,
  /*    40A8 */ 0x00000000UL,
  /*    40AC */ 0x00000000UL,
  /*    40B0 */ 0x00000000UL,
  /*    40B4 */ 0x00000000UL,
  /*    40B8 */ 0x00000000UL,
  /*    40BC */ 0x00000000UL,
  /*    40C0 */ 0x00000000UL,
  /*    40C4 */ 0x00000000UL,
  /*    40C8 */ 0x00000000UL,
  /*    40CC */ 0x00000000UL,
  /*    40D0 */ 0x00000000UL,
  /*    40D4 */ 0x00000000UL,
  0x020140E0UL, 0x00000281UL,
  0x02074120UL, 0x00000000UL,
  /*    4124 */ 0x078304FFUL,
  /*    4128 */ 0x3AC81388UL,
  /*    412C */ 0x0C6606FFUL,
  /*    4130 */ 0x078304FFUL,
  /*    4134 */ 0x03FF1388UL,
  /*    4138 */ 0xF00A20BCUL,
  0x02054140UL, 0x00000000UL,
  /*    4144 */ 0x123556B7UL,
  /*    4148 */ 0x50000000UL,
  /*    414C */ 0x00003B80UL,
  /*    4150 */ 0x00000000UL,
  0x02024158UL, 0x00000000UL,
  /*    415C */ 0x00000000UL,
  0x02014164UL, 0x0000010CUL,
  0x020B416CUL, 0x40000000UL,
  /*    4170 */ 0x00000000UL,
  /*    4174 */ 0x00000000UL,
  /*    4178 */ 0x00000000UL,
  /*    417C */ 0x00000000UL,
  /*    4180 */ 0x00000000UL,
  /*    4184 */ 0x00000101UL,
  /*    4188 */ 0x00000000UL,
  /*    418C */ 0x00000000UL,
  /*    4190 */ 0x00000000UL,
  /*    4194 */ 0x00000000UL,
  0x020141A4UL, 0x00000000UL,
  0x020C41B0UL, 0x00000000UL,
  /*    41B4 */ 0x00200000UL,
  /*    41B8 */ 0x00000000UL,
  /*    41BC */ 0x00000000UL,
  /*    41C0 */ 0x003C0000UL,
  /*    41C4 */ 0x0006AAAAUL,
  /*    41C8 */ 0x00000000UL,
  /*    41CC */ 0x00000000UL,
  /*    41D0 */ 0x00000000UL,
  /*    41D4 */ 0x00000090UL,
  /*    41D8 */ 0x00020000UL,
  /*    41DC */ 0x00000000UL,
  0x02054224UL, 0x0000001AUL,
  /*    4228 */ 0x00000000UL,
  /*    422C */ 0x00000000UL,
  /*    4230 */ 0x00000000UL,
  /*    4234 */ 0x00000000UL,
  0x0201423CUL, 0x00000000UL,
  0x02034244UL, 0x90000014UL,
  /*    4248 */ 0x00000000UL,
  /*    424C */ 0x04000008UL,
  0x020F4330UL, 0x00000000UL,
  /*    4334 */ 0x00000000UL,
  /*    4338 */ 0x00000000UL,
  /*    433C */ 0x00000000UL,
  /*    4340 */ 0x00000000UL,
  /*    4344 */ 0x00000000UL,
  /*    4348 */ 0x00000000UL,
  /*    434C */ 0x00000000UL,
  /*    4350 */ 0x00000000UL,
  /*    4354 */ 0x00000000UL,
  /*    4358 */ 0x00000000UL,
  /*    435C */ 0x38000000UL,
  /*    4360 */ 0x00000000UL,
  /*    4364 */ 0x00000000UL,
  /*    4368 */ 0x58FF0000UL,
  0x02018010UL, 0x00000003UL,
  0x0201803CUL, 0x00000003UL,
  0x0203809CUL, 0x00000000UL,
  /*    80A0 */ 0x0003B870UL,
  /*    80A4 */ 0x0003B870UL,
  0x120180A8UL, 0x000001F6UL,
  0x320180A8UL, 0x01014201UL,
  0x120180ACUL, 0x000001F6UL,
  0x320180ACUL, 0x01014201UL,
  0x020280B0UL, 0x02000300UL,
  /*    80B4 */ 0x02000300UL,
  0x03030098UL, 0x00000000UL,
  /*    009C */ 0x04000C00UL,
  /*    00A0 */ 0x0000044CUL,
  0x030200D8UL, 0xAA400005UL,
  /*    00DC */ 0x00000188UL,
  0x130100ECUL, 0x00000FE0UL,
  0x330100ECUL, 0x1351200DUL,
  0x030100F0UL, 0x0000052BUL,
  0x03010100UL, 0x00000110UL,
  0x13010104UL, 0x00000000UL,
  0x33010104UL, 0x00000110UL,
  0x13010110UL, 0x000FFF00UL,
  0x33010110UL, 0x52000002UL,
  0x1301012CUL, 0x001FFC00UL,
  0x3301012CUL, 0x008002E9UL,
  0x03010140UL, 0x0000003FUL,
  0x03020168UL, 0x80060010UL,
  /*    016C */ 0x000C0000UL,
  0x03010174UL, 0x01900169UL,
  0x13010178UL, 0x001C0000UL,
  0x33010178UL, 0x1FE00440UL,
  0x13010180UL, 0x00000779UL,
  0x33010180UL, 0x00000006UL,
  0x03020188UL, 0x00000090UL,
  /*    018C */ 0x00000000UL,
  0x030101E4UL, 0x00085220UL,
  0x03010208UL, 0x0020010AUL,
  0x13010400UL, 0x00000008UL,
  0x05120100UL, 0x00000000UL,
  /*    0104 */ 0x00000000UL,
  /*    0108 */ 0x00000000UL,
  /*    010C */ 0x00000000UL,
  /*    0110 */ 0x00000000UL,
  /*    0114 */ 0x00000000UL,
  /*    0118 */ 0x00000000UL,
  /*    011C */ 0x00000000UL,
  /*    0120 */ 0x00000000UL,
  /*    0124 */ 0x00000000UL,
  /*    0128 */ 0x00000000UL,
  /*    012C */ 0x00000000UL,
  /*    0130 */ 0x00000000UL,
  /*    0134 */ 0x00000000UL,
  /*    0138 */ 0x00000000UL,
  /*    013C */ 0x00000000UL,
  /*    0140 */ 0x00000000UL,
  /*    0144 */ 0x00000000UL,
  0x05010180UL, 0x00000000UL,
  0x05020200UL, 0x00000030UL,
  /*    0204 */ 0x00000000UL,
  0x05014144UL, 0x00000000UL,
  0x05014154UL, 0x00002CABUL,
  0x05024200UL, 0x00145463UL,
  /*    4204 */ 0x00000000UL,
  0x05098100UL, 0x000000C6UL,
  /*    8104 */ 0x7FBD7FE4UL,
  /*    8108 */ 0x7F7B7F9BUL,
  /*    810C */ 0x7F517F5EUL,
  /*    8110 */ 0x7FDD7F69UL,
  /*    8114 */ 0x018D009BUL,
  /*    8118 */ 0x03FF02B0UL,
  /*    811C */ 0x06B10569UL,
  /*    8120 */ 0x07F10789UL,
  0x05018128UL, 0x0003AD08UL,
  0x06016FF4UL, 0x00000300UL,
  0x0701FC04UL, 0x0000000AUL,
  0x0701FC04UL, 0x0000000AUL,
  0x0701FC04UL, 0x0000000AUL,
  0x0701FC04UL, 0x0000000AUL,
  0x0702FC04UL, 0x0000000AUL,
  /*    FC08 */ 0x01010000UL,
  0x0701FC08UL, 0x01010000UL,
  0x0701FC08UL, 0x01010000UL,
  0x0701FC08UL, 0x01010000UL,
  0x0701FC08UL, 0x01010000UL,
  0x0702FC10UL, 0x00004E20UL,
  /*    FC14 */ 0x00000015UL,
  0x0702FC1CUL, 0x00000001UL,
  /*    FC20 */ 0x00000000UL,
  0x0701FC58UL, 0x0000009FUL,
  0x0702FC58UL, 0x0000009FUL,
  /*    FC5C */ 0x122816ACUL,
  0x0702FC5CUL, 0x122816ACUL,
  /*    FC60 */ 0xFEBC07DEUL,
  0x0702FC60UL, 0xFEBC07DEUL,
  /*    FC64 */ 0xFDA3FB87UL,
  0x0706FC64UL, 0xFDA3FB87UL,
  /*    FC68 */ 0x020D00F0UL,
  /*    FC6C */ 0xFF1800CAUL,
  /*    FC70 */ 0xFF1FFE8AUL,
  /*    FC74 */ 0x0048FFECUL,
  /*    FC78 */ 0x0013003AUL,
  0x0702FC80UL, 0x00000000UL,
  /*    FC84 */ 0x003100A0UL,
  0x0701FCA8UL, 0x00000000UL,
  0xFFFFFFFFUL,
};

const uint32_t EU1_OFDM_option_1_modemConfig[] = {
  0x06016FFCUL, (uint32_t) &phyInfo_0,
  0x0101C024UL, 0x00002300UL,
  0x0101C030UL, 0xF4000FA0UL,
  0x0101C05CUL, 0x000003C0UL,
  0x010CC06CUL, 0x00000540UL,
  /*    C070 */ 0x000011BAUL,
  /*    C074 */ 0x003F0000UL,
  /*    C078 */ 0x00EE008DUL,
  /*    C07C */ 0x03AC01F6UL,
  /*    C080 */ 0x079604F5UL,
  /*    C084 */ 0x0D9C09DEUL,
  /*    C088 */ 0x179311C3UL,
  /*    C08C */ 0x26F51DFEUL,
  /*    C090 */ 0x3FFF32BDUL,
  /*    C094 */ 0x1BF815FEUL,
  /*    C098 */ 0x2DB423DCUL,
  0x0101C0CCUL, 0x00000000UL,
  0x0101C100UL, 0x00003084UL,
  0x02014058UL, 0x000A5000UL,
  0x02014068UL, 0x00E00333UL,
  0x02014400UL, 0x00001000UL,
  0x02018038UL, 0x00105E85UL,
  0x13010150UL, 0x0001C000UL,
  0x33010150UL, 0x006000C1UL,
  0x03010210UL, 0x0002998EUL,
  0x05114100UL, 0x00000008UL,
  /*    4104 */ 0x180A2800UL,
  /*    4108 */ 0x00000000UL,
  /*    410C */ 0x0661081AUL,
  /*    4110 */ 0x003DA84DUL,
  /*    4114 */ 0x00681E85UL,
  /*    4118 */ 0x00C52BEDUL,
  /*    411C */ 0x01297F22UL,
  /*    4120 */ 0x04F7CC20UL,
  /*    4124 */ 0x1BE919BAUL,
  /*    4128 */ 0x0661081AUL,
  /*    412C */ 0x003DA84DUL,
  /*    4130 */ 0x00681E85UL,
  /*    4134 */ 0x00C52BEDUL,
  /*    4138 */ 0x04F7CC20UL,
  /*    413C */ 0x01297F22UL,
  /*    4140 */ 0x1BE919BAUL,
  0x05014180UL, 0x0010B57AUL,
  0x05018124UL, 0x00000801UL,
  0x0701FC00UL, 0x98580001UL,
  0x0701FC00UL, 0x98580001UL,
  0x0701FC00UL, 0x98580001UL,
  0x0701FC00UL, 0x98580001UL,
  0x0701FC00UL, 0x98580001UL,
  0x0701FC0CUL, 0x000007F1UL,
  0x0701FC18UL, 0x8010D20AUL,
  0x0701FC30UL, 0x43428C05UL,
  0x0701FC30UL, 0x43428C05UL,
  0x0702FC30UL, 0x43428C05UL,
  /*    FC34 */ 0x000000A0UL,
  0x0702FC34UL, 0x000000A0UL,
  /*    FC38 */ 0x0A281C09UL,
  0x0702FC38UL, 0x0A281C09UL,
  /*    FC3C */ 0xFB93FB33UL,
  0x0702FC3CUL, 0xFB93FB33UL,
  /*    FC40 */ 0x02AF0219UL,
  0x0702FC40UL, 0x02AF0219UL,
  /*    FC44 */ 0xFE40FEFAUL,
  0x0702FC44UL, 0xFE40FEFAUL,
  /*    FC48 */ 0x01250078UL,
  0x0702FC48UL, 0x01250078UL,
  /*    FC4C */ 0xFF46FFD4UL,
  0x0702FC4CUL, 0xFF46FFD4UL,
  /*    FC50 */ 0x008F0009UL,
  0x0702FC50UL, 0x008F0009UL,
  /*    FC54 */ 0x00030052UL,
  0x0701FC54UL, 0x00030052UL,
  0x0708FC88UL, 0x059C0D64UL,
  /*    FC8C */ 0xFD78FE51UL,
  /*    FC90 */ 0x01A2007DUL,
  /*    FC94 */ 0xFEDF0009UL,
  /*    FC98 */ 0x00C4FFC5UL,
  /*    FC9C */ 0xFF8C0066UL,
  /*    FCA0 */ 0x0039FFA5UL,
  /*    FCA4 */ 0xFFBB0073UL,
  0xFFFFFFFFUL,
};

const uint32_t EU1_OFDM_option_2_modemConfig[] = {
  0x06016FFCUL, (uint32_t) &phyInfo_1,
  0x0101C024UL, 0x00002300UL,
  0x0101C030UL, 0xF4000FA0UL,
  0x0101C05CUL, 0x00000780UL,
  0x010CC06CUL, 0x00000500UL,
  /*    C070 */ 0x000011BAUL,
  /*    C074 */ 0x003F0000UL,
  /*    C078 */ 0x00EE008DUL,
  /*    C07C */ 0x03AC01F6UL,
  /*    C080 */ 0x079604F5UL,
  /*    C084 */ 0x0D9C09DEUL,
  /*    C088 */ 0x179311C3UL,
  /*    C08C */ 0x26F51DFEUL,
  /*    C090 */ 0x3FFF32BDUL,
  /*    C094 */ 0x1BF815FEUL,
  /*    C098 */ 0x2DB423DCUL,
  0x0101C0CCUL, 0x00000066UL,
  0x0101C100UL, 0x00002084UL,
  0x02014058UL, 0x000A9000UL,
  0x02014068UL, 0x00F006DBUL,
  0x02014400UL, 0x00001800UL,
  0x02018038UL, 0x00103F03UL,
  0x13010150UL, 0x0001C000UL,
  0x33010150UL, 0x006000C2UL,
  0x03010210UL, 0x0002998EUL,
  0x05114100UL, 0x00000012UL,
  /*    4104 */ 0x180A2800UL,
  /*    4108 */ 0x00000000UL,
  /*    410C */ 0x0661081AUL,
  /*    4110 */ 0x003DA84DUL,
  /*    4114 */ 0x00681E85UL,
  /*    4118 */ 0x00C52BEDUL,
  /*    411C */ 0x01297F22UL,
  /*    4120 */ 0x04F7CC20UL,
  /*    4124 */ 0x1BE919BAUL,
  /*    4128 */ 0x0661081AUL,
  /*    412C */ 0x003DA84DUL,
  /*    4130 */ 0x00681E85UL,
  /*    4134 */ 0x00C52BEDUL,
  /*    4138 */ 0x04F7CC20UL,
  /*    413C */ 0x01297F22UL,
  /*    4140 */ 0x1BE919BAUL,
  0x05014180UL, 0x0010A14FUL,
  0x05018124UL, 0x00001003UL,
  0x0701FC00UL, 0x98580101UL,
  0x0701FC00UL, 0x98580101UL,
  0x0701FC00UL, 0x98580101UL,
  0x0701FC00UL, 0x98580101UL,
  0x0701FC00UL, 0x98580101UL,
  0x0701FC0CUL, 0x000007E1UL,
  0x0701FC18UL, 0x80106905UL,
  0x0701FC30UL, 0x43428C05UL,
  0x0701FC30UL, 0x43428C05UL,
  0x0702FC30UL, 0x43428C05UL,
  /*    FC34 */ 0x000000A0UL,
  0x0702FC34UL, 0x000000A0UL,
  /*    FC38 */ 0x09411CF7UL,
  0x0702FC38UL, 0x09411CF7UL,
  /*    FC3C */ 0xFC68FA4BUL,
  0x0702FC3CUL, 0xFC68FA4BUL,
  /*    FC40 */ 0x01F702F2UL,
  0x0702FC40UL, 0x01F702F2UL,
  /*    FC44 */ 0xFED5FE35UL,
  0x0702FC44UL, 0xFED5FE35UL,
  /*    FC48 */ 0x00AD0126UL,
  0x0702FC48UL, 0x00AD0126UL,
  /*    FC4C */ 0xFFA9FF45UL,
  0x0702FC4CUL, 0xFFA9FF45UL,
  /*    FC50 */ 0x0023006BUL,
  0x0702FC50UL, 0x0023006BUL,
  /*    FC54 */ 0xFFEBFFCDUL,
  0x0701FC54UL, 0xFFEBFFCDUL,
  0x0708FC88UL, 0x04880E8FUL,
  /*    FC8C */ 0xFE5FFD20UL,
  /*    FC90 */ 0x00DC018BUL,
  /*    FC94 */ 0xFF88FF16UL,
  /*    FC98 */ 0x0041008EUL,
  /*    FC9C */ 0xFFE1FFAFUL,
  /*    FCA0 */ 0x000E002BUL,
  /*    FCA4 */ 0xFFFFFFEBUL,
  0xFFFFFFFFUL,
};

const uint32_t EU1_OFDM_option_3_modemConfig[] = {
  0x06016FFCUL, (uint32_t) &phyInfo_2,
  0x0101C024UL, 0x00001200UL,
  0x0101C030UL, 0xF4000FA0UL,
  0x0101C05CUL, 0x00000F00UL,
  0x010CC06CUL, 0x000004E0UL,
  /*    C070 */ 0x000011BAUL,
  /*    C074 */ 0x003F0000UL,
  /*    C078 */ 0x00EE008DUL,
  /*    C07C */ 0x03AC01F6UL,
  /*    C080 */ 0x079604F5UL,
  /*    C084 */ 0x0D9C09DEUL,
  /*    C088 */ 0x179311C3UL,
  /*    C08C */ 0x26F51DFEUL,
  /*    C090 */ 0x3FFF32BDUL,
  /*    C094 */ 0x1BF815FEUL,
  /*    C098 */ 0x2DB423DCUL,
  0x0101C0CCUL, 0x000000EEUL,
  0x0101C100UL, 0x00001084UL,
  0x02014058UL, 0x000AD000UL,
  0x02014068UL, 0x00F80E2BUL,
  0x02014400UL, 0x00003000UL,
  0x02018038UL, 0x00101F81UL,
  0x13010150UL, 0x0001C000UL,
  0x33010150UL, 0x006000C4UL,
  0x03010210UL, 0x0002998EUL,
  0x05114100UL, 0x00000040UL,
  /*    4104 */ 0x1809071CUL,
  /*    4108 */ 0x00000000UL,
  /*    410C */ 0x0EF1AC1DUL,
  /*    4110 */ 0x000C3974UL,
  /*    4114 */ 0x007680B0UL,
  /*    4118 */ 0x00B3DC89UL,
  /*    411C */ 0x00643C93UL,
  /*    4120 */ 0x04C789C6UL,
  /*    4124 */ 0x1D651A8FUL,
  /*    4128 */ 0x0EF1AC1DUL,
  /*    412C */ 0x000C3974UL,
  /*    4130 */ 0x007680B0UL,
  /*    4134 */ 0x00B3DC89UL,
  /*    4138 */ 0x04C789C6UL,
  /*    413C */ 0x00643C93UL,
  /*    4140 */ 0x1D651A8FUL,
  0x05014180UL, 0x00103C7DUL,
  0x05018124UL, 0x00001807UL,
  0x0701FC00UL, 0x98580201UL,
  0x0701FC00UL, 0x98580201UL,
  0x0701FC00UL, 0x98580201UL,
  0x0701FC00UL, 0x98580201UL,
  0x0701FC00UL, 0x98580201UL,
  0x0701FC0CUL, 0x000007E1UL,
  0x0701FC18UL, 0x80103482UL,
  0x0701FC30UL, 0x43428C05UL,
  0x0701FC30UL, 0x43428C05UL,
  0x0702FC30UL, 0x43428C05UL,
  /*    FC34 */ 0x000000A0UL,
  0x0702FC34UL, 0x000000A0UL,
  /*    FC38 */ 0x09701CDAUL,
  0x0702FC38UL, 0x09701CDAUL,
  /*    FC3C */ 0xFC32FA51UL,
  0x0702FC3CUL, 0xFC32FA51UL,
  /*    FC40 */ 0x023302FBUL,
  0x0702FC40UL, 0x023302FBUL,
  /*    FC44 */ 0xFE8FFE26UL,
  0x0702FC44UL, 0xFE8FFE26UL,
  /*    FC48 */ 0x00FC013FUL,
  0x0702FC48UL, 0x00FC013FUL,
  /*    FC4C */ 0xFF64FF19UL,
  0x0702FC4CUL, 0xFF64FF19UL,
  /*    FC50 */ 0x004E00A4UL,
  0x0702FC50UL, 0x004E00A4UL,
  /*    FC54 */ 0xFFBDFF8CUL,
  0x0701FC54UL, 0xFFBDFF8CUL,
  0x0708FC88UL, 0x045B0EBAUL,
  /*    FC8C */ 0xFE8EFCF8UL,
  /*    FC90 */ 0x00B401AFUL,
  /*    FC94 */ 0xFFAAFEF8UL,
  /*    FC98 */ 0x002700A5UL,
  /*    FC9C */ 0xFFF3FF9EUL,
  /*    FCA0 */ 0x00020035UL,
  /*    FCA4 */ 0x0006FFE5UL,
  0xFFFFFFFFUL,
};

const uint32_t EU1_OFDM_option_4_modemConfig[] = {
  0x06016FFCUL, (uint32_t) &phyInfo_3,
  0x0101C024UL, 0x00002200UL,
  0x0101C030UL, 0xF2000FA0UL,
  0x0101C05CUL, 0x00000F00UL,
  0x010CC06CUL, 0x000004C0UL,
  /*    C070 */ 0x000011BAUL,
  /*    C074 */ 0x003F0000UL,
  /*    C078 */ 0x00EE008DUL,
  /*    C07C */ 0x03AC01F6UL,
  /*    C080 */ 0x079604F5UL,
  /*    C084 */ 0x0D9C09DEUL,
  /*    C088 */ 0x179311C3UL,
  /*    C08C */ 0x26F51DFEUL,
  /*    C090 */ 0x3FFF32BDUL,
  /*    C094 */ 0x1BF815FEUL,
  /*    C098 */ 0x2DB423DCUL,
  0x0101C0CCUL, 0x000001FEUL,
  0x0101C100UL, 0x00000084UL,
  0x02014058UL, 0x000AD000UL,
  0x02014068UL, 0x00FC1CCBUL,
  0x02014400UL, 0x00003800UL,
  0x02018038UL, 0x00100FC0UL,
  0x13010150UL, 0x0001C000UL,
  0x33010150UL, 0x006000C8UL,
  0x03010210UL, 0x0002998EUL,
  0x05114100UL, 0x0000005AUL,
  /*    4104 */ 0x180A2800UL,
  /*    4108 */ 0x00000000UL,
  /*    410C */ 0x0C81901EUL,
  /*    4110 */ 0x0006490CUL,
  /*    4114 */ 0x006DDFA8UL,
  /*    4118 */ 0x00B10BC0UL,
  /*    411C */ 0x00A53D18UL,
  /*    4120 */ 0x05020AE8UL,
  /*    4124 */ 0x1DD71B27UL,
  /*    4128 */ 0x0C81901EUL,
  /*    412C */ 0x0006490CUL,
  /*    4130 */ 0x006DDFA8UL,
  /*    4134 */ 0x00B10BC0UL,
  /*    4138 */ 0x05020AE8UL,
  /*    413C */ 0x00A53D18UL,
  /*    4140 */ 0x1DD71B27UL,
  0x05014180UL, 0x00102852UL,
  0x05018124UL, 0x0000200FUL,
  0x0701FC00UL, 0x98580301UL,
  0x0701FC00UL, 0x98580301UL,
  0x0701FC00UL, 0x98580301UL,
  0x0701FC00UL, 0x98580301UL,
  0x0701FC00UL, 0x98580301UL,
  0x0701FC0CUL, 0x000007D3UL,
  0x0701FC18UL, 0x80101A41UL,
  0x0701FC30UL, 0x43468C05UL,
  0x0701FC30UL, 0x43468C05UL,
  0x0702FC30UL, 0x43468C05UL,
  /*    FC34 */ 0x000000A0UL,
  0x0702FC34UL, 0x000000A0UL,
  /*    FC38 */ 0x0046231EUL,
  0x0702FC38UL, 0x0046231EUL,
  /*    FC3C */ 0x04B3F8F5UL,
  0x0702FC3CUL, 0x04B3F8F5UL,
  /*    FC40 */ 0xFCFC0043UL,
  0x0702FC40UL, 0xFCFC0043UL,
  /*    FC44 */ 0x003D0238UL,
  0x0702FC44UL, 0x003D0238UL,
  /*    FC48 */ 0x0140FE46UL,
  0x0702FC48UL, 0x0140FE46UL,
  /*    FC4C */ 0xFEEF0032UL,
  0x0702FC4CUL, 0xFEEF0032UL,
  /*    FC50 */ 0x002000CDUL,
  0x0702FC50UL, 0x002000CDUL,
  /*    FC54 */ 0xFF8AFE84UL,
  0x0701FC54UL, 0xFF8AFE84UL,
  0x0708FC88UL, 0x04340EDFUL,
  /*    FC8C */ 0xFEB4FCD7UL,
  /*    FC90 */ 0x009201CBUL,
  /*    FC94 */ 0xFFC7FEE3UL,
  /*    FC98 */ 0x001000B3UL,
  /*    FC9C */ 0x0004FF95UL,
  /*    FCA0 */ 0xFFF7003AUL,
  /*    FCA4 */ 0x000DFFE2UL,
  0xFFFFFFFFUL,
};

const uint32_t NA_OFDM_option_1_modemConfig[] = {
  0x06016FFCUL, (uint32_t) &phyInfo_4,
  0x0101C024UL, 0x00002300UL,
  0x0101C030UL, 0xF4000FA0UL,
  0x0101C05CUL, 0x000003C0UL,
  0x010CC06CUL, 0x00000540UL,
  /*    C070 */ 0x000011BAUL,
  /*    C074 */ 0x00190000UL,
  /*    C078 */ 0x0065003AUL,
  /*    C07C */ 0x00DA0096UL,
  /*    C080 */ 0x02BA01C0UL,
  /*    C084 */ 0x05B003D6UL,
  /*    C088 */ 0x09EA07B2UL,
  /*    C08C */ 0x10FE0CFAUL,
  /*    C090 */ 0x1D5A16D2UL,
  /*    C094 */ 0x3178269AUL,
  /*    C098 */ 0x36DA3FFFUL,
  0x0101C0CCUL, 0x00000000UL,
  0x0101C100UL, 0x00003084UL,
  0x02014058UL, 0x000A5000UL,
  0x02014068UL, 0x00E00333UL,
  0x02014400UL, 0x00001000UL,
  0x02018038UL, 0x00105E85UL,
  0x13010150UL, 0x0001C000UL,
  0x33010150UL, 0x006000C1UL,
  0x03010210UL, 0x00031989UL,
  0x05114100UL, 0x00000008UL,
  /*    4104 */ 0x180A2800UL,
  /*    4108 */ 0x00000000UL,
  /*    410C */ 0x0661081AUL,
  /*    4110 */ 0x003DA84DUL,
  /*    4114 */ 0x00681E85UL,
  /*    4118 */ 0x00C52BEDUL,
  /*    411C */ 0x01297F22UL,
  /*    4120 */ 0x04F7CC20UL,
  /*    4124 */ 0x1BE919BAUL,
  /*    4128 */ 0x0661081AUL,
  /*    412C */ 0x003DA84DUL,
  /*    4130 */ 0x00681E85UL,
  /*    4134 */ 0x00C52BEDUL,
  /*    4138 */ 0x04F7CC20UL,
  /*    413C */ 0x01297F22UL,
  /*    4140 */ 0x1BE919BAUL,
  0x05014180UL, 0x0010B57AUL,
  0x05018124UL, 0x00000801UL,
  0x0701FC00UL, 0x98580001UL,
  0x0701FC00UL, 0x98580001UL,
  0x0701FC00UL, 0x98580001UL,
  0x0701FC00UL, 0x98580001UL,
  0x0701FC00UL, 0x98580001UL,
  0x0701FC0CUL, 0x000007F1UL,
  0x0701FC18UL, 0x8010D20AUL,
  0x0701FC30UL, 0x43428C05UL,
  0x0701FC30UL, 0x43428C05UL,
  0x0702FC30UL, 0x43428C05UL,
  /*    FC34 */ 0x000000A0UL,
  0x0702FC34UL, 0x000000A0UL,
  /*    FC38 */ 0x0A281C09UL,
  0x0702FC38UL, 0x0A281C09UL,
  /*    FC3C */ 0xFB93FB33UL,
  0x0702FC3CUL, 0xFB93FB33UL,
  /*    FC40 */ 0x02AF0219UL,
  0x0702FC40UL, 0x02AF0219UL,
  /*    FC44 */ 0xFE40FEFAUL,
  0x0702FC44UL, 0xFE40FEFAUL,
  /*    FC48 */ 0x01250078UL,
  0x0702FC48UL, 0x01250078UL,
  /*    FC4C */ 0xFF46FFD4UL,
  0x0702FC4CUL, 0xFF46FFD4UL,
  /*    FC50 */ 0x008F0009UL,
  0x0702FC50UL, 0x008F0009UL,
  /*    FC54 */ 0x00030052UL,
  0x0701FC54UL, 0x00030052UL,
  0x0708FC88UL, 0x059C0D64UL,
  /*    FC8C */ 0xFD78FE51UL,
  /*    FC90 */ 0x01A2007DUL,
  /*    FC94 */ 0xFEDF0009UL,
  /*    FC98 */ 0x00C4FFC5UL,
  /*    FC9C */ 0xFF8C0066UL,
  /*    FCA0 */ 0x0039FFA5UL,
  /*    FCA4 */ 0xFFBB0073UL,
  0xFFFFFFFFUL,
};

const uint32_t NA_OFDM_option_2_modemConfig[] = {
  0x06016FFCUL, (uint32_t) &phyInfo_5,
  0x0101C024UL, 0x00002300UL,
  0x0101C030UL, 0xF4000FA0UL,
  0x0101C05CUL, 0x00000780UL,
  0x010CC06CUL, 0x00000500UL,
  /*    C070 */ 0x000011BAUL,
  /*    C074 */ 0x00190000UL,
  /*    C078 */ 0x0065003AUL,
  /*    C07C */ 0x00DA0096UL,
  /*    C080 */ 0x02BA01C0UL,
  /*    C084 */ 0x05B003D6UL,
  /*    C088 */ 0x09EA07B2UL,
  /*    C08C */ 0x10FE0CFAUL,
  /*    C090 */ 0x1D5A16D2UL,
  /*    C094 */ 0x3178269AUL,
  /*    C098 */ 0x36DA3FFFUL,
  0x0101C0CCUL, 0x00000066UL,
  0x0101C100UL, 0x00002084UL,
  0x02014058UL, 0x000A9000UL,
  0x02014068UL, 0x00F006DBUL,
  0x02014400UL, 0x00001800UL,
  0x02018038UL, 0x00103F03UL,
  0x13010150UL, 0x0001C000UL,
  0x33010150UL, 0x006000C2UL,
  0x03010210UL, 0x00031989UL,
  0x05114100UL, 0x00000012UL,
  /*    4104 */ 0x180A2800UL,
  /*    4108 */ 0x00000000UL,
  /*    410C */ 0x0661081AUL,
  /*    4110 */ 0x003DA84DUL,
  /*    4114 */ 0x00681E85UL,
  /*    4118 */ 0x00C52BEDUL,
  /*    411C */ 0x01297F22UL,
  /*    4120 */ 0x04F7CC20UL,
  /*    4124 */ 0x1BE919BAUL,
  /*    4128 */ 0x0661081AUL,
  /*    412C */ 0x003DA84DUL,
  /*    4130 */ 0x00681E85UL,
  /*    4134 */ 0x00C52BEDUL,
  /*    4138 */ 0x04F7CC20UL,
  /*    413C */ 0x01297F22UL,
  /*    4140 */ 0x1BE919BAUL,
  0x05014180UL, 0x0010A14FUL,
  0x05018124UL, 0x00001003UL,
  0x0701FC00UL, 0x98580101UL,
  0x0701FC00UL, 0x98580101UL,
  0x0701FC00UL, 0x98580101UL,
  0x0701FC00UL, 0x98580101UL,
  0x0701FC00UL, 0x98580101UL,
  0x0701FC0CUL, 0x000007E1UL,
  0x0701FC18UL, 0x80106905UL,
  0x0701FC30UL, 0x43428C05UL,
  0x0701FC30UL, 0x43428C05UL,
  0x0702FC30UL, 0x43428C05UL,
  /*    FC34 */ 0x000000A0UL,
  0x0702FC34UL, 0x000000A0UL,
  /*    FC38 */ 0x09411CF7UL,
  0x0702FC38UL, 0x09411CF7UL,
  /*    FC3C */ 0xFC68FA4BUL,
  0x0702FC3CUL, 0xFC68FA4BUL,
  /*    FC40 */ 0x01F702F2UL,
  0x0702FC40UL, 0x01F702F2UL,
  /*    FC44 */ 0xFED5FE35UL,
  0x0702FC44UL, 0xFED5FE35UL,
  /*    FC48 */ 0x00AD0126UL,
  0x0702FC48UL, 0x00AD0126UL,
  /*    FC4C */ 0xFFA9FF45UL,
  0x0702FC4CUL, 0xFFA9FF45UL,
  /*    FC50 */ 0x0023006BUL,
  0x0702FC50UL, 0x0023006BUL,
  /*    FC54 */ 0xFFEBFFCDUL,
  0x0701FC54UL, 0xFFEBFFCDUL,
  0x0708FC88UL, 0x04880E8FUL,
  /*    FC8C */ 0xFE5FFD20UL,
  /*    FC90 */ 0x00DC018BUL,
  /*    FC94 */ 0xFF88FF16UL,
  /*    FC98 */ 0x0041008EUL,
  /*    FC9C */ 0xFFE1FFAFUL,
  /*    FCA0 */ 0x000E002BUL,
  /*    FCA4 */ 0xFFFFFFEBUL,
  0xFFFFFFFFUL,
};

const uint32_t NA_OFDM_option_3_modemConfig[] = {
  0x06016FFCUL, (uint32_t) &phyInfo_6,
  0x0101C024UL, 0x00001200UL,
  0x0101C030UL, 0xF4000FA0UL,
  0x0101C05CUL, 0x00000F00UL,
  0x010CC06CUL, 0x000004E0UL,
  /*    C070 */ 0x000011BAUL,
  /*    C074 */ 0x00190000UL,
  /*    C078 */ 0x0065003AUL,
  /*    C07C */ 0x00DA0096UL,
  /*    C080 */ 0x02BA01C0UL,
  /*    C084 */ 0x05B003D6UL,
  /*    C088 */ 0x09EA07B2UL,
  /*    C08C */ 0x10FE0CFAUL,
  /*    C090 */ 0x1D5A16D2UL,
  /*    C094 */ 0x3178269AUL,
  /*    C098 */ 0x36DA3FFFUL,
  0x0101C0CCUL, 0x000000EEUL,
  0x0101C100UL, 0x00001084UL,
  0x02014058UL, 0x000AD000UL,
  0x02014068UL, 0x00F80E2BUL,
  0x02014400UL, 0x00003000UL,
  0x02018038UL, 0x00101F81UL,
  0x13010150UL, 0x0001C000UL,
  0x33010150UL, 0x006000C4UL,
  0x03010210UL, 0x00031989UL,
  0x05114100UL, 0x00000040UL,
  /*    4104 */ 0x1809071CUL,
  /*    4108 */ 0x00000000UL,
  /*    410C */ 0x0EF1AC1DUL,
  /*    4110 */ 0x000C3974UL,
  /*    4114 */ 0x007680B0UL,
  /*    4118 */ 0x00B3DC89UL,
  /*    411C */ 0x00643C93UL,
  /*    4120 */ 0x04C789C6UL,
  /*    4124 */ 0x1D651A8FUL,
  /*    4128 */ 0x0EF1AC1DUL,
  /*    412C */ 0x000C3974UL,
  /*    4130 */ 0x007680B0UL,
  /*    4134 */ 0x00B3DC89UL,
  /*    4138 */ 0x04C789C6UL,
  /*    413C */ 0x00643C93UL,
  /*    4140 */ 0x1D651A8FUL,
  0x05014180UL, 0x00103C7DUL,
  0x05018124UL, 0x00001807UL,
  0x0701FC00UL, 0x98580201UL,
  0x0701FC00UL, 0x98580201UL,
  0x0701FC00UL, 0x98580201UL,
  0x0701FC00UL, 0x98580201UL,
  0x0701FC00UL, 0x98580201UL,
  0x0701FC0CUL, 0x000007E1UL,
  0x0701FC18UL, 0x80103482UL,
  0x0701FC30UL, 0x43428C05UL,
  0x0701FC30UL, 0x43428C05UL,
  0x0702FC30UL, 0x43428C05UL,
  /*    FC34 */ 0x000000A0UL,
  0x0702FC34UL, 0x000000A0UL,
  /*    FC38 */ 0x09701CDAUL,
  0x0702FC38UL, 0x09701CDAUL,
  /*    FC3C */ 0xFC32FA51UL,
  0x0702FC3CUL, 0xFC32FA51UL,
  /*    FC40 */ 0x023302FBUL,
  0x0702FC40UL, 0x023302FBUL,
  /*    FC44 */ 0xFE8FFE26UL,
  0x0702FC44UL, 0xFE8FFE26UL,
  /*    FC48 */ 0x00FC013FUL,
  0x0702FC48UL, 0x00FC013FUL,
  /*    FC4C */ 0xFF64FF19UL,
  0x0702FC4CUL, 0xFF64FF19UL,
  /*    FC50 */ 0x004E00A4UL,
  0x0702FC50UL, 0x004E00A4UL,
  /*    FC54 */ 0xFFBDFF8CUL,
  0x0701FC54UL, 0xFFBDFF8CUL,
  0x0708FC88UL, 0x045B0EBAUL,
  /*    FC8C */ 0xFE8EFCF8UL,
  /*    FC90 */ 0x00B401AFUL,
  /*    FC94 */ 0xFFAAFEF8UL,
  /*    FC98 */ 0x002700A5UL,
  /*    FC9C */ 0xFFF3FF9EUL,
  /*    FCA0 */ 0x00020035UL,
  /*    FCA4 */ 0x0006FFE5UL,
  0xFFFFFFFFUL,
};

const uint32_t NA_OFDM_option_4_modemConfig[] = {
  0x06016FFCUL, (uint32_t) &phyInfo_7,
  0x0101C024UL, 0x00002200UL,
  0x0101C030UL, 0xF2000FA0UL,
  0x0101C05CUL, 0x00000F00UL,
  0x010CC06CUL, 0x000004C0UL,
  /*    C070 */ 0x000011BAUL,
  /*    C074 */ 0x00190000UL,
  /*    C078 */ 0x0065003AUL,
  /*    C07C */ 0x00DA0096UL,
  /*    C080 */ 0x02BA01C0UL,
  /*    C084 */ 0x05B003D6UL,
  /*    C088 */ 0x09EA07B2UL,
  /*    C08C */ 0x10FE0CFAUL,
  /*    C090 */ 0x1D5A16D2UL,
  /*    C094 */ 0x3178269AUL,
  /*    C098 */ 0x36DA3FFFUL,
  0x0101C0CCUL, 0x000001FEUL,
  0x0101C100UL, 0x00000084UL,
  0x02014058UL, 0x000AD000UL,
  0x02014068UL, 0x00FC1CCBUL,
  0x02014400UL, 0x00003800UL,
  0x02018038UL, 0x00100FC0UL,
  0x13010150UL, 0x0001C000UL,
  0x33010150UL, 0x006000C8UL,
  0x03010210UL, 0x00031989UL,
  0x05114100UL, 0x0000005AUL,
  /*    4104 */ 0x180A2800UL,
  /*    4108 */ 0x00000000UL,
  /*    410C */ 0x0C81901EUL,
  /*    4110 */ 0x0006490CUL,
  /*    4114 */ 0x006DDFA8UL,
  /*    4118 */ 0x00B10BC0UL,
  /*    411C */ 0x00A53D18UL,
  /*    4120 */ 0x05020AE8UL,
  /*    4124 */ 0x1DD71B27UL,
  /*    4128 */ 0x0C81901EUL,
  /*    412C */ 0x0006490CUL,
  /*    4130 */ 0x006DDFA8UL,
  /*    4134 */ 0x00B10BC0UL,
  /*    4138 */ 0x05020AE8UL,
  /*    413C */ 0x00A53D18UL,
  /*    4140 */ 0x1DD71B27UL,
  0x05014180UL, 0x00102852UL,
  0x05018124UL, 0x0000200FUL,
  0x0701FC00UL, 0x98580301UL,
  0x0701FC00UL, 0x98580301UL,
  0x0701FC00UL, 0x98580301UL,
  0x0701FC00UL, 0x98580301UL,
  0x0701FC00UL, 0x98580301UL,
  0x0701FC0CUL, 0x000007D3UL,
  0x0701FC18UL, 0x80101A41UL,
  0x0701FC30UL, 0x43468C05UL,
  0x0701FC30UL, 0x43468C05UL,
  0x0702FC30UL, 0x43468C05UL,
  /*    FC34 */ 0x000000A0UL,
  0x0702FC34UL, 0x000000A0UL,
  /*    FC38 */ 0x0046231EUL,
  0x0702FC38UL, 0x0046231EUL,
  /*    FC3C */ 0x04B3F8F5UL,
  0x0702FC3CUL, 0x04B3F8F5UL,
  /*    FC40 */ 0xFCFC0043UL,
  0x0702FC40UL, 0xFCFC0043UL,
  /*    FC44 */ 0x003D0238UL,
  0x0702FC44UL, 0x003D0238UL,
  /*    FC48 */ 0x0140FE46UL,
  0x0702FC48UL, 0x0140FE46UL,
  /*    FC4C */ 0xFEEF0032UL,
  0x0702FC4CUL, 0xFEEF0032UL,
  /*    FC50 */ 0x002000CDUL,
  0x0702FC50UL, 0x002000CDUL,
  /*    FC54 */ 0xFF8AFE84UL,
  0x0701FC54UL, 0xFF8AFE84UL,
  0x0708FC88UL, 0x04340EDFUL,
  /*    FC8C */ 0xFEB4FCD7UL,
  /*    FC90 */ 0x009201CBUL,
  /*    FC94 */ 0xFFC7FEE3UL,
  /*    FC98 */ 0x001000B3UL,
  /*    FC9C */ 0x0004FF95UL,
  /*    FCA0 */ 0xFFF7003AUL,
  /*    FCA4 */ 0x000DFFE2UL,
  0xFFFFFFFFUL,
};

RAIL_ChannelConfigEntry_t Protocol_OFDM_channels[] = {
  {
    .phyConfigDeltaAdd = EU1_OFDM_option_1_modemConfig,
    .baseFrequency = 863625000,
    .channelSpacing = 1200000,
    .physicalChannelOffset = 1000,
    .channelNumberStart = 1000,
    .channelNumberEnd = 1004,
    .maxPower = RAIL_TX_POWER_MAX,
    .attr = &channelConfigEntryAttr,
#ifdef RADIO_CONFIG_ENABLE_CONC_PHY
    .entryType = 0,
#endif
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
    .stackInfo = stackInfo_0,
#endif
    .alternatePhy = NULL,
  },
  {
    .phyConfigDeltaAdd = EU1_OFDM_option_2_modemConfig,
    .baseFrequency = 863425000,
    .channelSpacing = 800000,
    .physicalChannelOffset = 2000,
    .channelNumberStart = 2000,
    .channelNumberEnd = 2008,
    .maxPower = RAIL_TX_POWER_MAX,
    .attr = &channelConfigEntryAttr,
#ifdef RADIO_CONFIG_ENABLE_CONC_PHY
    .entryType = 0,
#endif
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
    .stackInfo = stackInfo_1,
#endif
    .alternatePhy = NULL,
  },
  {
    .phyConfigDeltaAdd = EU1_OFDM_option_3_modemConfig,
    .baseFrequency = 863225000,
    .channelSpacing = 400000,
    .physicalChannelOffset = 3000,
    .channelNumberStart = 3000,
    .channelNumberEnd = 3016,
    .maxPower = RAIL_TX_POWER_MAX,
    .attr = &channelConfigEntryAttr,
#ifdef RADIO_CONFIG_ENABLE_CONC_PHY
    .entryType = 0,
#endif
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
    .stackInfo = stackInfo_2,
#endif
    .alternatePhy = NULL,
  },
  {
    .phyConfigDeltaAdd = EU1_OFDM_option_4_modemConfig,
    .baseFrequency = 863100000,
    .channelSpacing = 200000,
    .physicalChannelOffset = 4000,
    .channelNumberStart = 4000,
    .channelNumberEnd = 4061,
    .maxPower = RAIL_TX_POWER_MAX,
    .attr = &channelConfigEntryAttr,
#ifdef RADIO_CONFIG_ENABLE_CONC_PHY
    .entryType = 0,
#endif
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
    .stackInfo = stackInfo_3,
#endif
    .alternatePhy = NULL,
  },
  {
    .phyConfigDeltaAdd = NA_OFDM_option_1_modemConfig,
    .baseFrequency = 903200000,
    .channelSpacing = 1200000,
    .physicalChannelOffset = 5000,
    .channelNumberStart = 5000,
    .channelNumberEnd = 5019,
    .maxPower = RAIL_TX_POWER_MAX,
    .attr = &channelConfigEntryAttr,
#ifdef RADIO_CONFIG_ENABLE_CONC_PHY
    .entryType = 0,
#endif
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
    .stackInfo = stackInfo_0,
#endif
    .alternatePhy = NULL,
  },
  {
    .phyConfigDeltaAdd = NA_OFDM_option_2_modemConfig,
    .baseFrequency = 902800000,
    .channelSpacing = 800000,
    .physicalChannelOffset = 6000,
    .channelNumberStart = 6000,
    .channelNumberEnd = 6030,
    .maxPower = RAIL_TX_POWER_MAX,
    .attr = &channelConfigEntryAttr,
#ifdef RADIO_CONFIG_ENABLE_CONC_PHY
    .entryType = 0,
#endif
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
    .stackInfo = stackInfo_1,
#endif
    .alternatePhy = NULL,
  },
  {
    .phyConfigDeltaAdd = NA_OFDM_option_3_modemConfig,
    .baseFrequency = 902400000,
    .channelSpacing = 400000,
    .physicalChannelOffset = 7000,
    .channelNumberStart = 7000,
    .channelNumberEnd = 7063,
    .maxPower = RAIL_TX_POWER_MAX,
    .attr = &channelConfigEntryAttr,
#ifdef RADIO_CONFIG_ENABLE_CONC_PHY
    .entryType = 0,
#endif
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
    .stackInfo = stackInfo_2,
#endif
    .alternatePhy = NULL,
  },
  {
    .phyConfigDeltaAdd = NA_OFDM_option_4_modemConfig,
    .baseFrequency = 902200000,
    .channelSpacing = 200000,
    .physicalChannelOffset = 8000,
    .channelNumberStart = 8000,
    .channelNumberEnd = 8128,
    .maxPower = RAIL_TX_POWER_MAX,
    .attr = &channelConfigEntryAttr,
#ifdef RADIO_CONFIG_ENABLE_CONC_PHY
    .entryType = 0,
#endif
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
    .stackInfo = stackInfo_3,
#endif
    .alternatePhy = NULL,
  },
};

RAIL_ChannelConfig_t Protocol_OFDM_channelConfig = {
  .phyConfigBase = Protocol_OFDM_modemConfigBase,
  .phyConfigDeltaSubtract = NULL,
  .configs = Protocol_OFDM_channels,
  .length = 8U,
  .signature = 0UL,
  .xtalFrequencyHz = 39000000UL,
};

const RAIL_ChannelConfig_t *channelConfigs[] = {
  &Protocol_OFDM_channelConfig,
  NULL
};

const uint8_t wisun_modeSwitchPhrsLength = WISUN_MODESWITCHPHRS_ARRAY_SIZE;

const RAIL_IEEE802154_ModeSwitchPhr_t wisun_modeSwitchPhrs[WISUN_MODESWITCHPHRS_ARRAY_SIZE] = {
  {
    .phyModeId = 32U,
    .phr = 24609U,
  },
  {
    .phyModeId = 33U,
    .phr = 33825U,
  },
  {
    .phyModeId = 34U,
    .phr = 53793U,
  },
  {
    .phyModeId = 35U,
    .phr = 13857U,
  },
  {
    .phyModeId = 36U,
    .phr = 63777U,
  },
  {
    .phyModeId = 37U,
    .phr = 7457U,
  },
  {
    .phyModeId = 38U,
    .phr = 19233U,
  },
  {
    .phyModeId = 39U,
    .phr = 44833U,
  },
  {
    .phyModeId = 48U,
    .phr = 45153U,
  },
  {
    .phyModeId = 49U,
    .phr = 21601U,
  },
  {
    .phyModeId = 50U,
    .phr = 609U,
  },
  {
    .phyModeId = 51U,
    .phr = 58977U,
  },
  {
    .phyModeId = 52U,
    .phr = 10593U,
  },
  {
    .phyModeId = 53U,
    .phr = 52577U,
  },
  {
    .phyModeId = 54U,
    .phr = 39777U,
  },
  {
    .phyModeId = 55U,
    .phr = 32609U,
  },
  {
    .phyModeId = 64U,
    .phr = 47121U,
  },
  {
    .phyModeId = 65U,
    .phr = 23569U,
  },
  {
    .phyModeId = 66U,
    .phr = 2577U,
  },
  {
    .phyModeId = 67U,
    .phr = 60945U,
  },
  {
    .phyModeId = 68U,
    .phr = 8465U,
  },
  {
    .phyModeId = 69U,
    .phr = 50449U,
  },
  {
    .phyModeId = 70U,
    .phr = 37649U,
  },
  {
    .phyModeId = 71U,
    .phr = 30481U,
  },
  {
    .phyModeId = 80U,
    .phr = 26705U,
  },
  {
    .phyModeId = 81U,
    .phr = 35921U,
  },
  {
    .phyModeId = 82U,
    .phr = 55889U,
  },
  {
    .phyModeId = 83U,
    .phr = 15953U,
  },
  {
    .phyModeId = 84U,
    .phr = 61777U,
  },
  {
    .phyModeId = 85U,
    .phr = 5457U,
  },
  {
    .phyModeId = 86U,
    .phr = 17233U,
  },
  {
    .phyModeId = 87U,
    .phr = 42833U,
  },
};

#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
const uint8_t stackInfo_0[5] = {0x07, 0x20, 0x01, 0x05, 0x01};
const uint8_t stackInfo_1[5] = {0x07, 0x30, 0x01, 0x04, 0x01};
const uint8_t stackInfo_2[5] = {0x07, 0x40, 0x01, 0x02, 0x01};
const uint8_t stackInfo_3[5] = {0x07, 0x50, 0x01, 0x01, 0x01};
#endif // RADIO_CONFIG_ENABLE_STACK_INFO

uint32_t protocolAccelerationBuffer[515];



/* ******* RAIL OFDM configurations ******* */

const struct wisun_rail_config ofdm_rail_configs[] = {
    {
        .name = "FAN-EU1-OFDM-option-1-MCS-0-6-non-wisun-complient",
        .channel_config = { .channel_0_center_frequency = 863625000, .channel_spacing = 1200000,
                            .datarate = 0xFFFFFFFF, .number_of_channels = 5, .modulation = M_OFDM,
                            .ofdm_option = OFDM_OPTION_1, .ofdm_mcs = -1 },
        .set_config_func = rf_set_config_eu1_ofdm_option_1,
    },
    {
        .name = "FAN-EU1-OFDM-option-2-MCS-0-6-non-wisun-complient",
        .channel_config = { .channel_0_center_frequency = 863425000, .channel_spacing = 800000,
                            .datarate = 0xFFFFFFFF, .number_of_channels = 9, .modulation = M_OFDM,
                            .ofdm_option = OFDM_OPTION_2, .ofdm_mcs = -1 },
        .set_config_func = rf_set_config_eu1_ofdm_option_2,
    },
    {
        .name = "FAN-EU1-OFDM-option-3-MCS-0-6-non-wisun-complient",
        .channel_config = { .channel_0_center_frequency = 863225000, .channel_spacing = 400000,
                            .datarate = 0xFFFFFFFF, .number_of_channels = 17, .modulation = M_OFDM,
                            .ofdm_option = OFDM_OPTION_3, .ofdm_mcs = -1 },
        .set_config_func = rf_set_config_eu1_ofdm_option_3,
    },
      {
        .name = "FAN-EU1-OFDM-option-4-MCS-0-6-wisun-complient",
        .channel_config = { .channel_0_center_frequency = 863100000, .channel_spacing = 200000,
                            .datarate = 0xFFFFFFFF, .number_of_channels = 35, .modulation = M_OFDM,
                            .ofdm_option = OFDM_OPTION_4, .ofdm_mcs = -1 },
        .set_config_func = rf_set_config_eu1_ofdm_option_4,
    },
      {
        .name = "FAN-NA-OFDM-option-1-MCS-0-6-wisun-complient",
        .channel_config = { .channel_0_center_frequency = 903200000, .channel_spacing = 1200000,
                            .datarate = 0xFFFFFFFF, .number_of_channels = 21, .modulation = M_OFDM,
                            .ofdm_option = OFDM_OPTION_1, .ofdm_mcs = -1 },
        .set_config_func = rf_set_config_eu1_ofdm_option_1,
    },
    {
        .name = "FAN-NA-OFDM-option-2-MCS-0-6-wisun-complient",
        .channel_config = { .channel_0_center_frequency = 902800000, .channel_spacing = 800000,
                            .datarate = 0xFFFFFFFF, .number_of_channels = 31, .modulation = M_OFDM,
                            .ofdm_option = OFDM_OPTION_2, .ofdm_mcs = -1 },
        .set_config_func = rf_set_config_na_ofdm_option_2,
    },
    {
        .name = "FAN-NA-OFDM-option-3-MCS-0-6-wisun-complient",
        .channel_config = { .channel_0_center_frequency = 902400000, .channel_spacing = 400000,
                            .datarate = 0xFFFFFFFF, .number_of_channels = 64, .modulation = M_OFDM,
                            .ofdm_option = OFDM_OPTION_3, .ofdm_mcs = -1 },
        .set_config_func = rf_set_config_na_ofdm_option_3,
    },
      {
        .name = "FAN-NA-OFDM-option-4-MCS-0-6-wisun-complient",
        .channel_config = { .channel_0_center_frequency = 902200000, .channel_spacing = 200000,
                            .datarate = 0xFFFFFFFF, .number_of_channels = 128, .modulation = M_OFDM,
                            .ofdm_option = OFDM_OPTION_4, .ofdm_mcs = -1 },
        .set_config_func = rf_set_config_na_ofdm_option_4,
    },
    { NULL },  // Teminator
};

static uint32_t _rf_calculate_datarate(phy_ofdm_option_e option, phy_ofdm_mcs_e mcs) {
  if (option == OFDM_OPTION_1) {
    switch (mcs) {
      case OFDM_MCS_0:
        return 100000;
      case OFDM_MCS_1:
        return 200000;
      case OFDM_MCS_2:
        return 400000;
      case OFDM_MCS_3:
        return 800000;
      case OFDM_MCS_4:
        return 1200000;
      case OFDM_MCS_5:
        return 1600000;
      case OFDM_MCS_6:
        return 2400000;
      default:
        return 0;
    }
  } else if (option == OFDM_OPTION_2) {
    switch (mcs) {
      case OFDM_MCS_0:
        return 50000;
      case OFDM_MCS_1:
        return 100000;
      case OFDM_MCS_2:
        return 200000;
      case OFDM_MCS_3:
        return 400000;
      case OFDM_MCS_4:
        return 600000;
      case OFDM_MCS_5:
        return 800000;
      case OFDM_MCS_6:
        return 1200000;
      default:
        return 0;
    }
  } else if (option == OFDM_OPTION_3) {
    switch (mcs) {
      case OFDM_MCS_0:
        return 25000;
      case OFDM_MCS_1:
        return 50000;
      case OFDM_MCS_2:
        return 100000;
      case OFDM_MCS_3:
        return 200000;
      case OFDM_MCS_4:
        return 300000;
      case OFDM_MCS_5:
        return 400000;
      case OFDM_MCS_6:
        return 600000;
      default:
        return 0;
    }
  } else if (option == OFDM_OPTION_4) {
    switch (mcs) {
      case OFDM_MCS_0:
        return 12500;
      case OFDM_MCS_1:
        return 25000;
      case OFDM_MCS_2:
        return 50000;
      case OFDM_MCS_3:
        return 100000;
      case OFDM_MCS_4:
        return 150000;
      case OFDM_MCS_5:
        return 200000;
      case OFDM_MCS_6:
        return 300000;
      default:
        return 0;
    }
  }
}

RAIL_ChannelConfigEntry_t * rf_set_config_eu1_ofdm_option_1(phy_rf_channel_configuration_s *mbed_channel_config) {
  mbed_channel_config->datarate = _rf_calculate_datarate(mbed_channel_config->ofdm_option, mbed_channel_config->ofdm_mcs);

  if (mbed_channel_config->datarate == 0) {
    return NULL;
  }

  return &Protocol_OFDM_channels[0];
}

RAIL_ChannelConfigEntry_t * rf_set_config_eu1_ofdm_option_2(phy_rf_channel_configuration_s *mbed_channel_config) {
  mbed_channel_config->datarate = _rf_calculate_datarate(mbed_channel_config->ofdm_option, mbed_channel_config->ofdm_mcs);

  if (mbed_channel_config->datarate == 0) {
    return NULL;
  }

  return &Protocol_OFDM_channels[1];
}

RAIL_ChannelConfigEntry_t * rf_set_config_eu1_ofdm_option_3(phy_rf_channel_configuration_s *mbed_channel_config) {
  mbed_channel_config->datarate = _rf_calculate_datarate(mbed_channel_config->ofdm_option, mbed_channel_config->ofdm_mcs);

  if (mbed_channel_config->datarate == 0) {
    return NULL;
  }

  return &Protocol_OFDM_channels[2];
}

RAIL_ChannelConfigEntry_t * rf_set_config_eu1_ofdm_option_4(phy_rf_channel_configuration_s *mbed_channel_config) {
  mbed_channel_config->datarate = _rf_calculate_datarate(mbed_channel_config->ofdm_option, mbed_channel_config->ofdm_mcs);

  if (mbed_channel_config->datarate == 0) {
    return NULL;
  }

  return &Protocol_OFDM_channels[3];
}

RAIL_ChannelConfigEntry_t * rf_set_config_na_ofdm_option_1(phy_rf_channel_configuration_s *mbed_channel_config) {
  mbed_channel_config->datarate = _rf_calculate_datarate(mbed_channel_config->ofdm_option, mbed_channel_config->ofdm_mcs);

  if (mbed_channel_config->datarate == 0) {
    return NULL;
  }

  return &Protocol_OFDM_channels[4];
}

RAIL_ChannelConfigEntry_t * rf_set_config_na_ofdm_option_2(phy_rf_channel_configuration_s *mbed_channel_config) {
  mbed_channel_config->datarate = _rf_calculate_datarate(mbed_channel_config->ofdm_option, mbed_channel_config->ofdm_mcs);

  if (mbed_channel_config->datarate == 0) {
    return NULL;
  }

  return &Protocol_OFDM_channels[5];
}

RAIL_ChannelConfigEntry_t * rf_set_config_na_ofdm_option_3(phy_rf_channel_configuration_s *mbed_channel_config) {
  mbed_channel_config->datarate = _rf_calculate_datarate(mbed_channel_config->ofdm_option, mbed_channel_config->ofdm_mcs);

  if (mbed_channel_config->datarate == 0) {
    return NULL;
  }

  return &Protocol_OFDM_channels[6];
}

RAIL_ChannelConfigEntry_t * rf_set_config_na_ofdm_option_4(phy_rf_channel_configuration_s *mbed_channel_config) {
  mbed_channel_config->datarate = _rf_calculate_datarate(mbed_channel_config->ofdm_option, mbed_channel_config->ofdm_mcs);

  if (mbed_channel_config->datarate == 0) {
    return NULL;
  }

  return &Protocol_OFDM_channels[7];
}
