/**
 * @file rail_config.h
 * @author Yann Charbon <yann.charbon@heig-vd.ch>
 * @brief Contains all the configurations that are supported by the RAIL library for Wi-SUN.
 * @version 1.0
 * @date 2023-06
 *
 * @copyright Copyright (c) 2023
 *
 */

#ifndef __RAIL_CONFIG_H__
#define __RAIL_CONFIG_H__

#include <stdint.h>
#include "rail_types.h"
#include "rail_ieee802154.h"
#include "nanostack/platform/arm_hal_phy.h"

#include "rail_config_ofdm.h"

#define RSSI_THRESHOLD  (-85)

#define PROTOCOL_ACCELERATION_BUFFER protocolAccelerationBuffer
extern uint32_t protocolAccelerationBuffer[];

#define RADIO_CONFIG_XTAL_FREQUENCY 39000000UL

#define RAIL0_EU1_OFDM_OPTION_1_PHY_WISUN_FAN_1V1_915MHZ_PLAN1_OFDM_OPT4_NA
#define RAIL0_EU1_OFDM_OPTION_1_PROFILE_WISUN_FAN_1_1
extern const RAIL_ChannelConfig_t *channelConfigs[];
#define RADIO_CONFIG_RFFPLL_CONFIG_PRESENT
extern const uint32_t rffpllConfig[];
extern const RAIL_RffpllConfig_t *radioConfigRffpllConfig;

#define WISUN_MODESWITCHPHRS_ARRAY_SIZE 32
extern const uint8_t wisun_modeSwitchPhrsLength;
extern const RAIL_IEEE802154_ModeSwitchPhr_t wisun_modeSwitchPhrs[WISUN_MODESWITCHPHRS_ARRAY_SIZE];

typedef struct RAIL_StackInfoWisun {
  RAIL_StackInfoCommon_t stackInfoCommon;
  uint8_t version;
  uint8_t wisunChannelParam;// wisunOperatingClass for version=0, wisunChannelPlanId for version=1
  uint8_t wisunRegDomain;
} RAIL_StackInfoWisun_t;

#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
extern const uint8_t stackInfo_0[5];
extern const uint8_t stackInfo_1[5];
extern const uint8_t stackInfo_2[5];
extern const uint8_t stackInfo_3[5];
#endif // RADIO_CONFIG_ENABLE_STACK_INFO

// Public
extern RAIL_ChannelConfigEntry_t Protocol_Configuration_channels[];
extern RAIL_ChannelConfig_t Protocol_Configuration_channelConfig;
extern RAIL_ChannelConfig_t Protocol_OFDM_channelConfig;

struct wisun_rail_config {
    const char *name;
    const phy_rf_channel_configuration_s channel_config;
    RAIL_ChannelConfigEntry_t * (*set_config_func)(phy_rf_channel_configuration_s *);
};

extern const struct wisun_rail_config wisun_rail_configs[];
extern const struct wisun_rail_config ofdm_rail_configs[];

#endif