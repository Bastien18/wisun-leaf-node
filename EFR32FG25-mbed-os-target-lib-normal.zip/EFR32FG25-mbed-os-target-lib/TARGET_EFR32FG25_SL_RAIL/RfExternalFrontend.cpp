#include "RfExternalFrontend.h"

RfExternalFrontend::RfExternalFrontend(PinName csd_pin, PinName ctx_pin, PinName cps_pin, PinName rx_band_ctrl_pin, PinName rx_band_nctrl_pin) :
    _csd_pin(csd_pin), _ctx_pin(ctx_pin), _cps_pin(cps_pin), _rx_band_ctrl_pin(rx_band_ctrl_pin), _rx_band_nctrl_pin(rx_band_nctrl_pin) {
    set_frequency_band(RF_EXT_FRONT_FREQ_868M);
    set_mode(RF_EXT_FRONT_MODE_RX);
}


RfExternalFrontend::~RfExternalFrontend() {
    set_mode(RF_EXT_FRONT_MODE_RX);
}

/**
 * @brief Set the frequency band that must be used on the frontend
 * @param channel_0_center_freq Supported ranges: 860-880MHz, 900-950MHz, default 860-880MHz
 *
 * @note If TRX mode is RX, the new band is automatically applied, if mode is TX it will
 * be applied when mode is switched back to RX or OFF to avoid interrupting transmission
*/
void RfExternalFrontend::set_frequency_band(uint32_t channel_0_center_freq) {
    if (channel_0_center_freq >= 860000000 && channel_0_center_freq < 880000000) {
        set_frequency_band(RF_EXT_FRONT_FREQ_868M);
    } else if (channel_0_center_freq >= 900000000 && channel_0_center_freq < 950000000) {
        set_frequency_band(RF_EXT_FRONT_FREQ_915M);
    } else {
        set_frequency_band(RF_EXT_FRONT_FREQ_868M);
    }
}

/**
 * @brief Set the frequency band that must be used on the frontend
 * @param band Supported ranges are 868MHz and 915MHz
 *
 * @note If TRX mode is RX, the new band is automatically applied, if mode is TX it will
 * be applied when mode is switched back to RX or OFF to avoid interrupting transmission
*/
void RfExternalFrontend::set_frequency_band(enum rf_external_frontend_freq_band band) {
    _cur_freq_band = band;
    if (_cur_mode == RF_EXT_FRONT_MODE_RX) {
        // Apply mode
        set_mode(RF_EXT_FRONT_MODE_RX);
    }
    // It is useless to apply if mode is OFF, and we don't want to apply if mode is TX because it would interrupt
    // any ongoing transmission
}

/**
 * @brief Sets the TRX mode
*/
void RfExternalFrontend::set_mode(enum rf_external_frontend_mode mode) {
    if (_cur_freq_band == RF_EXT_FRONT_FREQ_868M) {
        _rx_band_ctrl_pin = 0;
        _rx_band_nctrl_pin = 1;
        //while (_rx_band_ctrl_pin.read() != 0 && _rx_band_nctrl_pin.read() != 1);
    } else if (_cur_freq_band == RF_EXT_FRONT_FREQ_915M) {
        _rx_band_ctrl_pin = 1;
        _rx_band_nctrl_pin = 0;
        //while (_rx_band_ctrl_pin.read() != 1 && _rx_band_nctrl_pin.read() != 0);
    }

    if (mode == RF_EXT_FRONT_MODE_RX) {
        _csd_pin = 1;
        _ctx_pin = 0;
        _cps_pin = 1;
        //while (_csd_pin.read() != 1 && _ctx_pin.read() != 0 && _cps_pin.read() != 1);
    } else if (mode == RF_EXT_FRONT_MODE_TX) {
        _csd_pin = 1;
        _ctx_pin = 1;
        _cps_pin = 1;
        //while (_csd_pin.read() != 1 && _ctx_pin.read() != 1 && _cps_pin.read() != 1);
    } else {
        // RF_EXT_FRONT_MODE_OFF
        _csd_pin = 0;
        _ctx_pin = 0;
        _cps_pin = 0;
        //while (_csd_pin.read() != 0 && _ctx_pin.read() != 0 && _cps_pin.read() != 0);
    }
}