/**
 * @file efr32_rf_wisun_util.h
 * @author Yann Charbon <yann.charbon@heig-vd.ch>
 * @brief This file contains the utility functions related to Wi-SUN for the PHY driver.
 * @version 1.0
 * @date 2022-05-03
 *
 * @copyright Copyright (c) 2022
 *
 */
#ifndef __EFR32_RADIO_WISUN_UTIL_H__
#define __EFR32_RADIO_WISUN_UTIL_H__

#include <stdint.h>

#define WISUN_HEADER_INVALID_PROFILE    0xFF

enum wisun_profile_type { WISUN_FAN_PROFILE, WISUN_ECHONET_PROFILE, WISUN_JUTA_PROFILE };

/**
 * @brief This function creates the PHY header (PHR) that must be prepended to the PHY payload.
 *
 * @param[in] data_length Length of data (exluding the PHY header and the FCS field) to be sent.
 * @param[in] profile_type WI-SUN profile type
 * @return The PHY header.
 *
 * The function returns WISUN_HEADER_INVALID_PROFILE if the profile type is invalid.
 */
uint16_t wisun_util_create_phy_header_sun_fsk(uint16_t data_length, enum wisun_profile_type profile_type);
uint32_t wisun_util_create_phy_header_sun_ofdm(uint16_t data_length, int mcs);

#endif