/**
 * @file efr32_rf_driver.h
 * @author Yann Charbon <yann.charbon@heig-vd.ch>
 * @brief PHY driver for EFR32 RAIL radio supporting IEEE 802.15.4-2015+ frames (Wi-SUN ready).
 * @version 1.0
 * @date 2023-06
 *
 * @copyright Copyright (c) 2023
 *
 */

#ifndef __EFR32_RF_DRIVER_H_
#define __EFR32_RF_DRIVER_H_

#include "mbed.h"
#include "PinNames.h"
#include "NanostackRfPhy.h"

class Efr32RfDriver : public NanostackRfPhy {
public:
    Efr32RfDriver();
    ~Efr32RfDriver();
    int8_t rf_register();
    void rf_unregister();
    void get_mac_address(uint8_t *mac);
    void set_mac_address(uint8_t *mac);
    uint32_t get_driver_version();
private:
    bool _mac_is_set;
};

//#define EFR32_ENABLE_TEST_GPIOS
#ifdef EFR32_ENABLE_TEST_GPIOS
#define EFR32_FHSS_UC_PIN   EXP3
#define EFR32_FHSS_BC_PIN   EXP4

extern void (*fhss_uc_switch)(void);
extern void (*fhss_bc_switch)(void);
#endif

#endif /* __EFR32_RF_DRIVER_H_ */