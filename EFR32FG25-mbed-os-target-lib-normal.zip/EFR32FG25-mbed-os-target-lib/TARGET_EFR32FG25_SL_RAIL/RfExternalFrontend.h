#ifndef RF_EXTERNAL_FRONTEND_H
#define RF_EXTERNAL_FRONTEND_H

#include "mbed.h"
#include "PinNames.h"

enum rf_external_frontend_freq_band { RF_EXT_FRONT_FREQ_868M, RF_EXT_FRONT_FREQ_915M };
enum rf_external_frontend_mode { RF_EXT_FRONT_MODE_OFF, RF_EXT_FRONT_MODE_RX, RF_EXT_FRONT_MODE_TX };

class RfExternalFrontend {
public:
    RfExternalFrontend(PinName csd_pin, PinName ctx_pin, PinName cps_pin, PinName rx_band_ctrl_pin, PinName rx_band_nctrl_pin);
    ~RfExternalFrontend();
    void set_frequency_band(uint32_t channel_0_center_freq);
    void set_frequency_band(enum rf_external_frontend_freq_band band);
    void set_mode(enum rf_external_frontend_mode mode);
private:
    DigitalOut _csd_pin;
    DigitalOut _ctx_pin;
    DigitalOut _cps_pin;
    DigitalOut _rx_band_ctrl_pin;
    DigitalOut _rx_band_nctrl_pin;
    enum rf_external_frontend_freq_band _cur_freq_band;
    enum rf_external_frontend_mode _cur_mode;
};

#endif