/**
 * @file ieee_802154_frame.h
 * @author Yann Charbon <yann.charbon@heig-vd.ch>
 * @brief List of macros used by the PHY driver to check some flags related to the MAC layer
 *  in the IEEE 802.15.4 frame.
 * @version 1.0
 * @date 2022-05-03
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef __IEEE_802154_FRAME__
#define __IEEE_802154_FRAME__

#define IEEE_FRAME_CONTROL_BYTE_0     0
#define IEEE_FRAME_CONTROL_BYTE_1     1
#define IEEE_SEQ_NUMBER_BYTE          2

/* MAC Frame control byte 0 */
#define IEEE_FC_ACK_REQUIRED_MASK       (1 << 5)
#define IEEE_FRAME_TYPE_MASK            0x07

#define IEEE_TYPE_ACK                   (2)

/* MAC Frame control byte 1 */
#define IEEE_FRAME_VERSION_MASK         0x30
#define IEEE_FRAME_VERSION_SHIFT        4

#define IEEE_VERSION_2015               0x2

#endif