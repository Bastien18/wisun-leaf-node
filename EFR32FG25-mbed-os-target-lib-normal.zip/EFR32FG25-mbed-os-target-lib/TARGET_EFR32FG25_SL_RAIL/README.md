IEEE 802.15.4-2015+ RF driver with Wi-SUN compatibility
=======================================================

This document is an adaptation of the official [IEEE 802.15.4 PHY driver implementation guide](https://os.mbed.com/docs/mbed-os/v6.15/porting/6lowpan-port.html).

* It provides a guide to implement an IEEE 802.15.4-2015+ PHY driver compatible with Wi-SUN.
* It also provides a generic driver that can be easily adapted to a new radio platform.

Porting a new RF driver
-----------------------

The following steps describe how you can create a new RF driver:

1.  Please see the [Nanostack PHY API](https://github.com/ARMmbed/mbed-os/blob/master/features/nanostack/sal-stack-nanostack/nanostack/platform/arm_hal_phy.h).
    
2.  Please read through the [_Example RF driver_](#example-rf-driver) section. You can use this example code to start.
    
3.  Please see the reference implementations for [simple](https://github.com/ARMmbed/mbed-os/blob/master/components/802.15.4_RF/atmel-rf-driver/source/NanostackRfPhyAtmel.cpp) and [extended](https://github.com/ARMmbed/mbed-os/blob/master/components/802.15.4_RF/stm-s2lp-rf-driver/source/NanostackRfPhys2lp.cpp) RF drivers.
    
5.  Please see [_Implementing PHY API_](#implementing-the-phy-api) for details how to implement callbacks and API functions:
    
    * Global time stamp functionality.
    * RF driver registration.
    * Address write callback.
    * State control callback.
    * RF extension callback.
    * TX functionality.
    * RX functionality.
    * Worker thread.

Testing
-------

To verify the implementation of the RF driver, please create a working Mesh network and run the full set of Mbed OS Socket tests from [TESTS/netsocket](https://github.com/ARMmbed/mbed-os/blob/master/TESTS/netsocket/README.md).

Structure of the driver
-----------------------

The PHY RF driver is made out of two different parts :

- Implementation of the Nanostack RF PHY class which links the driver with the MAC layer in Nanostack (this class is called MAC instance)
- Implementation of the Nanostack PHY API which allows piloting the radio and getting/setting radio parameters

Implementing Nanostack RF PHY class (MAC instance)
--------------------------------------------------

To define the driver, a class which extends the `NanostackRfPhy` class must be defined. This class **must** be a singleton to avoid multiple instanciation of it.

<pre>
class Efr32RfDriver : public NanostackRfPhy {
public:
    Efr32RfDriver();
    ~Efr32RfDriver();
    int8_t rf_register();
    void rf_unregister();
    void get_mac_address(uint8_t *mac);
    void set_mac_address(uint8_t *mac);
    uint32_t get_driver_version();
private:
    bool _mac_is_set;
};
</pre>

Here is a description of each method that must be implemented.

| Method | Description |
|---|---|
| constructor() | Nothing specific to do |
| ~destructor() | Unregister the driver from Nanostack (with rf_unregister()) |
| rf_register() | Only proceed if the driver is **not** already registered into Nanostack (current instance is NULL)).<br>If no MAC address is set, generate a random MAC address (set the local bit to 1 (mac[0] \|= 2) and clear the multicast bit (mac[0) &= ~1)<br>Init the driver and the radio. If successful, store the current instance of the class. |
| rf_unregister() | Only proceed if the driver is already registered into Nanostack.<br>Unregister the driver from the Nanostack PHY API.<br>Set the current instance of the class to NULL. |
| get_driver_version() | Return the driver version (for example version[31:24] = major, version[23:16] = minor, version[15:8] = revision, version[7:0] = build) |
| set_mac_address(uint8_t *mac) | Only proceed if the driver is already registered into Nanostack.<br>Copy the content of the 64-bit buffer to a global variable storing the local MAC address. |
| get_mac_address(uint8_t *mac) | Copy the content of the global variable storing the local MAC address to the 64-bits buffer. |

Implementing the PHY API
------------------------

PHY API guidance is separated into _**simple**_ and _**extended**_ implementations, which depend on the configuration you use:

* You can use the _**simple**_ implementation with 6LoWPAN without frequency hopping (won't be covered here).
    
* The _**extended**_ implementation is required for:
    
    * 6LoWPAN with and without frequency hopping.
    * Wi-SUN.

The **extended** version provides more advanced features such as CSMA/CA algorithm, frequency hopping.

**Important note** Depending on the IEEE 802.15.4 frame version that is used, the PHY driver must implement specific features.
* For 2003, 2006, 2012 frames : Nanostack is not able to perform address filtering nor acknowledging frames. This must be managed inside the PHY driver.

* For 2015+ frames : Nanostack is able to filter/ACK inside the MAC layer. The driver must simply transmit the received frame to the MAC layer.

This document only covers the implementation for 2015+ frames because Wi-SUN does not use older versions.

### Global time stamp functionality

The RF driver must implement a timer with a one-microsecond resolution to return a 32-bit time stamp value. The driver must be able to return the current time stamp when Nanostack requests it. This timer must be started during initialization of the driver.

The function should be called `uint32_t rf_get_timestamp()`.

### RF driver registration

Use `arm_net_phy_register` to register the RF driver to Nanostack. The function returns the driver ID, which you must use when creating the MAC instance. You must fill the structure of `phy_driver`:

| Parameter | Value |
| --- | --- |
| `link_type` | `PHY_LINK_15_4_2_4GHZ_TYPE` or `PHY_LINK_15_4_SUBGHZ_TYPE`. |
| `PHY_MAC` | PHY driver must deliver a unique 64-bit MAC address. Assign the MAC that has been previously generated by the MAC instance class and stored in the global variable. |
| `driver_description` | Name of the driver. |
| `phy_channel_pages` | Default RF configurations. |
| `phy_MTU` | MTU size. Must be 2047 for IEEE 802.15.4-2015+ frames. |
| `phy_header_length` | Extra header to be allocated before the MAC frame. This depends on the radio requirements. For instance, for the EFR32 RAIL radio requires the PHY header (PHR) to be prepended to the MAC frame. The S2LP transceiver has another mechanism to specify the PHR without having to prepend it at the beginning of the frame. The PHR length for IEEE 802.15.4-2015+ frames is 2 bytes. |
| `phy_tail_length` | Extra tail to be allocated after the MAC frame. This depends on the radio requirements. This could be used to specify the frame control information (e.g. CRC). This is not required for EFR32 RAIL and S2LP.  |
| `address_write` | RF address write callback function. Used by Nanostack to write MAC long and short addresses, PAN address, etc. |
| `extension` | RF extension callback function. This function is called by Nanostack to configure/retrieve information from the driver during runtime. |
| `state_control` | RF state control callback function. This callback allows Nanostack to control the state of the interface (activation/deactivation). |
| `tx` | RF packet transmit callback function. Entry point for transmitting a packet. For the **extended** version of the driver required for Wi-SUN, this function must start the CSMA/CA process. |

Any other callbacks and parameters must be nullified.

### Address write callback

Nanostack calls the address write callback `int8_t (*address_write)(phy_address_type_e, uint8_t *)` to set addresses for RF receive filtering.

| Address type | Use |
| --- | --- |
| `PHY_MAC_64BIT` | Driver must set given 64-bit address (MAC address). (required) |
| `PHY_MAC_16BIT` | *Not required for 2015+ frames*. Sets the 16-bit address (short address). |
| `PHY_MAC_PANID` | *Not required for 2015+ frames*. Sets the 16-bit PAN ID for the receiver PAN ID filter. |

### State control callback

Nanostack calls the state control callback `int8_t (*state_control)(phy_interface_state_e, uint8_t)` to change the RF state.

| State | Use |
| --- | --- |
| `PHY_INTERFACE_RESET` | Driver must stop any active TX and RX processes and set radio to idle state. |
| `PHY_INTERFACE_DOWN` | Driver must stop any active TX and RX processes and set radio to sleep or idle state. |
| `PHY_INTERFACE_UP` | Driver must wake up the radio and enable receiver on a channel that was given as parameter. |
| `PHY_INTERFACE_RX_ENERGY_STATE` | *Not required*. Driver must initialize energy detection on a channel that was given as parameter. Nanostack reads the ED result using RF extension `PHY_EXTENSION_READ_CHANNEL_ENERGY`. |
| `PHY_INTERFACE_SNIFFER_STATE` | *Should act identically as `PHY_INTERFACE_UP` for 2015+ frames*. Driver must enable receiver on a channel that was given as parameter. All filtering must be disabled. This state is used only if device is set as Sniffer. |

### RF extension callback

Nanostack calls the RF extension callback `int8_t (*extension)(phy_extension_type_e, uint8_t *)` to set or get various PHY parameters. 

| Extension type | Use |
| --- | --- |
| `PHY_EXTENSION_SET_CHANNEL` | Driver must enable receiver on a channel which was given as parameter. If radio is currently receiving or transmitting (CSMA/CA process has started or frame is beeing sent) a packet, channel should be changed after the TX/RX process. The best is to apply the config when the radio is set to receive mode. |
| `PHY_EXTENSION_DYNAMIC_RF_SUPPORTED` | Driver must return 1 if it supports _**extended**_ RF driver implementation. By default, Nanostack assumes _**simple**_ implementation is used. Value (0 or 1) must be written to given (`uint8_t *`) parameter. This must return 1 for Wi-SUN support. |
| `PHY_EXTENSION_GET_TIMESTAMP` | Driver must return 32-bit time stamp by writing it to given (`uint8_t *`) parameter. |
| `PHY_EXTENSION_READ_RX_TIME` | Driver must return 32-bit time stamp corresponding to the time just after the SYNC word has been received by the radio for the last packet transmitted by the `rx_cb` callback to the MAC layer. **IMPORTANT NOTE** : The timestamp **must be written in big endian (network) format** to the data pointer. |
| `PHY_EXTENSION_SET_CSMA_PARAMETERS` | Driver must read `phy_csma_params_t` type structure behind given (`uint8_t *`) parameter. If parameter `backoff_time` is 0, any on-going transmission must be canceled (abort TX and stop CSMA/CA process) and radio set to receive state on the current channel. 32-bit `backoff_time` and boolean `cca_enabled` must be stored because they will be used for next packet transmission. |
| `PHY_EXTENSION_GET_SYMBOLS_PER_SECOND` | Driver must return symbol rate as symbols per second. 32-bit value must be written to given (`uint8_t *`) parameter. (symbol_rate = baudrate / bits_per_symbol) |
| `PHY_EXTENSION_SET_RF_CONFIGURATION` | Driver must read `phy_rf_channel_configuration_s` type structure behind given (`uint8_t *`) parameter. Driver must apply the given RF configuration as soon as possible. If radio is currently receiving or transmitting a frame, configuration should be changed after the TX/RX process. The best is to apply the config when the radio is set to receive mode. |
| `PHY_EXTENSION_SET_CHANNEL_CCA_THRESHOLD` | Driver must change the RSSI threshold that is used for CCA. The value behind `*data_ptr` is `(int8_t)`. |

### Worker thread

Nanostack's interfaces use mutexes for protecting the access from multiple threads. In Mbed OS, you cannot use the mutex from an interrupt. The same applies to all APIs that have internal locking and multithread support. Therefore, each driver must implement its own worker thread to handle the interrupt requests.

Example: Use the worker thread and signals from an interrupt.

    // Signals from interrupt routines
    #define SIG_RADIO       1
    #define SIG_TIMER       2
    #define SIG_ETC         4
    #define SIG_ALL         (SIG_RADIO|SIG_TIMER|SIG_ALL)
    
    // Worker thread
    Thread irq_thread;
    
    // Interrupt routines
    static void rf_interrupt(void)
    {
        irq_thread.signal_set(SIG_RADIO);
    }
    
    static void rf_timer_interrupt(void)
    {
        irq_thread.signal_set(SIG_TIMER);
    }
    
    
    // Worker thread
    void _rf_irq_thread_task(void)
    {
        while {
            uint32_t flags = ThisThread::flags_wait_any(SIG_ALL);
    
            if (flags & SIG_RADIO) {
                rf_process_irq();
            }
            if (flags & SIG_TIMER) {
                rf_process_timer();
            }
        }
    }
    
    ...
    // Somewhere in the initialization code
    irq_thread.start(_rf_irq_thread_task);
    

### TX functionality

Nanostack calls the TX callback `int8_t (*tx)(uint8_t *, uint16_t, uint8_t, data_protocol_e)` to start packet transmission. We only describe the _**extended**_ implementation.

1. The entry point for packet transmission is `rf_start_cca()` which is the function that starts the CSMA/CA process.
2. The TX callback must directly return -1 if the the driver is busy (state is different than IDLE or RX).
3. If the driver is not busy, the driver must write the sending frame to the TX fifo of the radio. Create and prepend the PHY header (PHR) at the beginning of the frame if the radio requires it.
4. Start the CSMA/CA process. Change driver state to _**CSMA_STARTED**_
    * a) If `backoff_time > 0`, start the CSMA timeout timer with a duration of `csma_ca_period = backoff_time - rf_get_timestamp()`. If `csma_ca_period > 65000`, start the timer with the smallest possible duration (1us) to trigger immediately CCA to try transmitting the packet as soon as possible.
    * b) If `backoff_time == 0`, start the timer with the smallest possible duration (1us) to trigger immediately CCA to try transmitting the packet as soon as possible.
5. Exit the TX callback by returning "0" (success). The driver waits until the CSMA timeout timer triggers.
5. When the CSMA/CA timeout has passed, the driver must call `phy_tx_done_cb` with status `PHY_LINK_CCA_PREPARE` to read the state of the CSMA/CA process from the MAC layer. State is given as a return value of the `phy_tx_done_cb` call.
6. If the state is `PHY_TX_NOT_ALLOWED`, cancel the transmission. There is no need for an additional `phy_tx_done_cb` call. Ensure the receiver is enabled.
7. If the state is `PHY_RESTART_CSMA`, check the CCA immediately (compare RSSI on the current channel to the RSSI threshold that has been set for CCA). If the channel is not available, call `phy_tx_done_cb` with status `PHY_LINK_CCA_FAIL`. If the channel is available, call `phy_tx_done_cb` with status `PHY_LINK_CCA_OK`. If `backoff_time > 0` restart the CSMA process (see 4.a) **BUT** don't restart if `backoff_time == 0`.  Note that Nanostack has updated CCA mode and backoff time with the `PHY_EXTENSION_SET_CSMA_PARAMETERS` event.
8. If the state is `PHY_TX_ALLOWED`, check the CCA immediately.
    * If the channel is not available, call `phy_tx_done_cb` with status `PHY_LINK_CCA_FAIL`. 
    * If the channel is available, start transmission of the packet immediately.
        * If the TX execution fails, call `phy_tx_done_cb` with status `PHY_LINK_TX_FAIL`.
        * When the worker thread detects that the radio has triggered the TX completion event in the radio IRQ, call `phy_tx_done_cb` with status `PHY_LINK_TX_SUCCESS`.
        * It is a good practice to also start a _**backup_timer**_ which puts the radio back to a known state if the radio never triggers the TX completion event in the radio IRQ. If this happens, call `phy_tx_done_cb` with status `PHY_LINK_TX_FAIL`.

### RX functionality

When Nanostack has called `PHY_INTERFACE_UP` RF state, the receiver must be kept enabled on a channel given by the `PHY_INTERFACE_UP` or `PHY_EXTENSION_SET_CHANNEL` event unless transmission is active until the `PHY_INTERFACE_RESET` or `PHY_INTERFACE_DOWN` RF state is called.

Nanostack is capable of filtering and acking IEEE 802.15.4-2015 frames. The RF driver must filter and ack any other frame version. For a received frame, the driver must call the RX callback `arm_net_phy_rx_fn *phy_rx_cb(const uint8_t *data_ptr, uint16_t data_len, uint8_t link_quality, int8_t dbm, int8_t driver_id)`, where:

* `data_ptr` \- Pointer to the beginning of received MAC frame.
* `data_len` \- MAC frame length.
* `link_quality` \- LQI of the received frame.
* `dbm` \- RSSI of the received frame.
* `driver_id` \- ID of the RF driver.

Procedure to receive an IEEE 802.15.4-2015+ frame :
1. When the radio IRQ triggers the RX completion event, check if the the packet is valid (CRC OK).
2. If the packet is valid, store the packet in the receive queue. Also store the length, LQI and RSSI of the packet in the queue in order to be able to retrieve them outside of IRQ context. Because multiple packets can be received by the radio before Nanostack/the worker thread consumes them it is recommended to use a queue that can store a few packets (6-8) to allow some latency in the packet reception process.
3. Tell the worker thread a new packet is available.
4. The worker thread must call `phy_rx_cb` for every packets available in the RX queue. Before calling, check if the the frame version is 2015+ by checking the frame version field inside the MAC Frame Control (FC) header. Drop the packet if the frame does not correspond.    
    
    

Generic RF driver
-----------------

The following code is a complete generic PHY driver which supports the _**extended**_ format. The driver provides a very strong hardware abstraction. Only a few function need some hardware specific modifications. All the required modifications are specified by the `TODO` flag.

    /**
    * @file MyDriver.cpp
    * @author Yann Charbon <yann.charbon@heig-vd.ch>
    * @brief PHY driver for IEEE 802.15.4-2015+ frames (Wi-SUN ready).
    * @version 1.0
    * @date 2022-05-03
    * 
    * @copyright Copyright (c) 2022
    * 
    */

    #include "MyDriver.h"   // TODO: change to your driver header file
    #include "nanostack/platform/arm_hal_phy.h"
    #include <Timer.h>
    #include "Timeout.h"
    #include "Thread.h"
    #include "platform/arm_hal_interrupt.h"
    #include "mbed_toolchain.h"
    #include "common_functions.h"
    #include "mbed.h"
    #include "randLIB.h"

    using namespace std::chrono;

    /* Driver specific headers */
    extern "C" {
    // TODO: include radio specific API files
    }

    #include "mbed-trace/mbed_trace.h"
    #define  TRACE_GROUP  "MYDRIVER"

    //#define MYDRIVER_DEBUG
    #ifdef MYDRIVER_DEBUG
    #ifndef MYDRIVER_TR_DEBUG
    #define MYDRIVER_TR_DEBUG(...) tr_debug(__VA_ARGS__)
    #endif
    #else
    #define MYDRIVER_TR_DEBUG(...)
    #endif

    /* Driver instance handle */
    static MyDriver *myDriverInstance = NULL;

    /* Nanostack related variables configuration */
    static uint8_t mac_address[8];
    phy_device_driver_s device_driver;
    int8_t rf_radio_driver_id = -1;
    uint8_t mac_tx_handle;


    /* ********************* Driver enumerations ************************** */

    /**
    * @enum driver_state
    * @brief Represents the state of the driver
    * 
    * @note IMPORTANT : this is not the state of the radio, but of the driver
    */
    enum driver_state {
        /// Driver is not initialized
        DRVSTATE_RADIO_UNINIT,
        /// Driver is beeing initialized but is not ready to be used
        DRVSTATE_RADIO_INITING,
        /// Driver is in a state where any operation/maintenance can be performed
        DRVSTATE_IDLE,
        /// Driver is listening channel for incoming packets
        DRVSTATE_IDLE_WAITING_RX,
        /// Driver is transmitting
        DRVSTATE_TX,
        /// Driver is receiving
        DRVSTATE_RX,
        /// Driver is inside the CSMA process
        DRVSTATE_CSMA_STARTED,
    };


    /**
    * @enum idle_state
    * @brief Represent the different idle states depths that can be reached * 
    */
    enum idle_state {
        /// Puts the radio in idle state after current TRX operation is finished
        RADIO_IDLE,
        /// Puts the radio in idle state immediately by cancelling the current TRX operation
        RADIO_IDLE_ABORT,
        /// Puts the radio in shutdown/sleep mode immediately by cancelling the current TRX operation and clearing any pending flags
        RADIO_SHUTDOWN,
    };

    /* ********************* Prototypes ************************** */

    /* *******************************
    * RF driver "public" functions *
    * *******************************
    */
    static int8_t rf_device_register(void);
    static void rf_device_unregister(void);
    static int8_t rf_interface_state_control(phy_interface_state_e new_state, uint8_t rf_channel);
    static int8_t rf_extension(phy_extension_type_e extension_type, uint8_t *data_ptr);
    static int8_t rf_address_write(phy_address_type_e address_type, uint8_t *address_ptr);
    static uint32_t rf_get_timestamp();
    static int8_t rf_start_cca(uint8_t *data_ptr, uint16_t data_length, uint8_t tx_handle, data_protocol_e data_protocol);

    /* *******************************
    * RF driver private functions *
    * *******************************
    */

    /* Initialization functions */
    static void _rf_init_radio();
    static void _rf_ready_cb();

    /* Interface control */
    static int _rf_interface_up(int8_t new_channel);
    static void _rf_reset_interface(enum idle_state state);

    /* Channel frequency, channel, etc., configuration functions  */
    static int _rf_check_and_change_channel(int8_t new_channel);
    static int _rf_check_and_apply_rf_config(phy_rf_channel_configuration_s *config, bool only_check);
    static int _rf_update_phy_config(phy_rf_channel_configuration_s *new_config);
    static void _rf_apply_phy_config();
    static void _rf_update_symbol_rate(uint32_t baudrate, phy_modulation_e modulation);

    /* Radio state related functions */
    static bool _rf_is_busy();
    static void _rf_set_idle(enum idle_state mode);
    static int _rf_set_rx();
    static void _rf_poll_state_change(enum driver_state expected_drv_state);

    /* Transmit, receive, CCA related functions */
    static uint16_t _rf_write_tx_fifo(uint8_t *dataPtr, uint16_t length, bool reset);
    static int _rf_execute_tx();
    static bool _rf_check_cca();
    static void _rf_handle_rx_end();

    /* Radio events handling IRQ and thread functions */
    static void _rf_events_irq_handler();
    static void _rf_irq_thread_task();

    /* CSMA timer realted functions */
    static void _rf_start_csma_timeout_timer(uint32_t duration);
    static void _rf_stop_csma_timeout_timer();
    static void _rf_rearm_csma_timeout_timer();
    static void _rf_csma_timeout_timer_cb();
    static void _rf_csma_timeout_handler();

    /* Backup timer related functions */
    static void _rf_start_backup_timer(uint32_t duration);
    static void _rf_stop_backup_timer();
    static void _rf_backup_timer_cb();
    static void _rf_backup_timeout_handler();

    /* *****************************************************/

    /* ********************* RF driver variables and macros ************************** */

    // Default config is Wi-SUN EU option 3
    static phy_rf_channel_configuration_s cur_phy_config = {863100000, 200000, 150000, 35, M_2FSK, MODULATION_INDEX_0_5};

    static phy_device_channel_page_s phy_channel_pages[] = {
        {CHANNEL_PAGE_0, &cur_phy_config},
        {CHANNEL_PAGE_0, NULL},
    }; 

    #define FIFO_SIZE 4096
    #define PACKET_SENDING_EXTRA_TIME   5000
    uint32_t MAX_PACKET_SENDING_TIME = (uint32_t)(8000000/cur_phy_config.datarate)*FIFO_SIZE + PACKET_SENDING_EXTRA_TIME;


    #define SIG_ALL             (SIG_RADIO_ERROR|SIG_CSMA_TIMEOUT|SIG_TIMER_BACKUP|SIG_PACKET_RECEIVED|SIG_PACKET_SENT|SIG_RX_FIFO_EVENTS)
    #define SIG_RADIO_ERROR     1
    #define SIG_CSMA_TIMEOUT    2
    #define SIG_TIMER_BACKUP    4
    #define SIG_PACKET_RECEIVED 8
    #define SIG_PACKET_SENT     16
    #define SIG_RX_FIFO_EVENTS  32

    static int8_t channel = -1;
    static int8_t new_channel = -1;
    static uint8_t tx_fifo[FIFO_SIZE];
    static uint8_t rxFifo[FIFO_SIZE];
    static Timer rf_timer; // For gloabl time stamp
    static Timeout csma_timeout_timer;
    static Timeout backup_timeout_timer;
    static Thread irq_thread(osPriorityRealtime, 1024);
    static enum driver_state driver_state = DRVSTATE_RADIO_UNINIT;
    static bool sleep_blocked = false;
    static volatile int radio_error_packet_status;
    static uint32_t rf_symbol_rate;
    static bool cca_enabled;
    static uint32_t backoff_time;
    static int16_t rssi_cca_threshold = RSSI_THRESHOLD;
    static bool phy_config_update_requested = false;
    static uint32_t cur_pkt_rx_sync_word_time = 0;
    static uint32_t last_pkt_rx_sync_word_time = 0;

    /* Queue for passing packets from interrupt to adaptor thread */

    /**
    * @enum rx_queue_event
    * @brief Represents the different events that can be triggered for the RX queue
    * 
    */
    enum rx_queue_event {
        RX_QUEUE_FULL,
        RX_QUEUE_ALMOST_FULL,
        RX_QUEUE_OVERFLOW,
    };

    /**
    * @struct rx_queue_slot
    * @brief Represents a slot in the RX queue
    * 
    */
    struct rx_queue_slot {
        uint8_t buffer[FIFO_SIZE];
        uint16_t length;
        uint8_t lqi;
        int8_t rssi;
        uint32_t rx_time;
    };

    #define RX_QUEUE_SLOTS 6
    static struct rx_queue_slot rx_queue[RX_QUEUE_SLOTS];
    static volatile size_t rx_queue_head = 0;
    static volatile size_t rx_queue_tail = 0;
    static volatile enum rx_queue_event rx_fifo_irq_event;




    /* ********************* RF driver "public" functions implementation ************************** */

    /**
    * @brief Configures the radio and the Nanostack PHY device driver
    * 
    * @return The driver ID or -1 if the driver is already initialized 
    */
    static int8_t rf_device_register(void){
        /* Avoid registering if already registered */
        if (driver_state != DRVSTATE_RADIO_UNINIT){
            return -1;
        }

        /* Init radio */
        _rf_init_radio();

        /* Update the actual symbol rate */
        _rf_update_symbol_rate(cur_phy_config.datarate, cur_phy_config.modulation);

        /* Set pointer to MAC address */
        device_driver.PHY_MAC = mac_address;
        /* Set driver Name */
        device_driver.driver_description = (char*)"My Wi-SUN compatible driver";

        /* Configuration for Sub GHz Radio */
        device_driver.link_type = PHY_LINK_15_4_SUBGHZ_TYPE;
        device_driver.phy_channel_pages = phy_channel_pages;

        /*Maximum size of payload is 2047*/
        device_driver.phy_MTU = 2047;
        /*2 bytes PHY header (PHR)*/
        device_driver.phy_header_length = 2;   // TODO: adjust depending on PHR management by radio
        /*No tail in PHY*/
        device_driver.phy_tail_length = 0;

        /*Set up driver functions*/
        device_driver.address_write = &rf_address_write;
        device_driver.extension = &rf_extension;
        device_driver.state_control = &rf_interface_state_control;
        device_driver.tx = &rf_start_cca;
        //Nullify rx/tx callbacks
        device_driver.phy_rx_cb = NULL;
        device_driver.phy_tx_done_cb = NULL;
        device_driver.arm_net_virtual_rx_cb = NULL;
        device_driver.arm_net_virtual_tx_cb = NULL;

        driver_state = DRVSTATE_RADIO_INITING;

        /*Register device driver*/
        rf_radio_driver_id = arm_net_phy_register(&device_driver);

        return rf_radio_driver_id;
    }

    /**
    * @brief Unregisters the PHY device driver from Nanostack
    * 
    */
    static void rf_device_unregister(void){
        arm_net_phy_unregister(rf_radio_driver_id);
        if (sleep_blocked) {
            sleep_manager_unlock_deep_sleep();
            sleep_blocked = false;
        }
    }

    /**
    * @brief This function is called by Nanostack to activate/deactivate the driver
    * 
    * @param new_state The state to which the driver should be changed
    * @param rf_channel The channel on which the driver should listen when it is started
    * @return 0 on success, -1 if channel could not be set 
    */
    static int8_t rf_interface_state_control(phy_interface_state_e new_state, uint8_t rf_channel)
    {
        int8_t ret_val = 0;
        switch (new_state)
        {
            /*Reset PHY driver and set to idle*/
            case PHY_INTERFACE_RESET:
                MYDRIVER_TR_DEBUG("PHY_INTERFACE_RESET");
                _rf_reset_interface(RADIO_IDLE_ABORT);
                break;
            /*Disable PHY Interface driver*/
            case PHY_INTERFACE_DOWN:
                MYDRIVER_TR_DEBUG("PHY_INTERFACE_DOWN");
                _rf_reset_interface(RADIO_SHUTDOWN);
                break;
            /*Enable PHY Interface driver
            * -> set channel
            * -> set RX mode */
            case PHY_INTERFACE_UP:
                MYDRIVER_TR_DEBUG("PHY_INTERFACE_UP");
                ret_val = _rf_interface_up(rf_channel);
                break;
            /*Enable wireless interface ED scan mode*/
            case PHY_INTERFACE_RX_ENERGY_STATE:
                // Not required
                break;
            /*Enable Sniffer state*/
            case PHY_INTERFACE_SNIFFER_STATE:
                MYDRIVER_TR_DEBUG("PHY_INTERFACE_SNIFFER_STATE");
                ret_val = _rf_interface_up(rf_channel);
                break;
        }
        return ret_val;
    }

    /**
    * @brief This function is called by Nanostack to configure/retrieve information from the driver during runtime
    * 
    * @param extension_type Parameter to get/set
    * @param data_ptr A pointer from which the parameter value can be read or to which data can be written
    * @return 0 on success, -1 on failure
    */
    static int8_t rf_extension(phy_extension_type_e extension_type, uint8_t *data_ptr)
    {
        uint32_t *data_ptr_32bits;
        phy_csma_params_t *new_csma_params;
        phy_rf_channel_configuration_s *new_channel_params;

        int ret = 0;

        switch (extension_type)
        {
            case PHY_EXTENSION_SET_CHANNEL:
                MYDRIVER_TR_DEBUG("PHY_EXTENSION_SET_CHANNEL %u\n", *data_ptr);
                if (driver_state == DRVSTATE_IDLE ||
                    driver_state == DRVSTATE_IDLE_WAITING_RX ||
                    driver_state == DRVSTATE_CSMA_STARTED){
                    new_channel = *data_ptr;
                    _rf_set_rx();
                } else {
                    // Store for later : channel could not be set yet
                    new_channel = *data_ptr;
                    ret = -1;
                }          
                break;
            case PHY_EXTENSION_DYNAMIC_RF_SUPPORTED:
                *data_ptr = true;
                break;
            case PHY_EXTENSION_GET_TIMESTAMP:
                data_ptr_32bits = (uint32_t *)data_ptr;
                *data_ptr_32bits = rf_get_timestamp();
                break;
            case PHY_EXTENSION_READ_RX_TIME:
                common_write_32_bit(cur_pkt_rx_sync_word_time, data_ptr);
                break;
            case PHY_EXTENSION_GET_SYMBOLS_PER_SECOND:
                data_ptr_32bits = (uint32_t *)data_ptr;
                *data_ptr_32bits = rf_symbol_rate;
                break;
            case PHY_EXTENSION_SET_CSMA_PARAMETERS:
                new_csma_params = (phy_csma_params_t*)data_ptr;
                if (new_csma_params->backoff_time == 0){
                    // Cancel any on-going transmission and set to RX state on current channel
                    _rf_stop_csma_timeout_timer();
                    _rf_set_idle(RADIO_IDLE_ABORT);
                    driver_state = DRVSTATE_IDLE;
                    _rf_set_rx();             
                    backoff_time = 0;                
                } else {
                    // Store backoff_time and cca_enabled
                    cca_enabled = new_csma_params->cca_enabled;
                    backoff_time = new_csma_params->backoff_time;
                }
                
                MYDRIVER_TR_DEBUG("PHY_EXTENSION_SET_CSMA_PARAMETERS : cca_enabled=%u backoff_time=%u", cca_enabled, backoff_time);
                break;
            case PHY_EXTENSION_SET_RF_CONFIGURATION:
                MYDRIVER_TR_DEBUG("PHY_EXTENSION_SET_RF_CONFIGURATION");
                new_channel_params = (phy_rf_channel_configuration_s*)data_ptr;            
                ret = _rf_update_phy_config(new_channel_params);
                break;
            case PHY_EXTENSION_SET_CHANNEL_CCA_THRESHOLD:
                MYDRIVER_TR_DEBUG("PHY_EXTENSION_SET_CHANNEL_CCA_THRESHOLD : old=%d new=%d", rssi_cca_threshold, (int16_t)*data_ptr);
                rssi_cca_threshold = (int8_t)*data_ptr;
                break;
            default:
                MYDRIVER_TR_DEBUG("Unhandled PHY_EXTENSION type (%d)", extension_type);
                break;
        }
        return ret;
    }

    /**
    * @brief Used by Nanostack to write MAC long and short addresses, PAN address, etc.
    * 
    * @param address_type Type of address)
    * @param address_ptr Buffer containing the address
    * @return 0 on success, -1 on failure 
    */
    static int8_t rf_address_write(phy_address_type_e address_type, uint8_t *address_ptr)
    {

        switch (address_type)
        {
            /*Set 48-bit address*/
            case PHY_MAC_48BIT:
                // 15.4 does not support 48-bit addressing
                break;
            /*Set 64-bit address*/
            case PHY_MAC_64BIT:
                /* Store MAC in MSB order */
                memcpy(mac_address, address_ptr, 8);
    #ifdef MYDRIVER_DEBUG
                tr_debug("rf_address_write: MAC");
                for (unsigned int i = 0; i < sizeof(mac_address); i ++) {
                    tr_debug("%02x:", mac_address[i]);
                }
                tr_debug("\n");
    #endif
                break;
            /*Set 16-bit address*/
            case PHY_MAC_16BIT:
                // Not required for IEEE 802.15.4-2015+ frames
                break;
            /*Set PAN Id*/
            case PHY_MAC_PANID:
                // Not required for IEEE 802.15.4-2015+ frames
                break;
        }

        return 0;
    }

    /**
    * @brief Gets the monotonic timestamp of the driver
    * 
    * @return Timestamp in microseconds
    *
    * The timestamp corresponds to the time since the driver was initialized. 
    */
    static uint32_t rf_get_timestamp(){
        return (uint32_t)rf_timer.elapsed_time().count();
    }

    /**
    * @brief Called by Nanostack to transmit a packet
    * 
    * @param data_ptr A pointer to the buffer containing the packet to be transmitted
    * @param data_length Packet length
    * @param tx_handle An ID that is used by Nanostack to track the packet inside the driver during the CSMA/CA process
    * @param data_protocol Not used here.
    * @return 0 on success, -1 if the driver is busy (already transmitting)
    */
    static int8_t rf_start_cca(uint8_t *data_ptr, uint16_t data_length, uint8_t tx_handle, data_protocol_e data_protocol){
        /*Check if transmitter is busy*/
        if(_rf_is_busy()) {
            return -1;
        }

        platform_enter_critical();

        driver_state = DRVSTATE_CSMA_STARTED;

        /*Save tx_handle to be able to use it inside IRQ handler*/
        mac_tx_handle = tx_handle;

        // TODO: depends on the radio. The PHY header can be managed differently depending on the radio.
        /*Create PHY header for Wi-SUN and insert it at beginning of TX buffer*/
        uint16_t phr = wisun_util_create_phy_header(data_length, WISUN_FAN_PROFILE);
        uint8_t* phr_0 = (uint8_t*)&phr;
        uint8_t* phr_1 = phr_0 + 1;
        data_ptr[0] = *phr_0;
        data_ptr[1] = *phr_1;

    #ifdef MYDRIVER_DEBUG
        printf("===== TX Packet (sending on channel %u) :\n", channel);
        for(int i=0; i < (data_length + device_driver.phy_header_length); i++){
            printf(" 0x%02X", data_ptr[i]);
        }
        printf("=====\n");
    #endif    

        /*Load data to TX FIFO*/
        _rf_write_tx_fifo(data_ptr, data_length + device_driver.phy_header_length, true);
        
    #ifdef MYDRIVER_DEBUG
        if(txFifo[IEEE_FRAME_CONTROL_BYTE_0 + device_driver.phy_header_length] & IEEE_TYPE_ACK){
            tr_warn("ACK length = %u\n", data_length + device_driver.phy_header_length);
        }
    #endif

        /*Calculate CSMA-CA period and activate timeout timer*/
        if (backoff_time > 0) {
            _rf_rearm_csma_timeout_timer();
        } else {
            // If there is no backoff time, we can start transmitting immediately
            _rf_start_csma_timeout_timer(1);
        }

        platform_exit_critical();

        /*Return success*/
        return 0;
    }

    /* ********************* RF driver private functions implementation ************************** */

    /**
    * @brief Initializes the radio
    * 
    * @return 0 on success, -1 on failure
    */
    static void _rf_init_radio(){
        ...

        irq_thread.start(mbed::callback(_rf_irq_thread_task));

        rf_timer.start();

        // TODO: init the radio

    }

    /**
    * @brief Callback for radio initialization completion
    *
    */
    static void _rf_ready_cb(){
        // TODO: call this after radio initialization
        driver_state = DRVSTATE_IDLE;
        MYDRIVER_TR_DEBUG("Radio Ready");
    }

    /**
    * @brief Activates the interface.
    * 
    * @param[in] new_channel The channel on which the interface should listen when it is started
    * @param[in] filtering Not use for IEEE 802.15.4-2015 frames because filtering is done by Nanostack
    * @return 0 on success, -1 if channel could not be set
    * 
    * When the interface is started, it will listen on the given channel.
    */
    static int _rf_interface_up(int8_t new_channel){
        if (_rf_check_and_change_channel(new_channel) == -1){
            return -1;
        }
        _rf_set_idle(RADIO_SHUTDOWN);
        driver_state = DRVSTATE_IDLE;
        _rf_set_rx();
        if (!sleep_blocked) {
            /* RX can only happen in EM0/1*/
            sleep_manager_lock_deep_sleep();
            sleep_blocked = true;
        }
        return 0;
    }

    /**
    * @brief Shuts interface down.
    * 
    * The radio is deactivated and the interface is not listening on any channel.
    */
    static void _rf_reset_interface(enum idle_state state){
        // Put radio to idle state
        _rf_set_idle(state);
        driver_state = DRVSTATE_IDLE;
        if (sleep_blocked) {
            sleep_manager_unlock_deep_sleep();
            sleep_blocked = false;
        }    
    }

    /**
    * @brief Changes the active channel of the radio with state conflict avoidance
    * 
    * @param[in] new_channel New channel to switch to
    * @return 0 on success, -1 on failure (channel not changed because radio is
    * emitting or receiving a packet)
    */
    static int _rf_check_and_change_channel(int8_t new_channel){
        if (driver_state == DRVSTATE_TX || driver_state == DRVSTATE_RX){
            return -1;
        }
        if (new_channel != channel && new_channel != -1) {
            channel = new_channel;
        }
        return 0;
    }

    /**
    * @brief Changes or checks a new RF channel configuration (no state verification).
    * 
    * @param[in] config The new RF configuration to use
    * @param[in] only_check If true, only checks if the new configuration is valid regarding the configuration supported by the driver
    * @return 0 on success, -1 on failure (config not valid)
    * 
    * @note IMPORTANT : this function does not check the state of the radio before applying the new configuration (use @ref _rf_update_phy_config if required).
    */
    static int _rf_check_and_apply_rf_config(phy_rf_channel_configuration_s *config, bool only_check){

        if (!(config->modulation == M_2FSK || config->modulation == M_GFSK)){
            return -1;
        }

        // TODO: add support for your radio
        
        tr_warn("No RF configuration has been found for the given parameters. Leaving the current configuration.");
        return -1;
    }

    /**
    * @brief Configure the radio for the given configuration (with state verification).
    * 
    * @param[in] new_config The new RF configuration to use.
    * @return 0 on success, -1 on failure (configuration is not valid). 
    */
    static int _rf_update_phy_config(phy_rf_channel_configuration_s *new_config){
        if (_rf_check_and_apply_rf_config(new_config, true) == 0){
            MYDRIVER_TR_DEBUG("Requested PHY configuration is valid");

            cur_phy_config.datarate = new_config->datarate;
            cur_phy_config.channel_spacing = new_config->channel_spacing;
            cur_phy_config.channel_0_center_frequency = new_config->channel_0_center_frequency;
            cur_phy_config.number_of_channels = new_config->number_of_channels;
            cur_phy_config.modulation = new_config->modulation;
            cur_phy_config.modulation_index = new_config->modulation_index;
            _rf_update_symbol_rate(cur_phy_config.datarate, cur_phy_config.modulation);

            if (driver_state == DRVSTATE_IDLE){
                MYDRIVER_TR_DEBUG("Applying new PHY configuration");
                _rf_apply_phy_config();
            } else {
                MYDRIVER_TR_DEBUG("Requesting PHY configuration update");
                phy_config_update_requested = true;
            }

            return 0;

        } else {
            tr_error("Requested PHY configuration is INVALID. Leaving previous configuration unchanged");
            return -1;
        }
        
    }

    /**
    * @brief Creates and applies a new RF configuration based on the PHY configuration.
    */
    static void _rf_apply_phy_config(){
        _rf_set_idle(RADIO_IDLE_ABORT);    

        _rf_check_and_apply_rf_config(&cur_phy_config, false);

        phy_config_update_requested = false;

        MYDRIVER_TR_DEBUG("PHY config has been applied");
    }

    /**
    * @brief Calculates and updates the symbol rate based on the datarate and the modulation.
    * 
    * @param[in] datarate The current dataratee.
    * @param[in] modulation The modulation that is used (not used here because only 2-FSK is supported).
    */
    static void _rf_update_symbol_rate(uint32_t baudrate, phy_modulation_e modulation)
    {
        (void) modulation;
        uint8_t bits_in_symbols = 1;
        rf_symbol_rate = baudrate / bits_in_symbols;
        MAX_PACKET_SENDING_TIME = (uint32_t)(8000000/cur_phy_config.datarate)*FIFO_SIZE + PACKET_SENDING_EXTRA_TIME;
    }

    /**
    * @brief Checks if the radio is busy (i.e. transmitting or receiving a packet).
    * 
    * @return true if the radio is busy, false otherwise.
    */
    static bool _rf_is_busy(){
        if (driver_state == DRVSTATE_IDLE || driver_state == DRVSTATE_IDLE_WAITING_RX){
            return false;
        } else {
            return true;
        }
    }

    /**
    * @brief Sets the radio to idle state.
    * 
    * @param[in] mode Specifies if the radio must abort ongoing operation (TRX) or must shutdown (see @ref idle_state).
    */
    static void _rf_set_idle(enum idle_state mode){
        if (mode == RADIO_IDLE){
            // TODO: set radio to IDLE
        } else if (mode == RADIO_IDLE_ABORT){
            // TODO: set radio to IDLE and abort ongoing operation
        } else if (mode == RADIO_SHUTDOWN){
            // TODO: shutdown radio
        } else {
            // TODO
        } 
    }

    /**
    * @brief Sets the to receive mode (with state verification).
    * 
    * @return 0 on success, other on failure. 
    * 
    */
    static int _rf_set_rx(){
        ...

        if (driver_state == DRVSTATE_TX) {
            return // TODO : other than 0;
        }

        /*Set channel*/
        _rf_check_and_change_channel(new_channel); 

        if(phy_config_update_requested){
            phy_config_update_requested = false;
            _rf_apply_phy_config();
        }

        // TODO : Set radio to RX mode
        if (driver_state != DRVSTATE_CSMA_STARTED) {
            driver_state = DRVSTATE_IDLE_WAITING_RX;
        }

        _rf_poll_state_change(DRVSTATE_IDLE_WAITING_RX);
        return //TODO : return 0 (success) or status;
    }

    /**
    * @brief Waits for the radio to enter the given state.
    *
    * @param[in] expected_drv_state The state that the radio must be in.
    */
    static void _rf_poll_state_change(enum driver_state expected_drv_state)
    {
        // TODO replace types and states : RF_STATE_TYPE new_radio_state = RF_STATE_TYPE_INACTIVE;
        uint16_t break_counter = 0;

        switch(expected_drv_state){
            case DRVSTATE_IDLE:
                new_radio_state = // TODO;
                break;
            case DRVSTATE_IDLE_WAITING_RX:
                new_radio_state = // TODO;
                break;
            case DRVSTATE_RX:
                new_radio_state = // TODO;
                break;
            case DRVSTATE_TX:
                new_radio_state = // TODO;
                break;
            default:
                break;
        }

        while (new_radio_state != // TODO : get state from radio) {
            if (break_counter++ == 0xffff) {
                tr_err("Failed to change state from %x to: %x", TODO : get state from radio, new_radio_state);
                break;
            }
        }
    }

    /**
    * @brief Writes a packet to the radio TX fifo.
    * 
    * @param dataPtr A pointer to the buffer containing the packet to be sent.
    * @param length Length of the packet to be sent (including PHY header (PHR) length).
    * @param reset A flag to tell if the TX fifo must be reset before writing the packet.
    * @return The number of bytes written to the TX fifo (should normally be equal to the length of the packet). 
    */
    static uint16_t _rf_write_tx_fifo(uint8_t *dataPtr, uint16_t length, bool reset){
        uint16_t nb_bytes_written;
        return nb_bytes_written = // TODO: write to TX fifo;
    }

    /**
    * @brief Sends the packet stored inside the TX fifo.
    * 
    * @return 0 on success, > 0 on failure.
    * 
    * This function is non-blocking. It only sets the radio to TX mode. The end of transmission is handled
    * by the radio IRQ handler @ref _rf_events_irq_handlerg.
    * 
    */
    static int _rf_execute_tx(){
        MYDRIVER_TR_DEBUG("Execute TX on channel %d", channel);

        // TX FIFO must be pre-filled with TX data
        platform_enter_critical();

        driver_state = DRVSTATE_TX;

        _rf_set_idle(RADIO_IDLE_ABORT);

        status = // TODO: send the packet

        if (status != // TX ERROR ){
            // TX error
            _rf_set_idle(RADIO_IDLE_ABORT);
            driver_state = DRVSTATE_IDLE;
            _rf_set_rx();
            platform_exit_critical();
            return (int)status;
        }   

        _rf_start_backup_timer(MAX_PACKET_SENDING_TIME);

        platform_exit_critical(); 
        return // status;
    }

    /**
    * @brief Checks if the current channel is clear to send.
    * 
    * @return true if the channel is clear to send, false otherwise.
    */
    static bool _rf_check_cca(){   
        if(!cca_enabled){
            return true;
        }

        int16_t rssi; 
        unsigned int tries = 0;
        MYDRIVER_TR_DEBUG("check_cca()");
        if(!_rf_set_rx()){
            MYDRIVER_TR_DEBUG("Could not start RX mode");
        }

        // TODO: measure RSSI

        if(rssi > rssi_cca_threshold){
            return false;
        } else {
            return true;
        }
    }


    /**
    * @brief Handles the end of packet reception by sending the received packets to the MAC layer.
    * 
    * This function is called by the IRQ thread (see @ref _rf_irq_thread_task) when the radio IRQ handler (see @ref _rf_events_irq_handler)
    * has processed a new packet and added it to the RX queue. Because multiple packets can be received before the IRQ thread is able to call
    * this function, a queue is required to store the received packets before handling them.
    * 
    * @note This function sends only the IEEE 802.15.4-2015 compliant packets. All packets that have an older version are discarded.
    */
    static void _rf_handle_rx_end(){
        while (rx_queue_tail != rx_queue_head) {
            // Handle every packet that are available in the queue

            struct rx_queue_slot *rx_slot = &rx_queue[rx_queue_tail];

            rx_queue_tail = (rx_queue_tail + 1) % RX_QUEUE_SLOTS;

            cur_pkt_rx_sync_word_time = rx_slot->rx_time;   

            if (((rx_slot->buffer[IEEE_FRAME_CONTROL_BYTE_1 + device_driver.phy_header_length] & IEEE_FRAME_VERSION_MASK) >> IEEE_FRAME_VERSION_SHIFT) == IEEE_VERSION_2015){
                if (device_driver.phy_rx_cb)
                    device_driver.phy_rx_cb(&rx_slot->buffer[device_driver.phy_header_length],
                                            rx_slot->length - device_driver.phy_header_length,
                                            rx_slot->lqi,
                                            rx_slot->rssi,
                                            rf_radio_driver_id);
            } else {
                    // Driver does not support IEEE 802.15.4-2006/2003 frames
                    printf("Driver does not support IEEE 802.15.4-2006/2003 frames\n");
            }        
        }

    }

    /**
    * @brief IRQ handler for the events generated by the radio.
    * 
    */
    static void _rf_events_irq_handler(/* TODO: add parameters */){
        // TODO: check IRQ source and adapt to the specific radio

        if (events & SYNC_WORD_DETECTED){
            driver_state = DRVSTATE_RX;
            last_pkt_rx_sync_word_time = rf_get_timestamp();
            _rf_start_backup_timer(MAX_PACKET_SENDING_TIME);
        }

        if (events & PACKET_RECEIVED) {
            if (packet_is_valid) {}
                // Drop this packet if the RX queue is out of space
                if (((rx_queue_head + 1) % RX_QUEUE_SLOTS) == rx_queue_tail) {
                    rx_fifo_irq_event = RX_QUEUE_FULL;
                    irq_thread.flags_set(SIG_RX_FIFO_EVENTS); 
                    // TODO : release packet
                }

                // Get the next available slot in the RX queue
                struct rx_queue_slot *rx_slot = &rx_queue[rx_queue_tail];

                // TODO : copy content of packet and release packet

                // Store the packet parameters along with the packet payload in the queue slot
                rx_slot->buffer = packet_payload;
                rx_slot->rssi = packet_rssi;
                rx_slot->lqi = packet_lqi;
                rx_slot->length = packet_length;
                rx_slot->rx_time = last_pkt_rx_sync_word_time;

                rx_queue_head = (rx_queue_head + 1) % RX_QUEUE_SLOTS;
                irq_thread.flags_set(SIG_PACKET_RECEIVED);
            } else {
                irq_thread.flags_set(SIG_RADIO_ERROR);
                radio_error_packet_status = // some status (CRC fail, etc.));
            }
            driver_state = DRVSTATE_IDLE_WAITING_RX;               
        }


        if (events & TX_COMPLETION){
            _rf_stop_backup_timer();
            _rf_set_idle(RADIO_IDLE_ABORT);
            driver_state = DRVSTATE_IDLE_WAITING_RX;
            _rf_set_rx();
            irq_thread.flags_set(SIG_PACKET_SENT);
        }

        if (events & RX_ALMOST_FULL){
            rx_fifo_irq_event = RX_QUEUE_ALMOST_FULL;
            irq_thread.flags_set(SIG_RX_FIFO_EVENTS);
        }

        if (events & RX_ALMOST_FULL){
            rx_fifo_irq_event = RX_QUEUE_OVERFLOW;
            irq_thread.flags_set(SIG_RX_FIFO_EVENTS);
        }    
    }

    /**
    * @brief This function is the task assigned to the IRQ thread.
    * 
    * This task is responsible for taking information out of the IRQ context.
    * 
    */
    static void _rf_irq_thread_task(){
        while (1) {
        uint32_t flags = ThisThread::flags_wait_any(SIG_ALL);
            platform_enter_critical();
            if (flags & SIG_RADIO_ERROR) {
                tr_error("RADIO_ERROR");
            }
            if (flags & SIG_CSMA_TIMEOUT) {
                _rf_csma_timeout_handler();
            }
            if (flags & SIG_TIMER_BACKUP) {
                _rf_backup_timeout_handler();
            }
            if (flags & SIG_RX_FIFO_EVENTS) {
                switch(rx_fifo_irq_event){
                    case RX_QUEUE_ALMOST_FULL:
                        tr_warn("/!\\ RX queue almost full");
                        break;
                    case RX_QUEUE_FULL:
                        tr_error("/!\\ RX queue is full (packet dropped)");
                        break;
                    case RX_QUEUE_OVERFLOW:
                        tr_error("/!\\ RX queue overflow (packet dropped)");
                        break;
                }            
            }
            if (flags & SIG_PACKET_RECEIVED) {
                _rf_handle_rx_end();
            }
            if (flags & SIG_PACKET_SENT) {
                // TX success
                if (device_driver.phy_tx_done_cb)
                    device_driver.phy_tx_done_cb(rf_radio_driver_id, 
                                                            mac_tx_handle, PHY_LINK_TX_SUCCESS, 0, 0);   
            }
            platform_exit_critical();
        }
    }

    /**
    * @brief Starts the CSMA-CA timer
    * 
    * @param[in] duration before triggering the CSMA-CA timeout callback
    */
    static void _rf_start_csma_timeout_timer(uint32_t duration){
        csma_timeout_timer.attach(_rf_csma_timeout_timer_cb, microseconds(duration));
    }

    /**
    * @brief Stops the CSMA-CA timer 
    */
    static void _rf_stop_csma_timeout_timer(){
        csma_timeout_timer.detach();
    }

    /**
    * @brief CSMA-CA timeout callback 
    */
    static void _rf_csma_timeout_timer_cb(){
        irq_thread.flags_set(SIG_CSMA_TIMEOUT);
    }

    /**
    * @brief Starts/restarts the CSMA-CA timer based on the requested backoff time * 
    */
    static void _rf_rearm_csma_timeout_timer(){
        uint32_t csma_ca_period = backoff_time - rf_get_timestamp();

        if(csma_ca_period > 65000){
            // Time has already passed, trigger the IRQ immediately for immediate TX
            csma_ca_period = 1;
        } 

        _rf_start_csma_timeout_timer(csma_ca_period);
    }


    /**
    * @brief CSMA-CA timeout handler called by the IRQ thread task
    * 
    * This function tells to the MAC layer that the CSMA-CA timeout has occurred.
    * The MAC layer is responsible to tell what to do next. Depending on the status
    * that the MAC layer returns, this function will either cancel the transmission,
    * start the transmission or start the CSMA-CA procedure again.
    */
    static void _rf_csma_timeout_handler(){
        int8_t status = -1;

        // Request CSMA status from Nanostack
        if (device_driver.phy_tx_done_cb)
            status = device_driver.phy_tx_done_cb(rf_radio_driver_id, 
                                                                    mac_tx_handle, PHY_LINK_CCA_PREPARE, 0, 0);
        
        switch (status){
        case PHY_TX_NOT_ALLOWED:
            if (driver_state == DRVSTATE_CSMA_STARTED) {
                _rf_set_idle(RADIO_IDLE_ABORT);
                driver_state = DRVSTATE_IDLE;
                _rf_set_rx();
            }
            break;   
        case PHY_RESTART_CSMA:
            if (driver_state == DRVSTATE_RX){
                if (device_driver.phy_tx_done_cb)
                    device_driver.phy_tx_done_cb(rf_radio_driver_id, mac_tx_handle, PHY_LINK_CCA_FAIL_RX, 0, 0);
            } else if (!_rf_check_cca()) {
                // Channel is busy
                if (device_driver.phy_tx_done_cb)
                    device_driver.phy_tx_done_cb(rf_radio_driver_id, mac_tx_handle, PHY_LINK_CCA_FAIL, 0, 0);
            } else {
                // Channel is clear
                if (device_driver.phy_tx_done_cb)
                    device_driver.phy_tx_done_cb(rf_radio_driver_id, mac_tx_handle, PHY_LINK_CCA_OK, 0, 0);

                if (backoff_time > 0) {
                    _rf_rearm_csma_timeout_timer();
                }
            }
            break;   
        case PHY_TX_ALLOWED:
            if (driver_state == DRVSTATE_RX){
                if (device_driver.phy_tx_done_cb)
                    device_driver.phy_tx_done_cb(rf_radio_driver_id, mac_tx_handle, PHY_LINK_CCA_FAIL_RX, 0, 0);
            } else if(!_rf_check_cca()){
                MYDRIVER_TR_DEBUG("Channel is busy");
                // Channel is busy
                if (device_driver.phy_tx_done_cb)
                    device_driver.phy_tx_done_cb(rf_radio_driver_id, 
                                                                    mac_tx_handle, PHY_LINK_CCA_FAIL, 0, 0);
            } else {
                MYDRIVER_TR_DEBUG("Channel is clear");
                // Channel is clear -> start transmission immediately
                if (_rf_execute_tx() != 0){
                    MYDRIVER_TR_DEBUG("TX fail");
                    if (device_driver.phy_tx_done_cb)
                        device_driver.phy_tx_done_cb(rf_radio_driver_id, 
                                                                    mac_tx_handle, PHY_LINK_TX_FAIL, 0, 0);
                }
                // TX success is called in _rf_rail_events_irq_handler()
            }
            break;  
        default:
            break;
        }
    }

    /**
    * @brief Starts the backup timer
    * 
    * @param[in] duration before triggering the backup timeout callback
    * 
    * The backup timer is responsible to put the radio in a known state in case of unexpected radio failure.
    */
    void _rf_start_backup_timer(uint32_t duration){
        backup_timeout_timer.attach(_rf_backup_timer_cb, microseconds(duration));
    }

    /**
    * @brief Stops the backup timer 
    */
    void _rf_stop_backup_timer(){
        backup_timeout_timer.detach();
    }

    /**
    * @brief Backup timeout callback 
    */
    void _rf_backup_timer_cb(){
        irq_thread.flags_set(SIG_TIMER_BACKUP);
    }

    /**
    * @brief Backup timeout handler called by the IRQ thread task
    */
    static void _rf_backup_timeout_handler(){
        if (driver_state == DRVSTATE_TX) {
            // Radio is stuck in TX state, reset it
            if (device_driver.phy_tx_done_cb) {
                device_driver.phy_tx_done_cb(rf_radio_driver_id, mac_tx_handle, PHY_LINK_TX_FAIL, 0, 0);
            }
            driver_state = DRVSTATE_IDLE;
            _rf_set_idle(RADIO_IDLE_ABORT);
            _rf_set_rx();
        } else if (driver_state == DRVSTATE_RX){
            driver_state = DRVSTATE_IDLE_WAITING_RX;
        }
    }

    /* *******************************
    * Nanostack backend related functions *
    * *******************************
    */

    /**
    * @brief Gets the MAC address of the PHY
    * 
    * @param[out] mac A pointer to an 8 bytes buffer where the MAC address will be stored 
    */
    void MyDriver::get_mac_address(uint8_t *mac)
    {
        platform_enter_critical();

        memcpy(mac, mac_address, sizeof(mac_address));

        platform_exit_critical();
    }

    /**
    * @brief Sets the MAC address of the PHY
    * 
    * @param[out] mac A pointer to an 8 bytes buffer containing the MAC address to be set  
    */
    void MyDriver::set_mac_address(uint8_t *mac)
    {
        MYDRIVER_TR_DEBUG("set_mac_address: MAC");
        platform_enter_critical();

        if (NULL != myDriverInstance) {
            error("MyDriver cannot change mac address when running");
            platform_exit_critical();
            return;
        }

        memcpy(mac_address, mac, sizeof(mac_address)); 
        _mac_is_set = true;   

        platform_exit_critical();

    #ifdef MYDRIVER_DEBUG
        tr_debug("set_mac_address: MAC\n");
        for (int i = 0; i < sizeof(mac_address); i++) {
            tr_debug("%02x:", mac_address[i]);
        }
        tr_debug("\n");
    #endif
    }

    /**
    * @brief Gets the PHY radio version
    * 
    * @return The PHY radio version
    */
    uint32_t MyDriver::get_driver_version()
    {
        // TODO
    }

    /**
    * @brief Register and initializes the PHY driver into Nanostack
    * 
    * @return The radio driver ID on success, -1 if the PHY driver is already registered 
    */
    int8_t MyDriver::rf_register()
    {
        platform_enter_critical();

        if (myDriverInstance != NULL) {
            platform_exit_critical();
            error("Multiple registrations of MyDriver not supported");
            return -1;
        }

        if (!_mac_is_set) {
            uint8_t new_mac[8];

            tr_warn("No MAC has been assigned yet -> generating random MAC");
            randLIB_seed_random();
            randLIB_get_n_bytes_random(new_mac, 8);
            new_mac[0] |= 2; //Set Local Bit
            new_mac[0] &= ~1; //Clear multicast bit

            set_mac_address(new_mac);
        }

        int8_t radio_id = rf_device_register();
        if (radio_id < 0) {
            myDriverInstance = NULL;
        } else {
            myDriverInstance = this;
        }

        platform_exit_critical();
        return radio_id;
    }

    /**
    * @brief Removes the PHY driver from Nanostack
    */
    void MyDriver::rf_unregister()
    {
        platform_enter_critical();

        if (myDriverInstance != this) {
            platform_exit_critical();
            return;
        }

        rf_device_unregister();
        myDriverInstance = NULL;

        platform_exit_critical();
    }

    /**
    * @brief Constructs a new MyDriver object 
    */
    MyDriver::MyDriver() : NanostackRfPhy(), _mac_is_set(false)
    {
        // Do nothing
    }

    /**
    * @brief Destroys the MyDriver object
    * 
    */
    MyDriver::~MyDriver()
    {
        rf_unregister();
    }

    /**
    * @brief Retrieves the instance of the MyDriver PHY driver
    * 
    * @return Reference to the MyDriver instance
    */
    NanostackRfPhy &NanostackRfPhy::get_default_instance()
    {
        static MyDriver rf_phy;
        return rf_phy;
    }