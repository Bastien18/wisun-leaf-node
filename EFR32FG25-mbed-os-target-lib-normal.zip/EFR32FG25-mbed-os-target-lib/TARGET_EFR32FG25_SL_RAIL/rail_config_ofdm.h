#ifndef __RAIL_CONFIG_OFDM_H__
#define __RAIL_CONFIG_OFDM_H__

#define RF_EU1_OFDM_OPTION_1_CHAN_OFFSET    1000
#define RF_EU1_OFDM_OPTION_2_CHAN_OFFSET    2000
#define RF_EU1_OFDM_OPTION_3_CHAN_OFFSET    3000
#define RF_EU1_OFDM_OPTION_4_CHAN_OFFSET    4000
#define RF_NA_OFDM_OPTION_1_CHAN_OFFSET     5000
#define RF_NA_OFDM_OPTION_2_CHAN_OFFSET     6000
#define RF_NA_OFDM_OPTION_3_CHAN_OFFSET     7000
#define RF_NA_OFDM_OPTION_4_CHAN_OFFSET     8000

// Private
RAIL_ChannelConfigEntry_t * rf_set_config_eu1_ofdm_option_1(phy_rf_channel_configuration_s *mbed_channel_config);
RAIL_ChannelConfigEntry_t * rf_set_config_eu1_ofdm_option_2(phy_rf_channel_configuration_s *mbed_channel_config);
RAIL_ChannelConfigEntry_t * rf_set_config_eu1_ofdm_option_3(phy_rf_channel_configuration_s *mbed_channel_config);
RAIL_ChannelConfigEntry_t * rf_set_config_eu1_ofdm_option_4(phy_rf_channel_configuration_s *mbed_channel_config);
RAIL_ChannelConfigEntry_t * rf_set_config_na_ofdm_option_1(phy_rf_channel_configuration_s *mbed_channel_config);
RAIL_ChannelConfigEntry_t * rf_set_config_na_ofdm_option_2(phy_rf_channel_configuration_s *mbed_channel_config);
RAIL_ChannelConfigEntry_t * rf_set_config_na_ofdm_option_3(phy_rf_channel_configuration_s *mbed_channel_config);
RAIL_ChannelConfigEntry_t * rf_set_config_na_ofdm_option_4(phy_rf_channel_configuration_s *mbed_channel_config);

#endif