/**
 * @file efr32_rf_wisun_util.c
 * @author Yann Charbon <yann.charbon@heig-vd.ch>
 * @brief This file contains the utility functions related to Wi-SUN for the PHY driver.
 * @version 0.1
 * @date 2022-05-03
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "efr32_rf_wisun_util.h"
#include "cmsis_gcc.h"

uint16_t reverse_bits_uint16(uint16_t s) {
   uint16_t tmp = 0;
   uint8_t i = 15;

   while (i--){
        tmp |= ((s & (1 << i)) >> i) << (15 - i);
   }

   return tmp;
}

uint16_t wisun_util_create_phy_header_sun_fsk(uint16_t data_length, enum wisun_profile_type profile_type){
    uint16_t phr = 0;
    /* PHY header :
    * Bit 0 : Mode Switch -> Always equal to 0 for Wi-SUN
    * Bit 1-2 : Reserved -> Always equal to 0
    * Bit 3 : FCS (Frame Check Sequence) -> WISUN_FAN_PROFILE profile : 0 (4 octets CRC), WISUN_ECHONET_PROFILE/WISUN_JUTA_PROFILE profile : 1 (2 octets CRC)
    * Bit 4 : Data whitening -> Always equal to 1 for Wi-SUN
    * Bit 5-15 : Data length -> Bit 5 is MSB, bit 15 is LSB
    *
    * The whole PHY header must be constructed backwards because the data length field is an LSB to MSB field which must fit into an MSB to LSB field.
    * It is needed to reverse the bits because the radio must send the header from MSB to LSB.
    *
    * Example :
    * phr = 0b0001100000001011;    // frame in LSB format : FCS = 1, data whitening = 1, data length = 11
    * phr = 0b1101000000011000;    // reversed frame in MSB format
    * tx_buf = { 0b11010000, 0b00011000, data };   // This is how the frame must be sent by radio
    */

    // Frame in LSB format
    if (profile_type == WISUN_FAN_PROFILE){
        phr |= ( (0 << 15) | (0 << 12) | (1 << 11) | (((data_length + 4) & 0x7FF) << 0) );
    }
    else if (profile_type == WISUN_ECHONET_PROFILE || profile_type == WISUN_JUTA_PROFILE){
        phr |= ( (0 << 15) | (1 << 12) | (1 << 11) | (((data_length + 2) & 0x7FF) << 0) );
    }
    else{
        return WISUN_HEADER_INVALID_PROFILE;
    }

    // Frame in MSB format
    phr = reverse_bits_uint16(phr);
    return phr;
}

uint32_t wisun_util_create_phy_header_sun_ofdm(uint16_t data_length, int mcs){
    uint32_t phr = 0;

    uint8_t rate = (mcs & 0x1F);
    data_length += 4;
    uint8_t scrambler = 0;   // IEEE 802.15.4-2020 20.4.11 Scrambler and scrambler seeds
    phr = (rate << 19) | (data_length << 7) | (scrambler << 3);

    // Frame in MSB format
    //phr = reverse_bits_uint16(phr);
    phr = __RBIT(phr);
    return phr;
}