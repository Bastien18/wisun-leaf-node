/**
 * @file rail_config.c
 * @author Yann Charbon <yann.charbon@heig-vd.ch>
 * @brief Contains all the configurations that are supported by the RAIL library for Wi-SUN.
 * @version 1.0
 * @date 2023-06
 *
 * @copyright Copyright (c) 2023
 *
 * @details The values that are defined in this file have been automatically generated with
 *  Simplicity Studio. To avoid storing one specific copy of the radio configuration tables
 *  (irCalConfig, phyInfo, Protocol_Configuration_modemConfigBase) for every config (which
 *  takes quite a lot of memory space), each configuration only changes the fields that differ
 *  in each configuration. This way, all the common fields are only stored once.
 *
 */

#include "em_device.h"
#include "rail_config.h"
#include "rail_config_fsk.h"

__ALIGNED(4) uint8_t convDecodeBuffer[64];

static const uint8_t irCalConfig[] = {
  20, 41, 2, 0, 0, 57, 19, 0, 0, 0, 1, 0, 2, 100, 0, 1, 1, 47, 0, 0, 7
};

static const uint8_t txIrCalConfig[5] = {
  0x00, 0x03, 5, 5, 5
};

#if RAIL_SUPPORTS_HFXO_COMPENSATION
static const int16_t modemTxCompensation_0[33] = {
  0x2b94, 0xce67, 0x273a, 0x277f, 0xd881, 0x3121, 0x2398, 0xe2ab, 0x4120, 0x1f90, 0xecff, 0x611e, 0x1b90, 0xf602, 0xc3, 0x1790, 0x00fe, 0x60bd, 0x1390, 0x0a02, 0xc3, 0xf90, 0x14ff, 0x611f, 0xb98, 0x1eab, 0x4121, 0x77f, 0x2881, 0x3122, 0x394, 0x3267, 0x273b
};

static const int16_t modemTxCompensation_1[33] = {
  0x2b94, 0xce67, 0x139d, 0x2790, 0xd87f, 0x182f, 0x2398, 0xe2ab, 0x2090, 0x1f90, 0xecff, 0x308f, 0x1b90, 0xf604, 0xc3, 0x1790, 0x00fc, 0x2ffd, 0x1390, 0x0a04, 0xc3, 0xf90, 0x14fd, 0x302e, 0xb98, 0x1ea9, 0x202f, 0x77f, 0x2881, 0x1891, 0x394, 0x32ce, 0x273b
};

static const int16_t modemTxCompensation_2[33] = {
  0x2bd2, 0xce02, 0x41, 0x27d2, 0xd802, 0x41, 0x23d2, 0xe202, 0x41, 0x1fd2, 0xec02, 0x41, 0x1bd2, 0xf602, 0x41, 0x17b2, 0x00fe, 0x203f, 0x13d2, 0x0a02, 0x41, 0xfd2, 0x1402, 0x41, 0xbd2, 0x1e02, 0x41, 0x7d2, 0x2802, 0x41, 0x3d2, 0x3202, 0x41
};

static const int16_t modemTxCompensation_3[33] = {
  0x2bb4, 0xcece, 0x139d, 0x27b0, 0xd8fe, 0x182f, 0x23b8, 0xe2ab, 0x1048, 0x1fb0, 0xecfb, 0x17e6, 0x1bb0, 0xf608, 0xc3, 0x17b0, 0x00f8, 0x179d, 0x13b0, 0x0a08, 0xc3, 0xfb0, 0x14fd, 0x1817, 0xbb7, 0x1ead, 0x1079, 0x7b0, 0x287d, 0xbe7, 0x3b4, 0x3265, 0x99e
};

static const int16_t modemTxCompensation_4[33] = {
  0x2bf2, 0xce04, 0x41, 0x27f2, 0xd804, 0x41, 0x23f2, 0xe204, 0x41, 0x1ff2, 0xec04, 0x41, 0x1bf2, 0xf604, 0x41, 0x17b2, 0x00fc, 0xfff, 0x13f2, 0x0a04, 0x41, 0xff2, 0x1404, 0x41, 0xbf2, 0x1e04, 0x41, 0x7f2, 0x2804, 0x41, 0x3f2, 0x3204, 0x41
};

static const int16_t modemTxCompensation_5[33] = {
  0x2bb4, 0xce67, 0x139d, 0x27b0, 0xd87f, 0x182f, 0x23b8, 0xe2ab, 0x2090, 0x1fb0, 0xecff, 0x308f, 0x1bb0, 0xf604, 0xc3, 0x17b0, 0x00fc, 0x2ffd, 0x13b0, 0x0a04, 0xc3, 0xfb0, 0x14fd, 0x302e, 0xbb8, 0x1ea9, 0x202f, 0x79f, 0x2881, 0x1891, 0x3b4, 0x32ce, 0x273b
};

static const int16_t modemTxCompensation_6[33] = {
  0x2bd4, 0xcece, 0x139d, 0x27d0, 0xd8fe, 0x182f, 0x23d8, 0xe2ab, 0x1048, 0x1fd0, 0xecfb, 0x17e6, 0x1bd0, 0xf608, 0xc3, 0x17d0, 0x00f8, 0x179d, 0x13d0, 0x0a08, 0xc3, 0xfd0, 0x14fd, 0x1817, 0xbd7, 0x1ead, 0x1079, 0x7d0, 0x287d, 0xbe7, 0x3d4, 0x3265, 0x99e
};

static const int16_t modemTxCompensation_7[33] = {
  0x2b74, 0xce67, 0x273a, 0x275f, 0xd881, 0x3121, 0x2378, 0xe2ab, 0x4120, 0x1f70, 0xecff, 0x611e, 0x1b70, 0xf602, 0xc3, 0x1770, 0x00fe, 0x60bd, 0x1370, 0x0a02, 0xc3, 0xf70, 0x14ff, 0x611f, 0xb78, 0x1eab, 0x4121, 0x75f, 0x2881, 0x3122, 0x374, 0x3267, 0x273b
};
#endif

static const int32_t timingConfig_0[] = {
  200000, 200000, 0
};

static const int32_t timingConfig_1[] = {
  120000, 120000, 0
};

static const int32_t timingConfig_2[] = {
  66666, 66666, 0
};

static const int32_t timingConfig_3[] = {
  50000, 50000, 0
};

static const int32_t timingConfig_4[] = {
  30000, 30000, 0
};

static const int32_t timingConfig_5[] = {
  70000, 70000, 0
};

static const int32_t timingConfig_6[] = {
  40000, 40000, 0
};

static const int32_t timingConfig_7[] = {
  140000, 140000, 0
};

static const uint8_t hfxoRetimingConfigEntries[] = {
  1, 0, 0, 0, 0xc0, 0x17, 0x53, 0x02, 4, 12, 0, 0, 0xe0, 0x02, 0, 0, 0, 0, 0x3c, 0x03, 1, 2, 5, 4, 0x98, 0x03, 1, 2, 5, 5, 0xf4, 0x03, 1, 2, 6, 5
};

static RAIL_ChannelConfigEntryAttr_t channelConfigEntryAttr = {
#if RAIL_SUPPORTS_OFDM_PA
  {
#ifdef RADIO_CONFIG_ENABLE_IRCAL_MULTIPLE_RF_PATHS
    { 0xFFFFFFFFUL, 0xFFFFFFFFUL, },
#else
    { 0xFFFFFFFFUL },
#endif // RADIO_CONFIG_ENABLE_IRCAL_MULTIPLE_RF_PATHS
    { 0xFFFFFFFFUL, 0xFFFFFFFFUL }
  }
#else // RAIL_SUPPORTS_OFDM_PA
#ifdef RADIO_CONFIG_ENABLE_IRCAL_MULTIPLE_RF_PATHS
  { 0xFFFFFFFFUL, 0xFFFFFFFFUL, },
#else
  { 0xFFFFFFFFUL },
#endif // RADIO_CONFIG_ENABLE_IRCAL_MULTIPLE_RF_PATHS
#endif // RAIL_SUPPORTS_OFDM_PA
};


// By default eu2_3_fan1_0
static uint32_t phyInfo[] = {
  15UL,
  0x00307C1FUL, // 48.48484848484848
  (uint32_t) NULL,
  (uint32_t) irCalConfig,
  (uint32_t) timingConfig_2,
  0x00000000UL,
  0UL,
  0UL,
  150000UL,
  0x00EF0101UL,
  0x07101B7EUL,
  (uint32_t) NULL,
  (uint32_t) hfxoRetimingConfigEntries,
  (uint32_t) NULL,
  0UL,
  0UL,
  149999UL,
  (uint32_t) rffpllConfig,
  (uint32_t) txIrCalConfig,
#if RAIL_SUPPORTS_HFXO_COMPENSATION
  (uint32_t) modemTxCompensation_2,
#else
  (uint32_t) NULL,
#endif
};

// By default eu2_3_fan1_0
static uint32_t Protocol_Configuration_modemConfigBase[] = {
  0x10018058UL, 0xBF1FF07FUL,
  0x30018058UL, 0x40000000UL,
  0x0102400CUL, 0x0011B10CUL,
  /*    4010 */ 0x00004800UL,
  0x01024020UL, 0x00000000UL,
  /*    4024 */ 0x00000000UL,
  0x01074030UL, 0x00000825UL,
  /*    4034 */ 0x00000100UL,
  /*    4038 */ 0x000000FFUL,
  /*    403C */ 0x00010341UL,
  /*    4040 */ 0x00006040UL,
  /*    4044 */ 0x00006000UL,
  /*    4048 */ 0x030007A0UL,
  0x01014050UL, 0x0000000BUL,
  0x0102405CUL, 0x00000D0FUL,
  /*    4060 */ 0x00000101UL,
  0x010140A8UL, 0x00000007UL,
  0x010440BCUL, 0x00000000UL,
  /*    40C0 */ 0x00000000UL,
  /*    40C4 */ 0x00000000UL,
  /*    40C8 */ 0x00000000UL,
  0x01044108UL, 0x00004001UL,
  /*    410C */ 0x00000CFFUL,
  /*    4110 */ 0x00004101UL,
  /*    4114 */ 0x00000DFFUL,
  0x01014184UL, 0x00000001UL,
  0x1101C020UL, 0x0007F800UL,
  0x3101C020UL, 0x002801FEUL,
  0x0109C024UL, 0x00001300UL,
  /*    C028 */ 0x03B380ECUL,
  /*    C02C */ 0x51407543UL,
  /*    C030 */ 0xF8000FA0UL,
  /*    C034 */ 0x00004030UL,
  /*    C038 */ 0x0007AAA8UL,
  /*    C03C */ 0x00000000UL,
  /*    C040 */ 0x00000000UL,
  /*    C044 */ 0x00000000UL,
  0x0114C054UL, 0x00302187UL,
  /*    C058 */ 0xE66C0074UL,
  /*    C05C */ 0x0000015CUL,
  /*    C060 */ 0x68635740UL,
  /*    C064 */ 0x0000006CUL,
  /*    C068 */ 0x0002C688UL,
  /*    C06C */ 0x000004A0UL,
  /*    C070 */ 0x000010BAUL,
  /*    C074 */ 0x003F0000UL,
  /*    C078 */ 0x00EE008DUL,
  /*    C07C */ 0x03AC01F6UL,
  /*    C080 */ 0x079604F5UL,
  /*    C084 */ 0x0D9C09DEUL,
  /*    C088 */ 0x179311C3UL,
  /*    C08C */ 0x26F51DFEUL,
  /*    C090 */ 0x3FFF32BDUL,
  /*    C094 */ 0x1BF815FEUL,
  /*    C098 */ 0x2DB423DCUL,
  /*    C09C */ 0x3FFF39D0UL,
  /*    C0A0 */ 0x00003FFFUL,
  0x0105C0A8UL, 0x15724BBDUL,
  /*    C0AC */ 0x0518A311UL,
  /*    C0B0 */ 0x76543210UL,
  /*    C0B4 */ 0x00000A98UL,
  /*    C0B8 */ 0x00000000UL,
  0x0104C0CCUL, 0x000000EEUL,
  /*    C0D0 */ 0x00000000UL,
  /*    C0D4 */ 0x000A0001UL,
  /*    C0D8 */ 0x00280001UL,
  0x0101C100UL, 0x00002800UL,
  0x0102C110UL, 0x00010100UL,
  /*    C114 */ 0x000000C8UL,
  0x02010008UL, 0x0000170EUL,
  0x02010018UL, 0xFFFFFFFFUL,
  0x02010020UL, 0xEDB88320UL,
  0x02024040UL, 0x30B00000UL,
  /*    4044 */ 0x00000000UL,
  0x0209404CUL, 0x04000000UL,
  /*    4050 */ 0x0082C22FUL,
  /*    4054 */ 0x00000000UL,
  /*    4058 */ 0x00000000UL,
  /*    405C */ 0x03000000UL,
  /*    4060 */ 0x40001000UL,
  /*    4064 */ 0x00000000UL,
  /*    4068 */ 0x00FE203FUL,
  /*    406C */ 0x00000840UL,
  0x02194074UL, 0x00300012UL,
  /*    4078 */ 0x00007209UL,
  /*    407C */ 0x00007209UL,
  /*    4080 */ 0x00001F50UL,
  /*    4084 */ 0x00000000UL,
  /*    4088 */ 0x000803B2UL,
  /*    408C */ 0x62060000UL,
  /*    4090 */ 0x00000000UL,
  /*    4094 */ 0x0A000000UL,
  /*    4098 */ 0x5454544AUL,
  /*    409C */ 0x00000000UL,
  /*    40A0 */ 0x00000000UL,
  /*    40A4 */ 0x00000000UL,
  /*    40A8 */ 0x00000000UL,
  /*    40AC */ 0x00000000UL,
  /*    40B0 */ 0x00000000UL,
  /*    40B4 */ 0x00000000UL,
  /*    40B8 */ 0x00000000UL,
  /*    40BC */ 0x00000000UL,
  /*    40C0 */ 0x00000000UL,
  /*    40C4 */ 0x00000000UL,
  /*    40C8 */ 0x00000000UL,
  /*    40CC */ 0x00000000UL,
  /*    40D0 */ 0x00000000UL,
  /*    40D4 */ 0x00000000UL,
  0x020140E0UL, 0x00000281UL,
  0x02074120UL, 0x00000000UL,
  /*    4124 */ 0x078304FFUL,
  /*    4128 */ 0x3AC81388UL,
  /*    412C */ 0x0C6606FFUL,
  /*    4130 */ 0x078304FFUL,
  /*    4134 */ 0x03FF1388UL,
  /*    4138 */ 0xF00A20BCUL,
  0x02054140UL, 0x40A96701UL,
  /*    4144 */ 0x904E0000UL,
  /*    4148 */ 0x4148A1ACUL,
  /*    414C */ 0x00403B89UL,
  /*    4150 */ 0x800003C0UL,
  0x02024158UL, 0x00000000UL,
  /*    415C */ 0x0000FDFFUL,
  0x02014164UL, 0x0000010CUL,
  0x020B416CUL, 0x40000000UL,
  /*    4170 */ 0x00000000UL,
  /*    4174 */ 0x00000000UL,
  /*    4178 */ 0x00000000UL,
  /*    417C */ 0x00000000UL,
  /*    4180 */ 0x00000000UL,
  /*    4184 */ 0x00000101UL,
  /*    4188 */ 0x00000000UL,
  /*    418C */ 0x00000000UL,
  /*    4190 */ 0x00000000UL,
  /*    4194 */ 0x00000000UL,
  0x020141A4UL, 0x00000000UL,
  0x020C41B0UL, 0x00000000UL,
  /*    41B4 */ 0xC02FD568UL,
  /*    41B8 */ 0x00000000UL,
  /*    41BC */ 0x00000000UL,
  /*    41C0 */ 0x003C0000UL,
  /*    41C4 */ 0x0006AAAAUL,
  /*    41C8 */ 0x00000000UL,
  /*    41CC */ 0x00000000UL,
  /*    41D0 */ 0x55555555UL,
  /*    41D4 */ 0x80BB80E7UL,
  /*    41D8 */ 0x000A0004UL,
  /*    41DC */ 0x00000000UL,
  0x02054224UL, 0x00000078UL,
  /*    4228 */ 0x00000000UL,
  /*    422C */ 0x00000000UL,
  /*    4230 */ 0x00000000UL,
  /*    4234 */ 0x00000000UL,
  0x0201423CUL, 0x00000000UL,
  0x02034244UL, 0x90000014UL,
  /*    4248 */ 0x00000000UL,
  /*    424C */ 0x04030008UL,
  0x020F4330UL, 0x00000000UL,
  /*    4334 */ 0x00000000UL,
  /*    4338 */ 0x00000000UL,
  /*    433C */ 0x00000000UL,
  /*    4340 */ 0x00000000UL,
  /*    4344 */ 0x00000000UL,
  /*    4348 */ 0x00000000UL,
  /*    434C */ 0x00000000UL,
  /*    4350 */ 0x00000000UL,
  /*    4354 */ 0x00000000UL,
  /*    4358 */ 0x00000000UL,
  /*    435C */ 0x38000000UL,
  /*    4360 */ 0x00000000UL,
  /*    4364 */ 0x00000000UL,
  /*    4368 */ 0x58FF0000UL,
  0x02014400UL, 0x000000D0UL,
  0x02018010UL, 0x00000003UL,
  0x02028038UL, 0x00101B7EUL,
  /*    803C */ 0x00000003UL,
  0x0203809CUL, 0x00000000UL,
  /*    80A0 */ 0x0003B870UL,
  /*    80A4 */ 0x0003B870UL,
  0x120180A8UL, 0x000001F6UL,
  0x320180A8UL, 0x01014201UL,
  0x120180ACUL, 0x000001F6UL,
  0x320180ACUL, 0x01014201UL,
  0x020280B0UL, 0x02000300UL,
  /*    80B4 */ 0x02000300UL,
  0x03030098UL, 0x00000000UL,
  /*    009C */ 0x04000C00UL,
  /*    00A0 */ 0x0000044CUL,
  0x030200D8UL, 0xAA400005UL,
  /*    00DC */ 0x00000188UL,
  0x130100ECUL, 0x00000FE0UL,
  0x330100ECUL, 0x5351200DUL,
  0x030100F0UL, 0x0000052BUL,
  0x03010100UL, 0x00000110UL,
  0x13010104UL, 0x00000000UL,
  0x33010104UL, 0x00000110UL,
  0x13010110UL, 0x000FFF00UL,
  0x33010110UL, 0x42000002UL,
  0x1301012CUL, 0x001FFC00UL,
  0x3301012CUL, 0x008002E9UL,
  0x03010140UL, 0x0000003FUL,
  0x13010150UL, 0x0001C000UL,
  0x33010150UL, 0x00A200C4UL,
  0x03020168UL, 0x00060010UL,
  /*    016C */ 0x000C0000UL,
  0x03010174UL, 0x01900169UL,
  0x13010178UL, 0x001C0000UL,
  0x33010178UL, 0x1FE00440UL,
  0x13010180UL, 0x00000779UL,
  0x33010180UL, 0x00000006UL,
  0x03020188UL, 0x00000090UL,
  /*    018C */ 0x00000000UL,
  0x030101E4UL, 0x00045220UL,
  0x03010208UL, 0x00200008UL,
  0x03010210UL, 0x00001100UL,
  0x13010400UL, 0x00000008UL,
  0x05120100UL, 0x00000050UL,
  /*    0104 */ 0x08083503UL,
  /*    0108 */ 0x00000000UL,
  /*    010C */ 0x0BFFE7E6UL,
  /*    0110 */ 0x000AA1CDUL,
  /*    0114 */ 0x006A06BDUL,
  /*    0118 */ 0x004DB05EUL,
  /*    011C */ 0x0E42027DUL,
  /*    0120 */ 0x0222B6A5UL,
  /*    0124 */ 0x34B225FFUL,
  /*    0128 */ 0x365E63DEUL,
  /*    012C */ 0x00076FBFUL,
  /*    0130 */ 0x0016EA6FUL,
  /*    0134 */ 0x00CE30E5UL,
  /*    0138 */ 0x0494844BUL,
  /*    013C */ 0x0ED9B9B2UL,
  /*    0140 */ 0x24A91F5AUL,
  /*    0144 */ 0x80000000UL,
  0x05010180UL, 0x00506992UL,
  0x05020200UL, 0x00145463UL,
  /*    0204 */ 0x00000000UL,
  0x05124100UL, 0x00000000UL,
  /*    4104 */ 0x00000000UL,
  /*    4108 */ 0x00000000UL,
  /*    410C */ 0x00000000UL,
  /*    4110 */ 0x00000000UL,
  /*    4114 */ 0x00000000UL,
  /*    4118 */ 0x00000000UL,
  /*    411C */ 0x00000000UL,
  /*    4120 */ 0x00000000UL,
  /*    4124 */ 0x00000000UL,
  /*    4128 */ 0x00000000UL,
  /*    412C */ 0x00000000UL,
  /*    4130 */ 0x00000000UL,
  /*    4134 */ 0x00000000UL,
  /*    4138 */ 0x00000000UL,
  /*    413C */ 0x00000000UL,
  /*    4140 */ 0x00000000UL,
  /*    4144 */ 0x00000000UL,
  0x05014154UL, 0x00000000UL,
  0x05014180UL, 0x00000000UL,
  0x05024200UL, 0x00000030UL,
  /*    4204 */ 0x00000000UL,
  0x050B8100UL, 0x00000000UL,
  /*    8104 */ 0x00000000UL,
  /*    8108 */ 0x00000000UL,
  /*    810C */ 0x00000000UL,
  /*    8110 */ 0x00000000UL,
  /*    8114 */ 0x00000000UL,
  /*    8118 */ 0x00000000UL,
  /*    811C */ 0x00000000UL,
  /*    8120 */ 0x00000000UL,
  /*    8124 */ 0x00000000UL,
  /*    8128 */ 0x00000000UL,
  0x06086040UL, 0x08000000UL,
  /*    6044 */ 0x01001000UL,
  /*    6048 */ 0x00202000UL,
  /*    604C */ 0x00080200UL,
  /*    6050 */ 0x00014000UL,
  /*    6054 */ 0x00020040UL,
  /*    6058 */ 0x00800400UL,
  /*    605C */ 0x00040010UL,
  0x06016FF4UL, 0x00000004UL,
  0x06016FFCUL, (uint32_t) &phyInfo,
  0x0701FC00UL, 0x00000000UL,
  0x0701FC00UL, 0x00000000UL,
  0x0701FC00UL, 0x00000000UL,
  0x0701FC00UL, 0x00000000UL,
  0x0702FC00UL, 0x00000000UL,
  /*    FC04 */ 0x00000000UL,
  0x0701FC04UL, 0x00000000UL,
  0x0701FC04UL, 0x00000000UL,
  0x0701FC04UL, 0x00000000UL,
  0x0702FC04UL, 0x00000000UL,
  /*    FC08 */ 0x00000000UL,
  0x0701FC08UL, 0x00000000UL,
  0x0701FC08UL, 0x00000000UL,
  0x0701FC08UL, 0x00000000UL,
  0x0707FC08UL, 0x00000000UL,
  /*    FC0C */ 0x00000000UL,
  /*    FC10 */ 0x00000000UL,
  /*    FC14 */ 0x00000014UL,
  /*    FC18 */ 0x00000000UL,
  /*    FC1C */ 0x00000000UL,
  /*    FC20 */ 0x00000000UL,
  0x0701FC30UL, 0x00000000UL,
  0x0701FC30UL, 0x00000000UL,
  0x0702FC30UL, 0x00000000UL,
  /*    FC34 */ 0x00000000UL,
  0x0702FC34UL, 0x00000000UL,
  /*    FC38 */ 0x00000000UL,
  0x0702FC38UL, 0x00000000UL,
  /*    FC3C */ 0x00000000UL,
  0x0702FC3CUL, 0x00000000UL,
  /*    FC40 */ 0x00000000UL,
  0x0702FC40UL, 0x00000000UL,
  /*    FC44 */ 0x00000000UL,
  0x0702FC44UL, 0x00000000UL,
  /*    FC48 */ 0x00000000UL,
  0x0702FC48UL, 0x00000000UL,
  /*    FC4C */ 0x00000000UL,
  0x0702FC4CUL, 0x00000000UL,
  /*    FC50 */ 0x00000000UL,
  0x0702FC50UL, 0x00000000UL,
  /*    FC54 */ 0x00000000UL,
  0x0702FC54UL, 0x00000000UL,
  /*    FC58 */ 0x00000080UL,
  0x0702FC58UL, 0x00000080UL,
  /*    FC5C */ 0x00000000UL,
  0x0702FC5CUL, 0x00000000UL,
  /*    FC60 */ 0x00000000UL,
  0x0702FC60UL, 0x00000000UL,
  /*    FC64 */ 0x00000000UL,
  0x0706FC64UL, 0x00000000UL,
  /*    FC68 */ 0x00000000UL,
  /*    FC6C */ 0x00000000UL,
  /*    FC70 */ 0x00000000UL,
  /*    FC74 */ 0x00000000UL,
  /*    FC78 */ 0x00000000UL,
  0x070AFC80UL, 0x10001000UL,
  /*    FC84 */ 0x00000080UL,
  /*    FC88 */ 0x00000000UL,
  /*    FC8C */ 0x00000000UL,
  /*    FC90 */ 0x00000000UL,
  /*    FC94 */ 0x00000000UL,
  /*    FC98 */ 0x00000000UL,
  /*    FC9C */ 0x00000000UL,
  /*    FCA0 */ 0x00000000UL,
  /*    FCA4 */ 0x00000000UL,
  0xFFFFFFFFUL,
};

#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
const uint8_t stackInfo_na1_1b_fan1_0[5] = {0x07, 0x02, 0x00, 0x01, 0x01};
const uint8_t stackInfo_na1_2a_fan1_0[5] = {0x07, 0x03, 0x00, 0x01, 0x01};
const uint8_t stackInfo_na2_3_fan1_0[5] = {0x07, 0x05, 0x00, 0x02, 0x01};
const uint8_t stackInfo_na2_4a_fan1_0[5] = {0x07, 0x06, 0x00, 0x02, 0x01};
const uint8_t stackInfo_na3_5b_fan1_0[5] = {0x07, 0x08, 0x00, 0x03, 0x01};
const uint8_t stackInfo_jp1_1b_fan1_0[5] = {0x07, 0x02, 0x00, 0x01, 0x02};
const uint8_t stackInfo_jp2_2b_fan1_0[5] = {0x07, 0x04, 0x00, 0x02, 0x02};
const uint8_t stackInfo_jp2_3_fan1_0[5] = {0x07, 0x05, 0x00, 0x02, 0x02};
const uint8_t stackInfo_jp3_4b_fan1_0[5] = {0x07, 0x07, 0x00, 0x03, 0x02};
const uint8_t stackInfo_jp3_5_fan1_0[5] = {0x07, 0x08, 0x00, 0x03, 0x02};
const uint8_t stackInfo_eu1_1a_fan1_0[5] = {0x07, 0x01, 0x00, 0x01, 0x03};
const uint8_t stackInfo_eu2_2a_fan1_0[5] = {0x07, 0x03, 0x00, 0x02, 0x03};
const uint8_t stackInfo_eu2_3_fan1_0[5] = {0x07, 0x05, 0x00, 0x02, 0x03};
const uint8_t stackInfo_eu3_1a_fan1_0[5] = {0x07, 0x01, 0x00, 0x03, 0x03};
const uint8_t stackInfo_eu4_2a_fan1_0[5] = {0x07, 0x03, 0x00, 0x04, 0x03};
const uint8_t stackInfo_eu4_3_fan1_0[5] = {0x07, 0x05, 0x00, 0x04, 0x03};
#endif // RADIO_CONFIG_ENABLE_STACK_INFO

// By default eu2_3_fan1_0
RAIL_ChannelConfigEntry_t Protocol_Configuration_channels[] = {
  {
    .phyConfigDeltaAdd = NULL,
    .baseFrequency = 863100000,
    .channelSpacing = 200000,
    .physicalChannelOffset = 0,
    .channelNumberStart = 0,
    .channelNumberEnd = 34,
    .maxPower = RAIL_TX_POWER_MAX,
    .attr = &channelConfigEntryAttr,
#ifdef RADIO_CONFIG_ENABLE_CONC_PHY
    .entryType = 0,
#endif
//#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
//    .stackInfo = stackInfo_eu2_3_fan1_0,
//#endif
  },
};

// By default eu2_3_fan1_0
RAIL_ChannelConfig_t Protocol_Configuration_channelConfig = {
  .phyConfigBase = Protocol_Configuration_modemConfigBase,
  .phyConfigDeltaSubtract = NULL,
  .configs = Protocol_Configuration_channels,
  .length = 1U,
  .signature = 0UL,
};



/* ******* RAIL Wi-SUN configurations ******* */

const struct wisun_rail_config wisun_rail_configs[] = {
    {
        .name = "FAN-EU868-1a",
        .channel_config = { .channel_0_center_frequency = 863100000, .channel_spacing = 100000,
                            .datarate = 50000, .number_of_channels = 69, .modulation = M_2FSK,
                            .modulation_index = MODULATION_INDEX_0_5 },
        .set_config_func = rf_set_config_wisun_fan_eu_868_1a,
    },
    {
        .name = "FAN-EU868-2a",
        .channel_config = { .channel_0_center_frequency = 863100000, .channel_spacing = 200000,
                            .datarate = 100000, .number_of_channels = 35, .modulation = M_2FSK,
                            .modulation_index = MODULATION_INDEX_0_5 },
        .set_config_func = rf_set_config_wisun_fan_eu_868_2a,
    },
    {
        .name = "FAN-EU868-3",
        .channel_config = { .channel_0_center_frequency = 863100000, .channel_spacing = 200000,
                            .datarate = 150000, .number_of_channels = 35, .modulation = M_2FSK,
                            .modulation_index = MODULATION_INDEX_0_5 },
        .set_config_func = rf_set_config_wisun_fan_eu_868_3,
    },
    {
        .name = "FAN-EU873-1a",
        .channel_config = { .channel_0_center_frequency = 870100000, .channel_spacing = 100000,
                            .datarate = 50000, .number_of_channels = 55, .modulation = M_2FSK,
                            .modulation_index = MODULATION_INDEX_0_5 },
        .set_config_func = rf_set_config_wisun_fan_eu_873_1a,
    },
    {
        .name = "FAN-EU873-2a",
        .channel_config = { .channel_0_center_frequency = 870200000, .channel_spacing = 200000,
                            .datarate = 100000, .number_of_channels = 27, .modulation = M_2FSK,
                            .modulation_index = MODULATION_INDEX_0_5 },
        .set_config_func = rf_set_config_wisun_fan_eu_873_2a,
    },
    {
        .name = "FAN-EU873-3",
        .channel_config = { .channel_0_center_frequency = 870200000, .channel_spacing = 200000,
                            .datarate = 150000, .number_of_channels = 27, .modulation = M_2FSK,
                            .modulation_index = MODULATION_INDEX_0_5 },
        .set_config_func = rf_set_config_wisun_fan_eu_873_3,
    },
    {
        .name = "FAN-NA915-1b",
        .channel_config = { .channel_0_center_frequency = 902200000, .channel_spacing = 200000,
                            .datarate = 50000, .number_of_channels = 129, .modulation = M_2FSK,
                            .modulation_index = MODULATION_INDEX_1_0 },
        .set_config_func = rf_set_config_wisun_fan_na_915_1b,
    },
    {
        .name = "FAN-NA915-2a",
        .channel_config = { .channel_0_center_frequency = 902200000, .channel_spacing = 200000,
                            .datarate = 100000, .number_of_channels = 129, .modulation = M_2FSK,
                            .modulation_index = MODULATION_INDEX_0_5 },
        .set_config_func = rf_set_config_wisun_fan_na_915_2a,
    },
    {
        .name = "FAN-NA915-3",
        .channel_config = { .channel_0_center_frequency = 902400000, .channel_spacing = 400000,
                            .datarate = 150000, .number_of_channels = 64, .modulation = M_2FSK,
                            .modulation_index = MODULATION_INDEX_0_5 },
        .set_config_func = rf_set_config_wisun_fan_na_915_3,
    },
    {
        .name = "FAN-NA915-4a",
        .channel_config = { .channel_0_center_frequency = 902400000, .channel_spacing = 400000,
                            .datarate = 200000, .number_of_channels = 64, .modulation = M_2FSK,
                            .modulation_index = MODULATION_INDEX_0_5 },
        .set_config_func = rf_set_config_wisun_fan_na_915_4a,
    },
    {
        .name = "FAN-NA915-5",
        .channel_config = { .channel_0_center_frequency = 902600000, .channel_spacing = 600000,
                            .datarate = 300000, .number_of_channels = 42, .modulation = M_2FSK,
                            .modulation_index = MODULATION_INDEX_0_5 },
        .set_config_func = rf_set_config_wisun_fan_na_915_5,
    },
    { NULL },  // Teminator
};

/* ********************************************************* */



RAIL_ChannelConfigEntry_t * rf_set_config_wisun_fan_eu_868_1a(phy_rf_channel_configuration_s *mbed_channel_config){
  (void)mbed_channel_config;

  phyInfo[1] = 0x0021DCC8UL;
  phyInfo[4] = (uint32_t) timingConfig_7;
  phyInfo[8] = 50000UL;
  phyInfo[9] = 0x00F00101UL;
  phyInfo[10] = 0x0710120AUL;
  phyInfo[16] = 49999UL;
#if RAIL_SUPPORTS_HFXO_COMPENSATION
  phyInfo[19] = (uint32_t) modemTxCompensation_7;
#endif

  Protocol_Configuration_modemConfigBase[53] = /*    C058 */ 0xE6A500B1UL;
  Protocol_Configuration_modemConfigBase[54] = /*    C05C */ 0x00000213UL;
  Protocol_Configuration_modemConfigBase[55] = /*    C060 */ 0x9F968561UL;
  Protocol_Configuration_modemConfigBase[56] = /*    C064 */ 0x000000A5UL;
  Protocol_Configuration_modemConfigBase[58] = /*    C06C */ 0x000004A0UL;
  Protocol_Configuration_modemConfigBase[59] = /*    C070 */ 0x000010BAUL;
  Protocol_Configuration_modemConfigBase[60] = /*    C074 */ 0x003F0000UL;
  Protocol_Configuration_modemConfigBase[61] = /*    C078 */ 0x00EE008DUL;
  Protocol_Configuration_modemConfigBase[62] = /*    C07C */ 0x03AC01F6UL;
  Protocol_Configuration_modemConfigBase[63] = /*    C080 */ 0x079604F5UL;
  Protocol_Configuration_modemConfigBase[64] = /*    C084 */ 0x0D9C09DEUL;
  Protocol_Configuration_modemConfigBase[65] = /*    C088 */ 0x179311C3UL;
  Protocol_Configuration_modemConfigBase[66] = /*    C08C */ 0x26F51DFEUL;
  Protocol_Configuration_modemConfigBase[67] = /*    C090 */ 0x3FFF32BDUL;
  Protocol_Configuration_modemConfigBase[68] = /*    C094 */ 0x1BF815FEUL;
  Protocol_Configuration_modemConfigBase[69] = /*    C098 */ 0x2DB423DCUL;
  Protocol_Configuration_modemConfigBase[79] = 0x000001FEUL;
  Protocol_Configuration_modemConfigBase[95] = 0x20F00000UL;
  Protocol_Configuration_modemConfigBase[100] = /*    4054 */ 0x20000000UL;
  Protocol_Configuration_modemConfigBase[105] = /*    4068 */ 0x00FE60BDUL;
  Protocol_Configuration_modemConfigBase[106] = /*    406C */ 0x00000C40UL;
  Protocol_Configuration_modemConfigBase[108] = 0x00200012UL;
  Protocol_Configuration_modemConfigBase[111] = /*    4080 */ 0x00000F28UL;
  Protocol_Configuration_modemConfigBase[113] = /*    4088 */ 0x001A0370UL;
  Protocol_Configuration_modemConfigBase[114] = /*    408C */ 0x62040000UL;
  Protocol_Configuration_modemConfigBase[144] = 0x40983881UL;
  Protocol_Configuration_modemConfigBase[146] = /*    4148 */ 0x41E9BC9AUL;
  Protocol_Configuration_modemConfigBase[147] = /*    414C */ 0x00403B8BUL;
  Protocol_Configuration_modemConfigBase[170] = /*    41B4 */ 0xC02DD0B4UL;
  Protocol_Configuration_modemConfigBase[178] = /*    41D4 */ 0x805DC1DFUL;
  Protocol_Configuration_modemConfigBase[179] = /*    41D8 */ 0x00020006UL;
  Protocol_Configuration_modemConfigBase[182] = 0x00000058UL;
  Protocol_Configuration_modemConfigBase[192] = /*    424C */ 0x04050008UL;
  Protocol_Configuration_modemConfigBase[210] = 0x00000110UL;
  Protocol_Configuration_modemConfigBase[214] = 0x0010120AUL;
  Protocol_Configuration_modemConfigBase[219] = /*    80A4 */ 0x0003B870UL;
  Protocol_Configuration_modemConfigBase[227] = 0x01014201UL;
  Protocol_Configuration_modemConfigBase[230] = /*    80B4 */ 0x02000300UL;
  Protocol_Configuration_modemConfigBase[263] = 0x00A200C8UL;
  Protocol_Configuration_modemConfigBase[266] = /*    016C */ 0x000C0000UL;
  Protocol_Configuration_modemConfigBase[268] = 0x01900169UL;
  Protocol_Configuration_modemConfigBase[276] = 0x00000006UL;
  Protocol_Configuration_modemConfigBase[278] = 0x00000090UL;
  Protocol_Configuration_modemConfigBase[289] = 0x000000A0UL;
  Protocol_Configuration_modemConfigBase[290] = /*    0104 */ 0x0808990FUL;
  Protocol_Configuration_modemConfigBase[292] = /*    010C */ 0x0BFFE7E6UL;
  Protocol_Configuration_modemConfigBase[293] = /*    0110 */ 0x000AA1CDUL;
  Protocol_Configuration_modemConfigBase[294] = /*    0114 */ 0x006A06BDUL;
  Protocol_Configuration_modemConfigBase[295] = /*    0118 */ 0x004DB05EUL;
  Protocol_Configuration_modemConfigBase[296] = /*    011C */ 0x0E42027DUL;
  Protocol_Configuration_modemConfigBase[297] = /*    0120 */ 0x0222B6A5UL;
  Protocol_Configuration_modemConfigBase[298] = /*    0124 */ 0x34B225FFUL;
  Protocol_Configuration_modemConfigBase[299] = /*    0128 */ 0x0C81901EUL;
  Protocol_Configuration_modemConfigBase[300] = /*    012C */ 0x0006490CUL;
  Protocol_Configuration_modemConfigBase[301] = /*    0130 */ 0x006DDFA8UL;
  Protocol_Configuration_modemConfigBase[302] = /*    0134 */ 0x00B10BC0UL;
  Protocol_Configuration_modemConfigBase[303] = /*    0138 */ 0x05020AE8UL;
  Protocol_Configuration_modemConfigBase[304] = /*    013C */ 0x00A53D18UL;
  Protocol_Configuration_modemConfigBase[305] = /*    0140 */ 0x1DD71B27UL;
  Protocol_Configuration_modemConfigBase[308] = 0x00504545UL;


  Protocol_Configuration_channels[0].baseFrequency = 863100000;
  Protocol_Configuration_channels[0].channelSpacing = 100000;
  Protocol_Configuration_channels[0].channelNumberEnd = 68;
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
  //Protocol_Configuration_channels[0].stackInfo = stackInfo_eu1_1a_fan1_0;
#endif
  return NULL;
}

RAIL_ChannelConfigEntry_t * rf_set_config_wisun_fan_eu_868_2a(phy_rf_channel_configuration_s *mbed_channel_config){
  (void)mbed_channel_config;

  phyInfo[1] = 0x002B8994UL;
  phyInfo[4] = (uint32_t) timingConfig_1;
  phyInfo[8] = 100000UL;
  phyInfo[9] = 0x00F20101UL;
  phyInfo[10] = 0x071016C4UL;
  phyInfo[16] = 99999UL;
#if RAIL_SUPPORTS_HFXO_COMPENSATION
  phyInfo[19] = (uint32_t) modemTxCompensation_1;
#endif

  Protocol_Configuration_modemConfigBase[53] = /*    C058 */ 0xE683008DUL;
  Protocol_Configuration_modemConfigBase[54] = /*    C05C */ 0x000001A7UL;
  Protocol_Configuration_modemConfigBase[55] = /*    C060 */ 0x7F786A4EUL;
  Protocol_Configuration_modemConfigBase[56] = /*    C064 */ 0x00000083UL;
  Protocol_Configuration_modemConfigBase[58] = /*    C06C */ 0x000004A0UL;
  Protocol_Configuration_modemConfigBase[59] = /*    C070 */ 0x000010BAUL;
  Protocol_Configuration_modemConfigBase[60] = /*    C074 */ 0x003F0000UL;
  Protocol_Configuration_modemConfigBase[61] = /*    C078 */ 0x00EE008DUL;
  Protocol_Configuration_modemConfigBase[62] = /*    C07C */ 0x03AC01F6UL;
  Protocol_Configuration_modemConfigBase[63] = /*    C080 */ 0x079604F5UL;
  Protocol_Configuration_modemConfigBase[64] = /*    C084 */ 0x0D9C09DEUL;
  Protocol_Configuration_modemConfigBase[65] = /*    C088 */ 0x179311C3UL;
  Protocol_Configuration_modemConfigBase[66] = /*    C08C */ 0x26F51DFEUL;
  Protocol_Configuration_modemConfigBase[67] = /*    C090 */ 0x3FFF32BDUL;
  Protocol_Configuration_modemConfigBase[68] = /*    C094 */ 0x1BF815FEUL;
  Protocol_Configuration_modemConfigBase[69] = /*    C098 */ 0x2DB423DCUL;
  Protocol_Configuration_modemConfigBase[79] = 0x000001FEUL;
  Protocol_Configuration_modemConfigBase[95] = 0x20F00000UL;
  Protocol_Configuration_modemConfigBase[100] = /*    4054 */ 0x20000000UL;
  Protocol_Configuration_modemConfigBase[105] = /*    4068 */ 0x00FC2FFDUL;
  Protocol_Configuration_modemConfigBase[106] = /*    406C */ 0x00000840UL;
  Protocol_Configuration_modemConfigBase[108] = 0x00200012UL;
  Protocol_Configuration_modemConfigBase[111] = /*    4080 */ 0x00000F46UL;
  Protocol_Configuration_modemConfigBase[113] = /*    4088 */ 0x003B0390UL;
  Protocol_Configuration_modemConfigBase[114] = /*    408C */ 0x62060000UL;
  Protocol_Configuration_modemConfigBase[144] = 0x40A96701UL;
  Protocol_Configuration_modemConfigBase[146] = /*    4148 */ 0x4148E8B0UL;
  Protocol_Configuration_modemConfigBase[147] = /*    414C */ 0x00403B89UL;
  Protocol_Configuration_modemConfigBase[170] = /*    41B4 */ 0xC02ED568UL;
  Protocol_Configuration_modemConfigBase[178] = /*    41D4 */ 0x80BB80E7UL;
  Protocol_Configuration_modemConfigBase[179] = /*    41D8 */ 0x000A0004UL;
  Protocol_Configuration_modemConfigBase[182] = 0x00000058UL;
  Protocol_Configuration_modemConfigBase[192] = /*    424C */ 0x04030008UL;
  Protocol_Configuration_modemConfigBase[210] = 0x000000F0UL;
  Protocol_Configuration_modemConfigBase[214] = 0x001016C4UL;
  Protocol_Configuration_modemConfigBase[219] = /*    80A4 */ 0x0003B870UL;
  Protocol_Configuration_modemConfigBase[227] = 0x01014201UL;
  Protocol_Configuration_modemConfigBase[230] = /*    80B4 */ 0x02000300UL;
  Protocol_Configuration_modemConfigBase[263] = 0x00A200C8UL;
  Protocol_Configuration_modemConfigBase[266] = /*    016C */ 0x000C0000UL;
  Protocol_Configuration_modemConfigBase[268] = 0x01900169UL;
  Protocol_Configuration_modemConfigBase[276] = 0x00000006UL;
  Protocol_Configuration_modemConfigBase[278] = 0x00000090UL;
  Protocol_Configuration_modemConfigBase[289] = 0x00000068UL;
  Protocol_Configuration_modemConfigBase[290] = /*    0104 */ 0x0809AC31UL;
  Protocol_Configuration_modemConfigBase[292] = /*    010C */ 0x11E107F9UL;
  Protocol_Configuration_modemConfigBase[293] = /*    0110 */ 0x0005E9CCUL;
  Protocol_Configuration_modemConfigBase[294] = /*    0114 */ 0x006C8E32UL;
  Protocol_Configuration_modemConfigBase[295] = /*    0118 */ 0x004EB132UL;
  Protocol_Configuration_modemConfigBase[296] = /*    011C */ 0x0E1C0182UL;
  Protocol_Configuration_modemConfigBase[297] = /*    0120 */ 0x0265F774UL;
  Protocol_Configuration_modemConfigBase[298] = /*    0124 */ 0x3350259BUL;
  Protocol_Configuration_modemConfigBase[299] = /*    0128 */ 0x0A00ABFFUL;
  Protocol_Configuration_modemConfigBase[300] = /*    012C */ 0x000FF15CUL;
  Protocol_Configuration_modemConfigBase[301] = /*    0130 */ 0x000241D3UL;
  Protocol_Configuration_modemConfigBase[302] = /*    0134 */ 0x00B1ED95UL;
  Protocol_Configuration_modemConfigBase[303] = /*    0138 */ 0x04B90812UL;
  Protocol_Configuration_modemConfigBase[304] = /*    013C */ 0x0FD87B19UL;
  Protocol_Configuration_modemConfigBase[305] = /*    0140 */ 0x1F6D1BEAUL;
  Protocol_Configuration_modemConfigBase[308] = 0x0050576BUL;

  Protocol_Configuration_channels[0].baseFrequency = 863100000;
  Protocol_Configuration_channels[0].channelSpacing = 200000;
  Protocol_Configuration_channels[0].channelNumberEnd = 34;
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
  //Protocol_Configuration_channels[0].stackInfo = stackInfo_eu2_2a_fan1_0;
#endif
  return NULL;
}

RAIL_ChannelConfigEntry_t * rf_set_config_wisun_fan_eu_868_3(phy_rf_channel_configuration_s *mbed_channel_config){
  (void)mbed_channel_config;

  phyInfo[1] = 0x00307C1FUL;
  phyInfo[4] = (uint32_t) timingConfig_2;
  phyInfo[8] = 150000UL;
  phyInfo[9] = 0x00EF0101UL;
  phyInfo[10] = 0x07101B7EUL;
  phyInfo[16] = 149999UL;
#if RAIL_SUPPORTS_HFXO_COMPENSATION
  phyInfo[19] = (uint32_t) modemTxCompensation_2;
#endif

  Protocol_Configuration_modemConfigBase[53] = /*    C058 */ 0xE66C0074UL;
  Protocol_Configuration_modemConfigBase[54] = /*    C05C */ 0x0000015CUL;
  Protocol_Configuration_modemConfigBase[55] = /*    C060 */ 0x68635740UL;
  Protocol_Configuration_modemConfigBase[56] = /*    C064 */ 0x0000006CUL;
  Protocol_Configuration_modemConfigBase[58] = /*    C06C */ 0x000004A0UL;
  Protocol_Configuration_modemConfigBase[59] = /*    C070 */ 0x000010BAUL;
  Protocol_Configuration_modemConfigBase[60] = /*    C074 */ 0x003F0000UL;
  Protocol_Configuration_modemConfigBase[61] = /*    C078 */ 0x00EE008DUL;
  Protocol_Configuration_modemConfigBase[62] = /*    C07C */ 0x03AC01F6UL;
  Protocol_Configuration_modemConfigBase[63] = /*    C080 */ 0x079604F5UL;
  Protocol_Configuration_modemConfigBase[64] = /*    C084 */ 0x0D9C09DEUL;
  Protocol_Configuration_modemConfigBase[65] = /*    C088 */ 0x179311C3UL;
  Protocol_Configuration_modemConfigBase[66] = /*    C08C */ 0x26F51DFEUL;
  Protocol_Configuration_modemConfigBase[67] = /*    C090 */ 0x3FFF32BDUL;
  Protocol_Configuration_modemConfigBase[68] = /*    C094 */ 0x1BF815FEUL;
  Protocol_Configuration_modemConfigBase[69] = /*    C098 */ 0x2DB423DCUL;
  Protocol_Configuration_modemConfigBase[79] = 0x000000EEUL;
  Protocol_Configuration_modemConfigBase[95] = 0x30B00000UL;
  Protocol_Configuration_modemConfigBase[100] = /*    4054 */ 0x00000000UL;
  Protocol_Configuration_modemConfigBase[105] = /*    4068 */ 0x00FE203FUL;
  Protocol_Configuration_modemConfigBase[106] = /*    406C */ 0x00000840UL;
  Protocol_Configuration_modemConfigBase[108] = 0x00300012UL;
  Protocol_Configuration_modemConfigBase[111] = /*    4080 */ 0x00001F50UL;
  Protocol_Configuration_modemConfigBase[113] = /*    4088 */ 0x000803B2UL;
  Protocol_Configuration_modemConfigBase[114] = /*    408C */ 0x62060000UL;
  Protocol_Configuration_modemConfigBase[144] = 0x40A96701UL;
  Protocol_Configuration_modemConfigBase[146] = /*    4148 */ 0x4148A1ACUL;
  Protocol_Configuration_modemConfigBase[147] = /*    414C */ 0x00403B89UL;
  Protocol_Configuration_modemConfigBase[170] = /*    41B4 */ 0xC02FD568UL;
  Protocol_Configuration_modemConfigBase[178] = /*    41D4 */ 0x80BB80E7UL;
  Protocol_Configuration_modemConfigBase[179] = /*    41D8 */ 0x000A0004UL;
  Protocol_Configuration_modemConfigBase[182] = 0x00000078UL;
  Protocol_Configuration_modemConfigBase[192] = /*    424C */ 0x04030008UL;
  Protocol_Configuration_modemConfigBase[210] = 0x000000D0UL;
  Protocol_Configuration_modemConfigBase[214] = 0x00101B7EUL;
  Protocol_Configuration_modemConfigBase[219] = /*    80A4 */ 0x0003B870UL;
  Protocol_Configuration_modemConfigBase[227] = 0x01014201UL;
  Protocol_Configuration_modemConfigBase[230] = /*    80B4 */ 0x02000300UL;
  Protocol_Configuration_modemConfigBase[263] = 0x00A200C4UL;
  Protocol_Configuration_modemConfigBase[266] = /*    016C */ 0x000C0000UL;
  Protocol_Configuration_modemConfigBase[268] = 0x01900169UL;
  Protocol_Configuration_modemConfigBase[276] = 0x00000006UL;
  Protocol_Configuration_modemConfigBase[278] = 0x00000090UL;
  Protocol_Configuration_modemConfigBase[289] = 0x00000050UL;
  Protocol_Configuration_modemConfigBase[290] = /*    0104 */ 0x08083503UL;
  Protocol_Configuration_modemConfigBase[292] = /*    010C */ 0x0BFFE7E6UL;
  Protocol_Configuration_modemConfigBase[293] = /*    0110 */ 0x000AA1CDUL;
  Protocol_Configuration_modemConfigBase[294] = /*    0114 */ 0x006A06BDUL;
  Protocol_Configuration_modemConfigBase[295] = /*    0118 */ 0x004DB05EUL;
  Protocol_Configuration_modemConfigBase[296] = /*    011C */ 0x0E42027DUL;
  Protocol_Configuration_modemConfigBase[297] = /*    0120 */ 0x0222B6A5UL;
  Protocol_Configuration_modemConfigBase[298] = /*    0124 */ 0x34B225FFUL;
  Protocol_Configuration_modemConfigBase[299] = /*    0128 */ 0x365E63DEUL;
  Protocol_Configuration_modemConfigBase[300] = /*    012C */ 0x00076FBFUL;
  Protocol_Configuration_modemConfigBase[301] = /*    0130 */ 0x0016EA6FUL;
  Protocol_Configuration_modemConfigBase[302] = /*    0134 */ 0x00CE30E5UL;
  Protocol_Configuration_modemConfigBase[303] = /*    0138 */ 0x0494844BUL;
  Protocol_Configuration_modemConfigBase[304] = /*    013C */ 0x0ED9B9B2UL;
  Protocol_Configuration_modemConfigBase[305] = /*    0140 */ 0x24A91F5AUL;
  Protocol_Configuration_modemConfigBase[308] = 0x00506992UL;

  Protocol_Configuration_channels[0].baseFrequency = 863100000;
  Protocol_Configuration_channels[0].channelSpacing = 200000;
  Protocol_Configuration_channels[0].channelNumberEnd = 34;
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
  //Protocol_Configuration_channels[0].stackInfo = stackInfo_eu2_3_fan1_0;
#endif
  return NULL;
}

RAIL_ChannelConfigEntry_t * rf_set_config_wisun_fan_eu_873_1a(phy_rf_channel_configuration_s *mbed_channel_config){
  (void)mbed_channel_config;

  phyInfo[1] = 0x0021DCC8UL;
  phyInfo[4] = (uint32_t) timingConfig_7;
  phyInfo[8] = 50000UL;
  phyInfo[9] = 0x00F00101UL;
  phyInfo[10] = 0x07101216UL;
  phyInfo[16] = 49999UL;
#if RAIL_SUPPORTS_HFXO_COMPENSATION
  phyInfo[19] = (uint32_t) modemTxCompensation_7;
#endif

  Protocol_Configuration_modemConfigBase[53] = /*    C058 */ 0xE6A500B1UL;
  Protocol_Configuration_modemConfigBase[54] = /*    C05C */ 0x00000213UL;
  Protocol_Configuration_modemConfigBase[55] = /*    C060 */ 0x9F968561UL;
  Protocol_Configuration_modemConfigBase[56] = /*    C064 */ 0x000000A5UL;
  Protocol_Configuration_modemConfigBase[58] = /*    C06C */ 0x000004A0UL;
  Protocol_Configuration_modemConfigBase[59] = /*    C070 */ 0x000010BAUL;
  Protocol_Configuration_modemConfigBase[60] = /*    C074 */ 0x003F0000UL;
  Protocol_Configuration_modemConfigBase[61] = /*    C078 */ 0x00EE008DUL;
  Protocol_Configuration_modemConfigBase[62] = /*    C07C */ 0x03AC01F6UL;
  Protocol_Configuration_modemConfigBase[63] = /*    C080 */ 0x079604F5UL;
  Protocol_Configuration_modemConfigBase[64] = /*    C084 */ 0x0D9C09DEUL;
  Protocol_Configuration_modemConfigBase[65] = /*    C088 */ 0x179311C3UL;
  Protocol_Configuration_modemConfigBase[66] = /*    C08C */ 0x26F51DFEUL;
  Protocol_Configuration_modemConfigBase[67] = /*    C090 */ 0x3FFF32BDUL;
  Protocol_Configuration_modemConfigBase[68] = /*    C094 */ 0x1BF815FEUL;
  Protocol_Configuration_modemConfigBase[69] = /*    C098 */ 0x2DB423DCUL;
  Protocol_Configuration_modemConfigBase[79] = 0x000001FEUL;
  Protocol_Configuration_modemConfigBase[95] = 0x20F00000UL;
  Protocol_Configuration_modemConfigBase[100] = /*    4054 */ 0x20000000UL;
  Protocol_Configuration_modemConfigBase[105] = /*    4068 */ 0x00FE60BDUL;
  Protocol_Configuration_modemConfigBase[106] = /*    406C */ 0x00000C40UL;
  Protocol_Configuration_modemConfigBase[108] = 0x00200012UL;
  Protocol_Configuration_modemConfigBase[111] = /*    4080 */ 0x00000F28UL;
  Protocol_Configuration_modemConfigBase[113] = /*    4088 */ 0x001A0370UL;
  Protocol_Configuration_modemConfigBase[114] = /*    408C */ 0x62040000UL;
  Protocol_Configuration_modemConfigBase[144] = 0x40983881UL;
  Protocol_Configuration_modemConfigBase[146] = /*    4148 */ 0x41E9BF9AUL;
  Protocol_Configuration_modemConfigBase[147] = /*    414C */ 0x00403B8BUL;
  Protocol_Configuration_modemConfigBase[170] = /*    41B4 */ 0xC02DD0B4UL;
  Protocol_Configuration_modemConfigBase[178] = /*    41D4 */ 0x805DC1DFUL;
  Protocol_Configuration_modemConfigBase[179] = /*    41D8 */ 0x00020006UL;
  Protocol_Configuration_modemConfigBase[182] = 0x00000058UL;
  Protocol_Configuration_modemConfigBase[192] = /*    424C */ 0x04050008UL;
  Protocol_Configuration_modemConfigBase[210] = 0x00000110UL;
  Protocol_Configuration_modemConfigBase[214] = 0x00101216UL;
  Protocol_Configuration_modemConfigBase[219] = /*    80A4 */ 0x0003B870UL;
  Protocol_Configuration_modemConfigBase[227] = 0x01014201UL;
  Protocol_Configuration_modemConfigBase[230] = /*    80B4 */ 0x02000300UL;
  Protocol_Configuration_modemConfigBase[263] = 0x00A200C8UL;
  Protocol_Configuration_modemConfigBase[266] = /*    016C */ 0x000C0000UL;
  Protocol_Configuration_modemConfigBase[268] = 0x01900169UL;
  Protocol_Configuration_modemConfigBase[276] = 0x00000006UL;
  Protocol_Configuration_modemConfigBase[278] = 0x00000090UL;
  Protocol_Configuration_modemConfigBase[289] = 0x000000A0UL;
  Protocol_Configuration_modemConfigBase[290] = /*    0104 */ 0x0808990FUL;
  Protocol_Configuration_modemConfigBase[292] = /*    010C */ 0x0BFFE7E6UL;
  Protocol_Configuration_modemConfigBase[293] = /*    0110 */ 0x000AA1CDUL;
  Protocol_Configuration_modemConfigBase[294] = /*    0114 */ 0x006A06BDUL;
  Protocol_Configuration_modemConfigBase[295] = /*    0118 */ 0x004DB05EUL;
  Protocol_Configuration_modemConfigBase[296] = /*    011C */ 0x0E42027DUL;
  Protocol_Configuration_modemConfigBase[297] = /*    0120 */ 0x0222B6A5UL;
  Protocol_Configuration_modemConfigBase[298] = /*    0124 */ 0x34B225FFUL;
  Protocol_Configuration_modemConfigBase[299] = /*    0128 */ 0x0C81901EUL;
  Protocol_Configuration_modemConfigBase[300] = /*    012C */ 0x0006490CUL;
  Protocol_Configuration_modemConfigBase[301] = /*    0130 */ 0x006DDFA8UL;
  Protocol_Configuration_modemConfigBase[302] = /*    0134 */ 0x00B10BC0UL;
  Protocol_Configuration_modemConfigBase[303] = /*    0138 */ 0x05020AE8UL;
  Protocol_Configuration_modemConfigBase[304] = /*    013C */ 0x00A53D18UL;
  Protocol_Configuration_modemConfigBase[305] = /*    0140 */ 0x1DD71B27UL;
  Protocol_Configuration_modemConfigBase[308] = 0x00504573UL;

  Protocol_Configuration_channels[0].baseFrequency = 870100000;
  Protocol_Configuration_channels[0].channelSpacing = 100000;
  Protocol_Configuration_channels[0].channelNumberEnd = 54;
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
  //Protocol_Configuration_channels[0].stackInfo = stackInfo_eu3_1a_fan1_0;
#endif
  return NULL;
}

RAIL_ChannelConfigEntry_t * rf_set_config_wisun_fan_eu_873_2a(phy_rf_channel_configuration_s *mbed_channel_config){
  (void)mbed_channel_config;

  phyInfo[1] = 0x002B8994UL;
  phyInfo[4] = (uint32_t) timingConfig_1;
  phyInfo[8] = 100000UL;
  phyInfo[9] = 0x00F20101UL;
  phyInfo[10] = 0x071016D0UL;
  phyInfo[16] = 99999UL;
#if RAIL_SUPPORTS_HFXO_COMPENSATION
  phyInfo[19] = (uint32_t) modemTxCompensation_1;
#endif

  Protocol_Configuration_modemConfigBase[53] = /*    C058 */ 0xE682008CUL;
  Protocol_Configuration_modemConfigBase[54] = /*    C05C */ 0x000001A4UL;
  Protocol_Configuration_modemConfigBase[55] = /*    C060 */ 0x7E77694DUL;
  Protocol_Configuration_modemConfigBase[56] = /*    C064 */ 0x00000082UL;
  Protocol_Configuration_modemConfigBase[58] = /*    C06C */ 0x000004A0UL;
  Protocol_Configuration_modemConfigBase[59] = /*    C070 */ 0x000010BAUL;
  Protocol_Configuration_modemConfigBase[60] = /*    C074 */ 0x003F0000UL;
  Protocol_Configuration_modemConfigBase[61] = /*    C078 */ 0x00EE008DUL;
  Protocol_Configuration_modemConfigBase[62] = /*    C07C */ 0x03AC01F6UL;
  Protocol_Configuration_modemConfigBase[63] = /*    C080 */ 0x079604F5UL;
  Protocol_Configuration_modemConfigBase[64] = /*    C084 */ 0x0D9C09DEUL;
  Protocol_Configuration_modemConfigBase[65] = /*    C088 */ 0x179311C3UL;
  Protocol_Configuration_modemConfigBase[66] = /*    C08C */ 0x26F51DFEUL;
  Protocol_Configuration_modemConfigBase[67] = /*    C090 */ 0x3FFF32BDUL;
  Protocol_Configuration_modemConfigBase[68] = /*    C094 */ 0x1BF815FEUL;
  Protocol_Configuration_modemConfigBase[69] = /*    C098 */ 0x2DB423DCUL;
  Protocol_Configuration_modemConfigBase[79] = 0x000001FEUL;
  Protocol_Configuration_modemConfigBase[95] = 0x20F00000UL;
  Protocol_Configuration_modemConfigBase[100] = /*    4054 */ 0x20000000UL;
  Protocol_Configuration_modemConfigBase[105] = /*    4068 */ 0x00FC2FFDUL;
  Protocol_Configuration_modemConfigBase[106] = /*    406C */ 0x00000840UL;
  Protocol_Configuration_modemConfigBase[108] = 0x00200012UL;
  Protocol_Configuration_modemConfigBase[111] = /*    4080 */ 0x00000F46UL;
  Protocol_Configuration_modemConfigBase[113] = /*    4088 */ 0x003B0390UL;
  Protocol_Configuration_modemConfigBase[114] = /*    408C */ 0x62060000UL;
  Protocol_Configuration_modemConfigBase[144] = 0x40A96701UL;
  Protocol_Configuration_modemConfigBase[146] = /*    4148 */ 0x4148E9B0UL;
  Protocol_Configuration_modemConfigBase[147] = /*    414C */ 0x00403B89UL;
  Protocol_Configuration_modemConfigBase[170] = /*    41B4 */ 0xC02ED568UL;
  Protocol_Configuration_modemConfigBase[178] = /*    41D4 */ 0x80BB80E7UL;
  Protocol_Configuration_modemConfigBase[179] = /*    41D8 */ 0x000A0004UL;
  Protocol_Configuration_modemConfigBase[182] = 0x00000058UL;
  Protocol_Configuration_modemConfigBase[192] = /*    424C */ 0x04030008UL;
  Protocol_Configuration_modemConfigBase[210] = 0x000000F0UL;
  Protocol_Configuration_modemConfigBase[214] = 0x001016D0UL;
  Protocol_Configuration_modemConfigBase[219] = /*    80A4 */ 0x0003B870UL;
  Protocol_Configuration_modemConfigBase[227] = 0x01014201UL;
  Protocol_Configuration_modemConfigBase[230] = /*    80B4 */ 0x02000300UL;
  Protocol_Configuration_modemConfigBase[263] = 0x00A200C8UL;
  Protocol_Configuration_modemConfigBase[266] = /*    016C */ 0x000C0000UL;
  Protocol_Configuration_modemConfigBase[268] = 0x01900169UL;
  Protocol_Configuration_modemConfigBase[276] = 0x00000006UL;
  Protocol_Configuration_modemConfigBase[278] = 0x00000090UL;
  Protocol_Configuration_modemConfigBase[289] = 0x00000068UL;
  Protocol_Configuration_modemConfigBase[290] = /*    0104 */ 0x0809AC31UL;
  Protocol_Configuration_modemConfigBase[292] = /*    010C */ 0x11E107F9UL;
  Protocol_Configuration_modemConfigBase[293] = /*    0110 */ 0x0005E9CCUL;
  Protocol_Configuration_modemConfigBase[294] = /*    0114 */ 0x006C8E32UL;
  Protocol_Configuration_modemConfigBase[295] = /*    0118 */ 0x004EB132UL;
  Protocol_Configuration_modemConfigBase[296] = /*    011C */ 0x0E1C0182UL;
  Protocol_Configuration_modemConfigBase[297] = /*    0120 */ 0x0265F774UL;
  Protocol_Configuration_modemConfigBase[298] = /*    0124 */ 0x3350259BUL;
  Protocol_Configuration_modemConfigBase[299] = /*    0128 */ 0x0A00ABFFUL;
  Protocol_Configuration_modemConfigBase[300] = /*    012C */ 0x000FF15CUL;
  Protocol_Configuration_modemConfigBase[301] = /*    0130 */ 0x000241D3UL;
  Protocol_Configuration_modemConfigBase[302] = /*    0134 */ 0x00B1ED95UL;
  Protocol_Configuration_modemConfigBase[303] = /*    0138 */ 0x04B90812UL;
  Protocol_Configuration_modemConfigBase[304] = /*    013C */ 0x0FD87B19UL;
  Protocol_Configuration_modemConfigBase[305] = /*    0140 */ 0x1F6D1BEAUL;
  Protocol_Configuration_modemConfigBase[308] = 0x00505799UL;

  Protocol_Configuration_channels[0].baseFrequency = 870200000;
  Protocol_Configuration_channels[0].channelSpacing = 200000;
  Protocol_Configuration_channels[0].channelNumberEnd = 26;
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
  //Protocol_Configuration_channels[0].stackInfo = stackInfo_eu4_2a_fan1_0;
#endif
  return NULL;
}

RAIL_ChannelConfigEntry_t * rf_set_config_wisun_fan_eu_873_3(phy_rf_channel_configuration_s *mbed_channel_config){
  (void)mbed_channel_config;

  phyInfo[1] = 0x00307C1FUL;
  phyInfo[4] = (uint32_t) timingConfig_2;
  phyInfo[8] = 150000UL;
  phyInfo[9] = 0x00EF0101UL;
  phyInfo[10] = 0x07101B89UL;
  phyInfo[16] = 149999UL;
#if RAIL_SUPPORTS_HFXO_COMPENSATION
  phyInfo[19] = (uint32_t) modemTxCompensation_2;
#endif

  Protocol_Configuration_modemConfigBase[53] = /*    C058 */ 0xE66C0074UL;
  Protocol_Configuration_modemConfigBase[54] = /*    C05C */ 0x0000015CUL;
  Protocol_Configuration_modemConfigBase[55] = /*    C060 */ 0x68635740UL;
  Protocol_Configuration_modemConfigBase[56] = /*    C064 */ 0x0000006CUL;
  Protocol_Configuration_modemConfigBase[58] = /*    C06C */ 0x000004A0UL;
  Protocol_Configuration_modemConfigBase[59] = /*    C070 */ 0x000010BAUL;
  Protocol_Configuration_modemConfigBase[60] = /*    C074 */ 0x003F0000UL;
  Protocol_Configuration_modemConfigBase[61] = /*    C078 */ 0x00EE008DUL;
  Protocol_Configuration_modemConfigBase[62] = /*    C07C */ 0x03AC01F6UL;
  Protocol_Configuration_modemConfigBase[63] = /*    C080 */ 0x079604F5UL;
  Protocol_Configuration_modemConfigBase[64] = /*    C084 */ 0x0D9C09DEUL;
  Protocol_Configuration_modemConfigBase[65] = /*    C088 */ 0x179311C3UL;
  Protocol_Configuration_modemConfigBase[66] = /*    C08C */ 0x26F51DFEUL;
  Protocol_Configuration_modemConfigBase[67] = /*    C090 */ 0x3FFF32BDUL;
  Protocol_Configuration_modemConfigBase[68] = /*    C094 */ 0x1BF815FEUL;
  Protocol_Configuration_modemConfigBase[69] = /*    C098 */ 0x2DB423DCUL;
  Protocol_Configuration_modemConfigBase[79] = 0x000000EEUL;
  Protocol_Configuration_modemConfigBase[95] = 0x30B00000UL;
  Protocol_Configuration_modemConfigBase[100] = /*    4054 */ 0x00000000UL;
  Protocol_Configuration_modemConfigBase[105] = /*    4068 */ 0x00FE203FUL;
  Protocol_Configuration_modemConfigBase[106] = /*    406C */ 0x00000840UL;
  Protocol_Configuration_modemConfigBase[108] = 0x00300012UL;
  Protocol_Configuration_modemConfigBase[111] = /*    4080 */ 0x00001F50UL;
  Protocol_Configuration_modemConfigBase[113] = /*    4088 */ 0x000803B2UL;
  Protocol_Configuration_modemConfigBase[114] = /*    408C */ 0x62060000UL;
  Protocol_Configuration_modemConfigBase[144] = 0x40A96701UL;
  Protocol_Configuration_modemConfigBase[146] = /*    4148 */ 0x4148A2ADUL;
  Protocol_Configuration_modemConfigBase[147] = /*    414C */ 0x00403B89UL;
  Protocol_Configuration_modemConfigBase[170] = /*    41B4 */ 0xC02FD568UL;
  Protocol_Configuration_modemConfigBase[178] = /*    41D4 */ 0x80BB80E7UL;
  Protocol_Configuration_modemConfigBase[179] = /*    41D8 */ 0x000A0004UL;
  Protocol_Configuration_modemConfigBase[182] = 0x00000078UL;
  Protocol_Configuration_modemConfigBase[192] = /*    424C */ 0x04030008UL;
  Protocol_Configuration_modemConfigBase[210] = 0x000000D0UL;
  Protocol_Configuration_modemConfigBase[214] = 0x00101B89UL;
  Protocol_Configuration_modemConfigBase[219] = /*    80A4 */ 0x0003B870UL;
  Protocol_Configuration_modemConfigBase[227] = 0x01014201UL;
  Protocol_Configuration_modemConfigBase[230] = /*    80B4 */ 0x02000300UL;
  Protocol_Configuration_modemConfigBase[263] = 0x00A200C4UL;
  Protocol_Configuration_modemConfigBase[266] = /*    016C */ 0x000C0000UL;
  Protocol_Configuration_modemConfigBase[268] = 0x01900169UL;
  Protocol_Configuration_modemConfigBase[276] = 0x00000006UL;
  Protocol_Configuration_modemConfigBase[278] = 0x00000090UL;
  Protocol_Configuration_modemConfigBase[289] = 0x00000050UL;
  Protocol_Configuration_modemConfigBase[290] = /*    0104 */ 0x08083503UL;
  Protocol_Configuration_modemConfigBase[292] = /*    010C */ 0x046EC3D5UL;
  Protocol_Configuration_modemConfigBase[293] = /*    0110 */ 0x000E599AUL;
  Protocol_Configuration_modemConfigBase[294] = /*    0114 */ 0x00694F64UL;
  Protocol_Configuration_modemConfigBase[295] = /*    0118 */ 0x004ADF9DUL;
  Protocol_Configuration_modemConfigBase[296] = /*    011C */ 0x0E6B035CUL;
  Protocol_Configuration_modemConfigBase[297] = /*    0120 */ 0x01E2F5F3UL;
  Protocol_Configuration_modemConfigBase[298] = /*    0124 */ 0x36172668UL;
  Protocol_Configuration_modemConfigBase[299] = /*    0128 */ 0x365E63DEUL;
  Protocol_Configuration_modemConfigBase[300] = /*    012C */ 0x00076FBFUL;
  Protocol_Configuration_modemConfigBase[301] = /*    0130 */ 0x0016EA6FUL;
  Protocol_Configuration_modemConfigBase[302] = /*    0134 */ 0x00CE30E5UL;
  Protocol_Configuration_modemConfigBase[303] = /*    0138 */ 0x0494844BUL;
  Protocol_Configuration_modemConfigBase[304] = /*    013C */ 0x0ED9B9B2UL;
  Protocol_Configuration_modemConfigBase[305] = /*    0140 */ 0x24A91F5AUL;
  Protocol_Configuration_modemConfigBase[308] = 0x005069BCUL;

  Protocol_Configuration_channels[0].baseFrequency = 870200000;
  Protocol_Configuration_channels[0].channelSpacing = 200000;
  Protocol_Configuration_channels[0].channelNumberEnd = 26;
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
  //Protocol_Configuration_channels[0].stackInfo = stackInfo_eu4_3_fan1_0;
#endif
  return NULL;
}

RAIL_ChannelConfigEntry_t * rf_set_config_wisun_fan_na_915_1b(phy_rf_channel_configuration_s *mbed_channel_config){
  (void)mbed_channel_config;

  phyInfo[1] = 0x003CF3CFUL;
  phyInfo[4] = (uint32_t) timingConfig_0;
  phyInfo[8] = 50000UL;
  phyInfo[9] = 0x00F10101UL;
  phyInfo[10] = 0x07101703UL;
  phyInfo[16] = 50000UL;
#if RAIL_SUPPORTS_HFXO_COMPENSATION
  phyInfo[19] = (uint32_t) modemTxCompensation_0;
#endif

  Protocol_Configuration_modemConfigBase[53] = /*    C058 */ 0xE681008BUL;
  Protocol_Configuration_modemConfigBase[54] = /*    C05C */ 0x000001A1UL;
  Protocol_Configuration_modemConfigBase[55] = /*    C060 */ 0x7D76684CUL;
  Protocol_Configuration_modemConfigBase[56] = /*    C064 */ 0x00000081UL;
  Protocol_Configuration_modemConfigBase[58] = /*    C06C */ 0x000004A0UL;
  Protocol_Configuration_modemConfigBase[59] = /*    C070 */ 0x000013BAUL;
  Protocol_Configuration_modemConfigBase[60] = /*    C074 */ 0x00190000UL;
  Protocol_Configuration_modemConfigBase[61] = /*    C078 */ 0x0065003AUL;
  Protocol_Configuration_modemConfigBase[62] = /*    C07C */ 0x00DA0096UL;
  Protocol_Configuration_modemConfigBase[63] = /*    C080 */ 0x02BA01C0UL;
  Protocol_Configuration_modemConfigBase[64] = /*    C084 */ 0x05B003D6UL;
  Protocol_Configuration_modemConfigBase[65] = /*    C088 */ 0x09EA07B2UL;
  Protocol_Configuration_modemConfigBase[66] = /*    C08C */ 0x10FE0CFAUL;
  Protocol_Configuration_modemConfigBase[67] = /*    C090 */ 0x1D5A16D2UL;
  Protocol_Configuration_modemConfigBase[68] = /*    C094 */ 0x3178269AUL;
  Protocol_Configuration_modemConfigBase[69] = /*    C098 */ 0x36DA3FFFUL;
  Protocol_Configuration_modemConfigBase[79] = 0x000001FEUL;
  Protocol_Configuration_modemConfigBase[95] = 0x20F00000UL;
  Protocol_Configuration_modemConfigBase[100] = /*    4054 */ 0x20000000UL;
  Protocol_Configuration_modemConfigBase[105] = /*    4068 */ 0x00FE60BDUL;
  Protocol_Configuration_modemConfigBase[106] = /*    406C */ 0x00000C40UL;
  Protocol_Configuration_modemConfigBase[108] = 0x00200012UL;
  Protocol_Configuration_modemConfigBase[111] = /*    4080 */ 0x00000F43UL;
  Protocol_Configuration_modemConfigBase[113] = /*    4088 */ 0x002B0390UL;
  Protocol_Configuration_modemConfigBase[114] = /*    408C */ 0x62060000UL;
  Protocol_Configuration_modemConfigBase[144] = 0x40B17303UL;
  Protocol_Configuration_modemConfigBase[146] = /*    4148 */ 0x41E9CFB7UL;
  Protocol_Configuration_modemConfigBase[147] = /*    414C */ 0x00403B89UL;
  Protocol_Configuration_modemConfigBase[170] = /*    41B4 */ 0xC02ED568UL;
  Protocol_Configuration_modemConfigBase[178] = /*    41D4 */ 0x80BB81E7UL;
  Protocol_Configuration_modemConfigBase[179] = /*    41D8 */ 0x000E0006UL;
  Protocol_Configuration_modemConfigBase[182] = 0x00000058UL;
  Protocol_Configuration_modemConfigBase[192] = /*    424C */ 0x04050008UL;
  Protocol_Configuration_modemConfigBase[210] = 0x000000F0UL;
  Protocol_Configuration_modemConfigBase[214] = 0x00101703UL;
  Protocol_Configuration_modemConfigBase[219] = /*    80A4 */ 0x0003B870UL;
  Protocol_Configuration_modemConfigBase[227] = 0x01014201UL;
  Protocol_Configuration_modemConfigBase[230] = /*    80B4 */ 0x02000300UL;
  Protocol_Configuration_modemConfigBase[263] = 0x00A200C8UL;
  Protocol_Configuration_modemConfigBase[266] = /*    016C */ 0x000C0000UL;
  Protocol_Configuration_modemConfigBase[268] = 0x01900169UL;
  Protocol_Configuration_modemConfigBase[276] = 0x00000006UL;
  Protocol_Configuration_modemConfigBase[278] = 0x00000090UL;
  Protocol_Configuration_modemConfigBase[289] = 0x00000068UL;
  Protocol_Configuration_modemConfigBase[290] = /*    0104 */ 0x080CE596UL;
  Protocol_Configuration_modemConfigBase[292] = /*    010C */ 0x0BFFE7E6UL;
  Protocol_Configuration_modemConfigBase[293] = /*    0110 */ 0x000AA1CDUL;
  Protocol_Configuration_modemConfigBase[294] = /*    0114 */ 0x006A06BDUL;
  Protocol_Configuration_modemConfigBase[295] = /*    0118 */ 0x004DB05EUL;
  Protocol_Configuration_modemConfigBase[296] = /*    011C */ 0x0E42027DUL;
  Protocol_Configuration_modemConfigBase[297] = /*    0120 */ 0x0222B6A5UL;
  Protocol_Configuration_modemConfigBase[298] = /*    0124 */ 0x34B225FFUL;
  Protocol_Configuration_modemConfigBase[299] = /*    0128 */ 0x0EF1AC1DUL;
  Protocol_Configuration_modemConfigBase[300] = /*    012C */ 0x000C3974UL;
  Protocol_Configuration_modemConfigBase[301] = /*    0130 */ 0x007680B0UL;
  Protocol_Configuration_modemConfigBase[302] = /*    0134 */ 0x00B3DC89UL;
  Protocol_Configuration_modemConfigBase[303] = /*    0138 */ 0x04C789C6UL;
  Protocol_Configuration_modemConfigBase[304] = /*    013C */ 0x00643C93UL;
  Protocol_Configuration_modemConfigBase[305] = /*    0140 */ 0x1D651A8FUL;
  Protocol_Configuration_modemConfigBase[308] = 0x0050585DUL;

  Protocol_Configuration_channels[0].baseFrequency = 902200000;
  Protocol_Configuration_channels[0].channelSpacing = 200000;
  Protocol_Configuration_channels[0].channelNumberEnd = 128;
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
  //Protocol_Configuration_channels[0].stackInfo = stackInfo_na1_1b_fan1_0;
#endif
  return NULL;
}

RAIL_ChannelConfigEntry_t * rf_set_config_wisun_fan_na_915_2a(phy_rf_channel_configuration_s *mbed_channel_config){
  (void)mbed_channel_config;

  phyInfo[1] = 0x002B8994UL;
  phyInfo[4] = (uint32_t) timingConfig_1;
  phyInfo[8] = 100000UL;
  phyInfo[9] = 0x00F10101UL;
  phyInfo[10] = 0x07101703UL;
  phyInfo[16] = 99999UL;
#if RAIL_SUPPORTS_HFXO_COMPENSATION
  phyInfo[19] = (uint32_t) modemTxCompensation_1;
#endif

  Protocol_Configuration_modemConfigBase[53] = /*    C058 */ 0xE681008BUL;
  Protocol_Configuration_modemConfigBase[54] = /*    C05C */ 0x000001A1UL;
  Protocol_Configuration_modemConfigBase[55] = /*    C060 */ 0x7D76684CUL;
  Protocol_Configuration_modemConfigBase[56] = /*    C064 */ 0x00000081UL;
  Protocol_Configuration_modemConfigBase[58] = /*    C06C */ 0x000004A0UL;
  Protocol_Configuration_modemConfigBase[59] = /*    C070 */ 0x000013BAUL;
  Protocol_Configuration_modemConfigBase[60] = /*    C074 */ 0x00190000UL;
  Protocol_Configuration_modemConfigBase[61] = /*    C078 */ 0x0065003AUL;
  Protocol_Configuration_modemConfigBase[62] = /*    C07C */ 0x00DA0096UL;
  Protocol_Configuration_modemConfigBase[63] = /*    C080 */ 0x02BA01C0UL;
  Protocol_Configuration_modemConfigBase[64] = /*    C084 */ 0x05B003D6UL;
  Protocol_Configuration_modemConfigBase[65] = /*    C088 */ 0x09EA07B2UL;
  Protocol_Configuration_modemConfigBase[66] = /*    C08C */ 0x10FE0CFAUL;
  Protocol_Configuration_modemConfigBase[67] = /*    C090 */ 0x1D5A16D2UL;
  Protocol_Configuration_modemConfigBase[68] = /*    C094 */ 0x3178269AUL;
  Protocol_Configuration_modemConfigBase[69] = /*    C098 */ 0x36DA3FFFUL;
  Protocol_Configuration_modemConfigBase[79] = 0x000001FEUL;
  Protocol_Configuration_modemConfigBase[95] = 0x20F00000UL;
  Protocol_Configuration_modemConfigBase[100] = /*    4054 */ 0x20000000UL;
  Protocol_Configuration_modemConfigBase[105] = /*    4068 */ 0x00FC2FFDUL;
  Protocol_Configuration_modemConfigBase[106] = /*    406C */ 0x00000840UL;
  Protocol_Configuration_modemConfigBase[108] = 0x00200012UL;
  Protocol_Configuration_modemConfigBase[111] = /*    4080 */ 0x00000F46UL;
  Protocol_Configuration_modemConfigBase[113] = /*    4088 */ 0x003B0390UL;
  Protocol_Configuration_modemConfigBase[114] = /*    408C */ 0x62060000UL;
  Protocol_Configuration_modemConfigBase[144] = 0x40A96701UL;
  Protocol_Configuration_modemConfigBase[146] = /*    4148 */ 0x4148F1B1UL;
  Protocol_Configuration_modemConfigBase[147] = /*    414C */ 0x00403B89UL;
  Protocol_Configuration_modemConfigBase[170] = /*    41B4 */ 0xC02ED568UL;
  Protocol_Configuration_modemConfigBase[178] = /*    41D4 */ 0x80BB80E7UL;
  Protocol_Configuration_modemConfigBase[179] = /*    41D8 */ 0x000A0004UL;
  Protocol_Configuration_modemConfigBase[182] = 0x00000058UL;
  Protocol_Configuration_modemConfigBase[192] = /*    424C */ 0x04030008UL;
  Protocol_Configuration_modemConfigBase[210] = 0x000000F0UL;
  Protocol_Configuration_modemConfigBase[214] = 0x00101703UL;
  Protocol_Configuration_modemConfigBase[219] = /*    80A4 */ 0x0003B870UL;
  Protocol_Configuration_modemConfigBase[227] = 0x01014201UL;
  Protocol_Configuration_modemConfigBase[230] = /*    80B4 */ 0x02000300UL;
  Protocol_Configuration_modemConfigBase[263] = 0x00A200C8UL;
  Protocol_Configuration_modemConfigBase[266] = /*    016C */ 0x000C0000UL;
  Protocol_Configuration_modemConfigBase[268] = 0x01900169UL;
  Protocol_Configuration_modemConfigBase[276] = 0x00000006UL;
  Protocol_Configuration_modemConfigBase[278] = 0x00000090UL;
  Protocol_Configuration_modemConfigBase[289] = 0x00000068UL;
  Protocol_Configuration_modemConfigBase[290] = /*    0104 */ 0x0809AC31UL;
  Protocol_Configuration_modemConfigBase[292] = /*    010C */ 0x0BFFE7E6UL;
  Protocol_Configuration_modemConfigBase[293] = /*    0110 */ 0x000AA1CDUL;
  Protocol_Configuration_modemConfigBase[294] = /*    0114 */ 0x006A06BDUL;
  Protocol_Configuration_modemConfigBase[295] = /*    0118 */ 0x004DB05EUL;
  Protocol_Configuration_modemConfigBase[296] = /*    011C */ 0x0E42027DUL;
  Protocol_Configuration_modemConfigBase[297] = /*    0120 */ 0x0222B6A5UL;
  Protocol_Configuration_modemConfigBase[298] = /*    0124 */ 0x34B225FFUL;
  Protocol_Configuration_modemConfigBase[299] = /*    0128 */ 0x0A00ABFFUL;
  Protocol_Configuration_modemConfigBase[300] = /*    012C */ 0x000FF15CUL;
  Protocol_Configuration_modemConfigBase[301] = /*    0130 */ 0x000241D3UL;
  Protocol_Configuration_modemConfigBase[302] = /*    0134 */ 0x00B1ED95UL;
  Protocol_Configuration_modemConfigBase[303] = /*    0138 */ 0x04B90812UL;
  Protocol_Configuration_modemConfigBase[304] = /*    013C */ 0x0FD87B19UL;
  Protocol_Configuration_modemConfigBase[305] = /*    0140 */ 0x1F6D1BEAUL;
  Protocol_Configuration_modemConfigBase[308] = 0x0050585DUL;

  Protocol_Configuration_channels[0].baseFrequency = 902200000;
  Protocol_Configuration_channels[0].channelSpacing = 200000;
  Protocol_Configuration_channels[0].channelNumberEnd = 128;
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
  //Protocol_Configuration_channels[0].stackInfo = stackInfo_na1_2a_fan1_0;
#endif
  return NULL;
}

RAIL_ChannelConfigEntry_t * rf_set_config_wisun_fan_na_915_3(phy_rf_channel_configuration_s *mbed_channel_config){
  (void)mbed_channel_config;

  phyInfo[1] = 0x00320000UL;
  phyInfo[4] = (uint32_t) timingConfig_2;
  phyInfo[8] = 150000UL;
  phyInfo[9] = 0x00F20101UL;
  phyInfo[10] = 0x07101BBDUL;
  phyInfo[16] = 149999UL;
#if RAIL_SUPPORTS_HFXO_COMPENSATION
  phyInfo[19] = (uint32_t) modemTxCompensation_2;
#endif

  Protocol_Configuration_modemConfigBase[53] = /*    C058 */ 0xE66B0073UL;
  Protocol_Configuration_modemConfigBase[54] = /*    C05C */ 0x00000159UL;
  Protocol_Configuration_modemConfigBase[55] = /*    C060 */ 0x6862563FUL;
  Protocol_Configuration_modemConfigBase[56] = /*    C064 */ 0x0000006BUL;
  Protocol_Configuration_modemConfigBase[58] = /*    C06C */ 0x000004A0UL;
  Protocol_Configuration_modemConfigBase[59] = /*    C070 */ 0x000013BAUL;
  Protocol_Configuration_modemConfigBase[60] = /*    C074 */ 0x00190000UL;
  Protocol_Configuration_modemConfigBase[61] = /*    C078 */ 0x0065003AUL;
  Protocol_Configuration_modemConfigBase[62] = /*    C07C */ 0x00DA0096UL;
  Protocol_Configuration_modemConfigBase[63] = /*    C080 */ 0x02BA01C0UL;
  Protocol_Configuration_modemConfigBase[64] = /*    C084 */ 0x05B003D6UL;
  Protocol_Configuration_modemConfigBase[65] = /*    C088 */ 0x09EA07B2UL;
  Protocol_Configuration_modemConfigBase[66] = /*    C08C */ 0x10FE0CFAUL;
  Protocol_Configuration_modemConfigBase[67] = /*    C090 */ 0x1D5A16D2UL;
  Protocol_Configuration_modemConfigBase[68] = /*    C094 */ 0x3178269AUL;
  Protocol_Configuration_modemConfigBase[69] = /*    C098 */ 0x36DA3FFFUL;
  Protocol_Configuration_modemConfigBase[79] = 0x000000EEUL;
  Protocol_Configuration_modemConfigBase[95] = 0x30F00000UL;
  Protocol_Configuration_modemConfigBase[100] = /*    4054 */ 0x00000000UL;
  Protocol_Configuration_modemConfigBase[105] = /*    4068 */ 0x00FE203FUL;
  Protocol_Configuration_modemConfigBase[106] = /*    406C */ 0x00000840UL;
  Protocol_Configuration_modemConfigBase[108] = 0x00300012UL;
  Protocol_Configuration_modemConfigBase[111] = /*    4080 */ 0x00001F50UL;
  Protocol_Configuration_modemConfigBase[113] = /*    4088 */ 0x000803B2UL;
  Protocol_Configuration_modemConfigBase[114] = /*    408C */ 0x62060000UL;
  Protocol_Configuration_modemConfigBase[144] = 0x40A96901UL;
  Protocol_Configuration_modemConfigBase[146] = /*    4148 */ 0x4148A7ADUL;
  Protocol_Configuration_modemConfigBase[147] = /*    414C */ 0x00403B89UL;
  Protocol_Configuration_modemConfigBase[170] = /*    41B4 */ 0xC02FD568UL;
  Protocol_Configuration_modemConfigBase[178] = /*    41D4 */ 0x80BB80E7UL;
  Protocol_Configuration_modemConfigBase[179] = /*    41D8 */ 0x000A0004UL;
  Protocol_Configuration_modemConfigBase[182] = 0x00000078UL;
  Protocol_Configuration_modemConfigBase[192] = /*    424C */ 0x04030008UL;
  Protocol_Configuration_modemConfigBase[210] = 0x000000C0UL;
  Protocol_Configuration_modemConfigBase[214] = 0x00101BBDUL;
  Protocol_Configuration_modemConfigBase[219] = /*    80A4 */ 0x0003B870UL;
  Protocol_Configuration_modemConfigBase[227] = 0x01014201UL;
  Protocol_Configuration_modemConfigBase[230] = /*    80B4 */ 0x02000300UL;
  Protocol_Configuration_modemConfigBase[263] = 0x00A200C4UL;
  Protocol_Configuration_modemConfigBase[266] = /*    016C */ 0x000C0000UL;
  Protocol_Configuration_modemConfigBase[268] = 0x01900169UL;
  Protocol_Configuration_modemConfigBase[276] = 0x00000006UL;
  Protocol_Configuration_modemConfigBase[278] = 0x00000090UL;
  Protocol_Configuration_modemConfigBase[289] = 0x0000003AUL;
  Protocol_Configuration_modemConfigBase[290] = /*    0104 */ 0x080876ABUL;
  Protocol_Configuration_modemConfigBase[292] = /*    010C */ 0x0BFFE7E6UL;
  Protocol_Configuration_modemConfigBase[293] = /*    0110 */ 0x000AA1CDUL;
  Protocol_Configuration_modemConfigBase[294] = /*    0114 */ 0x006A06BDUL;
  Protocol_Configuration_modemConfigBase[295] = /*    0118 */ 0x004DB05EUL;
  Protocol_Configuration_modemConfigBase[296] = /*    011C */ 0x0E42027DUL;
  Protocol_Configuration_modemConfigBase[297] = /*    0120 */ 0x0222B6A5UL;
  Protocol_Configuration_modemConfigBase[298] = /*    0124 */ 0x34B225FFUL;
  Protocol_Configuration_modemConfigBase[299] = /*    0128 */ 0x3BBEE3E3UL;
  Protocol_Configuration_modemConfigBase[300] = /*    012C */ 0x000BA049UL;
  Protocol_Configuration_modemConfigBase[301] = /*    0130 */ 0x00131A92UL;
  Protocol_Configuration_modemConfigBase[302] = /*    0134 */ 0x00C38003UL;
  Protocol_Configuration_modemConfigBase[303] = /*    0138 */ 0x049C8539UL;
  Protocol_Configuration_modemConfigBase[304] = /*    013C */ 0x0F11B9CFUL;
  Protocol_Configuration_modemConfigBase[305] = /*    0140 */ 0x23321E63UL;
  Protocol_Configuration_modemConfigBase[308] = 0x00508E05UL;

  Protocol_Configuration_channels[0].baseFrequency = 902400000;
  Protocol_Configuration_channels[0].channelSpacing = 400000;
  Protocol_Configuration_channels[0].channelNumberEnd = 63;
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
  //Protocol_Configuration_channels[0].stackInfo = stackInfo_na2_3_fan1_0;
#endif
  return NULL;
}

RAIL_ChannelConfigEntry_t * rf_set_config_wisun_fan_na_915_4a(phy_rf_channel_configuration_s *mbed_channel_config){
  (void)mbed_channel_config;

  phyInfo[1] = 0x00333333UL;
  phyInfo[4] = (uint32_t) timingConfig_3;
  phyInfo[8] = 200000UL;
  phyInfo[9] = 0x00F10101UL;
  phyInfo[10] = 0x07102077UL;
  phyInfo[16] = 200000UL;
#if RAIL_SUPPORTS_HFXO_COMPENSATION
  phyInfo[19] = (uint32_t) modemTxCompensation_3;
#endif

  Protocol_Configuration_modemConfigBase[53] = /*    C058 */ 0xE65C0063UL;
  Protocol_Configuration_modemConfigBase[54] = /*    C05C */ 0x00000129UL;
  Protocol_Configuration_modemConfigBase[55] = /*    C060 */ 0x59544A36UL;
  Protocol_Configuration_modemConfigBase[56] = /*    C064 */ 0x0000005CUL;
  Protocol_Configuration_modemConfigBase[58] = /*    C06C */ 0x000004C0UL;
  Protocol_Configuration_modemConfigBase[59] = /*    C070 */ 0x000013BAUL;
  Protocol_Configuration_modemConfigBase[60] = /*    C074 */ 0x00190000UL;
  Protocol_Configuration_modemConfigBase[61] = /*    C078 */ 0x0065003AUL;
  Protocol_Configuration_modemConfigBase[62] = /*    C07C */ 0x00DA0096UL;
  Protocol_Configuration_modemConfigBase[63] = /*    C080 */ 0x02BA01C0UL;
  Protocol_Configuration_modemConfigBase[64] = /*    C084 */ 0x05B003D6UL;
  Protocol_Configuration_modemConfigBase[65] = /*    C088 */ 0x09EA07B2UL;
  Protocol_Configuration_modemConfigBase[66] = /*    C08C */ 0x10FE0CFAUL;
  Protocol_Configuration_modemConfigBase[67] = /*    C090 */ 0x1D5A16D2UL;
  Protocol_Configuration_modemConfigBase[68] = /*    C094 */ 0x3178269AUL;
  Protocol_Configuration_modemConfigBase[69] = /*    C098 */ 0x36DA3FFFUL;
  Protocol_Configuration_modemConfigBase[79] = 0x000000EEUL;
  Protocol_Configuration_modemConfigBase[95] = 0x31900000UL;
  Protocol_Configuration_modemConfigBase[100] = /*    4054 */ 0x20000000UL;
  Protocol_Configuration_modemConfigBase[105] = /*    4068 */ 0x00F8179DUL;
  Protocol_Configuration_modemConfigBase[106] = /*    406C */ 0x00000840UL;
  Protocol_Configuration_modemConfigBase[108] = 0x00300012UL;
  Protocol_Configuration_modemConfigBase[111] = /*    4080 */ 0x00001F64UL;
  Protocol_Configuration_modemConfigBase[113] = /*    4088 */ 0x002A03B0UL;
  Protocol_Configuration_modemConfigBase[114] = /*    408C */ 0x62060000UL;
  Protocol_Configuration_modemConfigBase[144] = 0x40A86501UL;
  Protocol_Configuration_modemConfigBase[146] = /*    4148 */ 0x414882ABUL;
  Protocol_Configuration_modemConfigBase[147] = /*    414C */ 0x00403B89UL;
  Protocol_Configuration_modemConfigBase[170] = /*    41B4 */ 0xC02FD568UL;
  Protocol_Configuration_modemConfigBase[178] = /*    41D4 */ 0x80BB80E7UL;
  Protocol_Configuration_modemConfigBase[179] = /*    41D8 */ 0x000A0004UL;
  Protocol_Configuration_modemConfigBase[182] = 0x00000078UL;
  Protocol_Configuration_modemConfigBase[192] = /*    424C */ 0x04030008UL;
  Protocol_Configuration_modemConfigBase[210] = 0x00000090UL;
  Protocol_Configuration_modemConfigBase[214] = 0x00102077UL;
  Protocol_Configuration_modemConfigBase[219] = /*    80A4 */ 0x0003B870UL;
  Protocol_Configuration_modemConfigBase[227] = 0x01014201UL;
  Protocol_Configuration_modemConfigBase[230] = /*    80B4 */ 0x02000300UL;
  Protocol_Configuration_modemConfigBase[263] = 0x00A200C4UL;
  Protocol_Configuration_modemConfigBase[266] = /*    016C */ 0x000C0000UL;
  Protocol_Configuration_modemConfigBase[268] = 0x01900169UL;
  Protocol_Configuration_modemConfigBase[276] = 0x00000006UL;
  Protocol_Configuration_modemConfigBase[278] = 0x00000090UL;
  Protocol_Configuration_modemConfigBase[289] = 0x00000025UL;
  Protocol_Configuration_modemConfigBase[290] = /*    0104 */ 0x08082000UL;
  Protocol_Configuration_modemConfigBase[292] = /*    010C */ 0x14F1E00BUL;
  Protocol_Configuration_modemConfigBase[293] = /*    0110 */ 0x00010998UL;
  Protocol_Configuration_modemConfigBase[294] = /*    0114 */ 0x007075DBUL;
  Protocol_Configuration_modemConfigBase[295] = /*    0118 */ 0x004CF1F5UL;
  Protocol_Configuration_modemConfigBase[296] = /*    011C */ 0x0DFD4085UL;
  Protocol_Configuration_modemConfigBase[297] = /*    0120 */ 0x02A7384AUL;
  Protocol_Configuration_modemConfigBase[298] = /*    0124 */ 0x322B2554UL;
  Protocol_Configuration_modemConfigBase[299] = /*    0128 */ 0x365E63DEUL;
  Protocol_Configuration_modemConfigBase[300] = /*    012C */ 0x00076FBFUL;
  Protocol_Configuration_modemConfigBase[301] = /*    0130 */ 0x0016EA6FUL;
  Protocol_Configuration_modemConfigBase[302] = /*    0134 */ 0x00CE30E5UL;
  Protocol_Configuration_modemConfigBase[303] = /*    0138 */ 0x0494844BUL;
  Protocol_Configuration_modemConfigBase[304] = /*    013C */ 0x0ED9B9B2UL;
  Protocol_Configuration_modemConfigBase[305] = /*    0140 */ 0x24A91F5AUL;
  Protocol_Configuration_modemConfigBase[308] = 0x0050CFC6UL;

  Protocol_Configuration_channels[0].baseFrequency = 902400000;
  Protocol_Configuration_channels[0].channelSpacing = 400000;
  Protocol_Configuration_channels[0].channelNumberEnd = 63;
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
  //Protocol_Configuration_channels[0].stackInfo = stackInfo_na2_4a_fan1_0;
#endif
  return NULL;
}

RAIL_ChannelConfigEntry_t * rf_set_config_wisun_fan_na_915_5(phy_rf_channel_configuration_s *mbed_channel_config){
  (void)mbed_channel_config;

  phyInfo[1] = 0x00471C71UL;
  phyInfo[4] = (uint32_t) timingConfig_4;
  phyInfo[8] = 300000UL;
  phyInfo[9] = 0x00F00101UL;
  phyInfo[10] = 0x07102B52UL;
  phyInfo[16] = 300000UL;
#if RAIL_SUPPORTS_HFXO_COMPENSATION
  phyInfo[19] = (uint32_t) modemTxCompensation_4;
#endif

  Protocol_Configuration_modemConfigBase[53] = /*    C058 */ 0xE645004AUL;
  Protocol_Configuration_modemConfigBase[54] = /*    C05C */ 0x000000DEUL;
  Protocol_Configuration_modemConfigBase[55] = /*    C060 */ 0x433F3829UL;
  Protocol_Configuration_modemConfigBase[56] = /*    C064 */ 0x00000045UL;
  Protocol_Configuration_modemConfigBase[58] = /*    C06C */ 0x000004C0UL;
  Protocol_Configuration_modemConfigBase[59] = /*    C070 */ 0x000013BAUL;
  Protocol_Configuration_modemConfigBase[60] = /*    C074 */ 0x00190000UL;
  Protocol_Configuration_modemConfigBase[61] = /*    C078 */ 0x0065003AUL;
  Protocol_Configuration_modemConfigBase[62] = /*    C07C */ 0x00DA0096UL;
  Protocol_Configuration_modemConfigBase[63] = /*    C080 */ 0x02BA01C0UL;
  Protocol_Configuration_modemConfigBase[64] = /*    C084 */ 0x05B003D6UL;
  Protocol_Configuration_modemConfigBase[65] = /*    C088 */ 0x09EA07B2UL;
  Protocol_Configuration_modemConfigBase[66] = /*    C08C */ 0x10FE0CFAUL;
  Protocol_Configuration_modemConfigBase[67] = /*    C090 */ 0x1D5A16D2UL;
  Protocol_Configuration_modemConfigBase[68] = /*    C094 */ 0x3178269AUL;
  Protocol_Configuration_modemConfigBase[69] = /*    C098 */ 0x36DA3FFFUL;
  Protocol_Configuration_modemConfigBase[79] = 0x000000EEUL;
  Protocol_Configuration_modemConfigBase[95] = 0x40B00000UL;
  Protocol_Configuration_modemConfigBase[100] = /*    4054 */ 0x20000000UL;
  Protocol_Configuration_modemConfigBase[105] = /*    4068 */ 0x00FC0FFFUL;
  Protocol_Configuration_modemConfigBase[106] = /*    406C */ 0x00000840UL;
  Protocol_Configuration_modemConfigBase[108] = 0x00600012UL;
  Protocol_Configuration_modemConfigBase[111] = /*    4080 */ 0x00004F64UL;
  Protocol_Configuration_modemConfigBase[113] = /*    4088 */ 0x002A03B2UL;
  Protocol_Configuration_modemConfigBase[114] = /*    408C */ 0x62050000UL;
  Protocol_Configuration_modemConfigBase[144] = 0x40A86501UL;
  Protocol_Configuration_modemConfigBase[146] = /*    4148 */ 0x41485DA9UL;
  Protocol_Configuration_modemConfigBase[147] = /*    414C */ 0x00403B89UL;
  Protocol_Configuration_modemConfigBase[170] = /*    41B4 */ 0xC02FD568UL;
  Protocol_Configuration_modemConfigBase[178] = /*    41D4 */ 0x80BB80E7UL;
  Protocol_Configuration_modemConfigBase[179] = /*    41D8 */ 0x000A0004UL;
  Protocol_Configuration_modemConfigBase[182] = 0x000000D8UL;
  Protocol_Configuration_modemConfigBase[192] = /*    424C */ 0x04030008UL;
  Protocol_Configuration_modemConfigBase[210] = 0x000000A0UL;
  Protocol_Configuration_modemConfigBase[214] = 0x00102B52UL;
  Protocol_Configuration_modemConfigBase[219] = /*    80A4 */ 0x00000FB0UL;
  Protocol_Configuration_modemConfigBase[227] = 0x03AF0001UL;
  Protocol_Configuration_modemConfigBase[230] = /*    80B4 */ 0x01000037UL;
  Protocol_Configuration_modemConfigBase[263] = 0x00A200C4UL;
  Protocol_Configuration_modemConfigBase[266] = /*    016C */ 0x00020000UL;
  Protocol_Configuration_modemConfigBase[268] = 0x019B8169UL;
  Protocol_Configuration_modemConfigBase[276] = 0x00000002UL;
  Protocol_Configuration_modemConfigBase[278] = 0x00000050UL;
  Protocol_Configuration_modemConfigBase[289] = 0x00000028UL;
  Protocol_Configuration_modemConfigBase[290] = /*    0104 */ 0x084785EDUL;
  Protocol_Configuration_modemConfigBase[292] = /*    010C */ 0x0BFFE7E6UL;
  Protocol_Configuration_modemConfigBase[293] = /*    0110 */ 0x000AA1CDUL;
  Protocol_Configuration_modemConfigBase[294] = /*    0114 */ 0x006A06BDUL;
  Protocol_Configuration_modemConfigBase[295] = /*    0118 */ 0x004DB05EUL;
  Protocol_Configuration_modemConfigBase[296] = /*    011C */ 0x0E42027DUL;
  Protocol_Configuration_modemConfigBase[297] = /*    0120 */ 0x0222B6A5UL;
  Protocol_Configuration_modemConfigBase[298] = /*    0124 */ 0x34B225FFUL;
  Protocol_Configuration_modemConfigBase[299] = /*    0128 */ 0x2CDDCFE2UL;
  Protocol_Configuration_modemConfigBase[300] = /*    012C */ 0x003AB67EUL;
  Protocol_Configuration_modemConfigBase[301] = /*    0130 */ 0x00190960UL;
  Protocol_Configuration_modemConfigBase[302] = /*    0134 */ 0x00E22251UL;
  Protocol_Configuration_modemConfigBase[303] = /*    0138 */ 0x04A98239UL;
  Protocol_Configuration_modemConfigBase[304] = /*    013C */ 0x0E51B94CUL;
  Protocol_Configuration_modemConfigBase[305] = /*    0140 */ 0x299B22D8UL;
  Protocol_Configuration_modemConfigBase[308] = 0x0050A65AUL;

  Protocol_Configuration_channels[0].baseFrequency = 902600000;
  Protocol_Configuration_channels[0].channelSpacing = 600000;
  Protocol_Configuration_channels[0].channelNumberEnd = 41;
#ifdef RADIO_CONFIG_ENABLE_STACK_INFO
  //Protocol_Configuration_channels[0].stackInfo = stackInfo_na3_5b_fan1_0;
#endif
  return NULL;
}